#!/usr/bin/env python3
"""
inventaire_php_app.py — Inventaire PHP, outil local des Hôpitaux de Corrèze (cadre HC-SSI-CADRE-DEV, type « outil local »)
CVE-2026-109618 / CVE-2026-109619 — avis CERTFR-2026-AVI-1359 (21/10/2026)

Bibliothèque standard Python (3.8+) ; interface servie à côté du programme (inventaire_php_interface.html, construite
par outils/construire.py avec la charte commune). Tout se paramètre dans l'interface.

Lancement :   python3 inventaire_php_app.py         le navigateur s'ouvre sur l'adresse locale munie du jeton de session
Options  :   --port 8765 ; l'écoute est toujours limitée à 127.0.0.1

Modules :
  Paramétrage     plages de scan autorisées, exclusions permanentes (VLAN biomédicaux), ports, débit
  Serveurs        import CSV de la liste des serveurs (nom, IP, OS, site…) servant de cibles
  Scan réseau     nmap + sonde HTTP sur les plages et/ou serveurs choisis (nmap requis sur le poste)
  Inventaire hôtes  relevé des versions exactes : Linux via SSH (clé requise), Windows via
                  PowerShell/WinRM (depuis un poste Windows du domaine), ou import des CSV
  Historique      scans conservés dans le dossier donnees_inventaire_php

Garde-fous : seules les cibles incluses dans les plages autorisées sont scannées ; le scan hôtes ne vise que les
serveurs de la liste importée ; les exclusions permanentes s'appliquent toujours ; l'interface n'écoute que sur
127.0.0.1, exige à chaque requête le jeton tiré au lancement et contrôle l'en-tête Host ; toute action passe par
une requête POST munie du jeton.
"""

import argparse
import base64
import hashlib
import hmac
import http.client
import secrets
import shutil
import zipfile
import socket
import csv
import io
import ipaddress
import json
import os
import platform
import re
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import unicodedata
import urllib.parse
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

# ---------------------------------------------------------------------------
# Référentiel CVE — à recaler si l'avis CERT-FR évolue
# ---------------------------------------------------------------------------
VERSION = "2.18.0"
APP_ID = "inventaire-php-hopitaux-correze"   # signature vérifiée dans les archives de mise à jour  # 2026-10-22
MENTION = "Diffusion restreinte"   # complétée par parametres_etablissement.json (organisation)
CVE_LIBELLE = "CVE-2026-109618 / CVE-2026-109619 — CERTFR-2026-AVI-1359 (21/10/2026)"
VERSIONS_CORRIGEES = {"8.5": (8, 5, 12), "8.4": (8, 4, 27), "8.3": (8, 3, 36), "8.2": (8, 2, 35)}
BRANCHE_MIN_MAINTENUE = (8, 2)
PORTS_DEFAUT = "80,81,443,8000,8008,8080,8081,8088,8443,8888,9000,9443,10000"
USER_AGENT = f"DSI-InventairePHP/{VERSION}"
TIMEOUT_HTTP = 6

BASE = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))
# Version portable : nmap et ssh peuvent être livrés dans des sous-dossiers à côté de l'application
for _sous in ("nmap", "ssh", "outils"):
    _d = os.path.join(BASE, _sous)
    if os.path.isdir(_d) and _d not in os.environ.get("PATH", ""):
        os.environ["PATH"] = _d + os.pathsep + os.environ.get("PATH", "")


def migrer_nom_donnees(cible):
    """Versions <= 2.2 : données dans « donnees_inventaire_php ». Depuis 2.5 : toujours « donnees ».
    Si seul l'ancien dossier existe à côté, il est renommé (rien n'est copié ni supprimé)."""
    ancien = os.path.join(os.path.dirname(cible), "donnees_inventaire_php")
    if os.path.basename(cible) == "donnees" and not os.path.exists(cible) and os.path.isdir(ancien):
        try:
            os.rename(ancien, cible)
            print(f"Dossier de données renommé : {ancien} -> {cible}", file=sys.stderr)
        except OSError:
            return ancien
    return cible


def dossier_donnees():
    """Dossier de données : --donnees, sinon variable INVENTAIRE_PHP_DONNEES, sinon à côté du script ;
    pour l'exécutable, dossier utilisateur (%LOCALAPPDATA%/InventairePHP ou ~/.inventaire_php),
    sauf si un dossier existe déjà à côté de l'exécutable (compatibilité)."""
    for i, a in enumerate(sys.argv):
        if a == "--donnees" and i + 1 < len(sys.argv):
            return migrer_nom_donnees(os.path.abspath(sys.argv[i + 1]))
    if os.environ.get("INVENTAIRE_PHP_DONNEES"):
        return os.path.abspath(os.environ["INVENTAIRE_PHP_DONNEES"])
    if not getattr(sys, "frozen", False):
        return migrer_nom_donnees(os.path.join(BASE, "donnees"))
    local = os.path.join(BASE, "donnees_inventaire_php")
    if getattr(sys, "frozen", False) and not os.path.isdir(local):
        racine = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        return os.path.join(racine, "InventairePHP" if os.environ.get("LOCALAPPDATA") else ".inventaire_php")
    return local


DATA = dossier_donnees()


def dossier_resultats():
    """Dossier des résultats (scans réseau, inventaires des hôtes, bilans reçus, journaux) : --resultats, sinon variable
    INVENTAIRE_PHP_RESULTATS, sinon le dossier de données (compatibilité avec les installations existantes).
    Comme le dossier de données, il reste hors de tout dépôt de code."""
    for i, a in enumerate(sys.argv):
        if a == "--resultats" and i + 1 < len(sys.argv):
            return os.path.abspath(sys.argv[i + 1])
    if os.environ.get("INVENTAIRE_PHP_RESULTATS"):
        return os.path.abspath(os.environ["INVENTAIRE_PHP_RESULTATS"])
    return DATA


RESULTATS = dossier_resultats()
JOURNAUX = os.path.join(RESULTATS, "journaux")
SCRIPTS = os.path.join(BASE, "scripts_inventaire_php")
CONFIG_PATH = os.path.join(DATA, "config.json")
SERVEURS_PATH = os.path.join(DATA, "serveurs.json")
HOTES_PATH = os.path.join(RESULTATS, "hotes.json")
EXTERNES_PATH = os.path.join(DATA, "externes.json")
SUIVI_PATH = os.path.join(DATA, "suivi.json")
NOMS_PATH = os.path.join(DATA, "noms.json")
VLANS_PATH = os.path.join(DATA, "vlans.json")

CONFIG = {"plages_autorisees": [], "exclusions": [], "ports": PORTS_DEFAUT, "debit": 200,
          "threads": 20, "ssh_parallele": 5, "ssh_timeout": 90,   # aucun compte n'est enregistré (saisi à chaque scan)
          # planification interne
          "planif_actif": False, "planif_heure": "06:30", "planif_jours": [0, 1, 2, 3, 4],
          "planif_cibles": "les_deux", "planif_inventaire_linux": False,
          # courriel de synthèse (optionnel)
          "smtp_serveur": "", "smtp_port": 25, "smtp_tls": False, "smtp_de": "", "smtp_a": "",
          "ps_approfondi": False, "plafond_hotes": 4096, "moteur": "auto",
          "py_connexions": 16, "tls_verifier": True, "ca_interne": "", "retention_jours": 365,
          # sélection du périmètre (v2.8) : VLAN, serveurs et noms d'hôtes cochés dans l'onglet Périmètre
          "perimetre_vlans": None, "perimetre_serveurs": [], "perimetre_noms": [], "perimetre_adresses": [],
          # nom de l'établissement inscrit dans le bilan exporté pour la consolidation territoriale (v2.10)
          "etablissement": ""}
ETAT_PLANIF = {"journal": [], "dernier": None, "prochain": None}
JETON = secrets.token_urlsafe(32)
PORT_ECOUTE = 8765
VERROU = threading.Lock()
ETAT = {"en_cours": False, "phase": "inactif", "fait": 0, "total": 0, "journal": [],
        "scan_id": None, "erreur": None, "proc": None, "stop": False,
        "pourcent": 0.0, "restant": None, "debut": None, "nmap_pourcent": 0.0, "fil": [], "courant": ""}
ETAT_INV = {"en_cours": False, "phase": "inactif", "fait": 0, "total": 0, "journal": [], "erreur": None, "stop": False,
            "fil": [], "courant": ""}


def fil(etat, msg, courant=None):
    """Activité en direct (défilement à l'écran) : adresses et serveurs en cours, ports ouverts, résultats."""
    with VERROU:
        etat["fil"].append(f"{datetime.now():%H:%M:%S}  {msg}")
        if len(etat["fil"]) > 600:
            del etat["fil"][:-500]
        if courant is not None:
            etat["courant"] = courant


def journal(etat, msg):
    with VERROU:
        etat["journal"].append(f"{datetime.now():%H:%M:%S}  {msg}")
        etat["journal"] = etat["journal"][-400:]
    if etat is ETAT_PLANIF:
        try:
            with open(os.path.join(RESULTATS, "planification.log"), "a", encoding="utf-8") as f:
                f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S}  {msg}\n")
        except OSError:
            pass
    # journal local du jour (hors dépôt) : trace de toutes les actions des scans et inventaires
    try:
        os.makedirs(JOURNAUX, exist_ok=True)
        with open(os.path.join(JOURNAUX, f"inventaire_php_{datetime.now():%Y%m%d}.log"), "a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S}  {msg}\n")
    except OSError:
        pass


def sauver_json(path, obj):
    os.makedirs(os.path.dirname(path) or DATA, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def lire_json(path, defaut):
    if os.path.exists(path):
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except json.JSONDecodeError:
            pass
    return defaut


def charger_parametres_etablissement():
    """Valeurs propres à l'établissement, hors du code (cadre § 3) : parametres_etablissement.json à côté du programme,
    éventuellement surchargé par le même fichier dans le dossier de données."""
    p = {"organisation": "", "mention": "Diffusion restreinte", "etablissements": []}
    for f in (os.path.join(BASE, "parametres_etablissement.json"), os.path.join(DATA, "parametres_etablissement.json")):
        d = lire_json(f, None)
        if isinstance(d, dict):
            p.update({k: v for k, v in d.items() if k in p})
    p["etablissements"] = [str(x)[:80] for x in p["etablissements"] if str(x).strip()][:20]
    return p


PARAMETRES = charger_parametres_etablissement()
MENTION = ""
ORGANISATION_ORIGINE = "Hôpitaux de Corrèze"   # l'auteur de l'outil ; une autre organisation déclenche l'habillage neutre


def recharger_parametres():
    """Relit les valeurs d'établissement (après une modification à l'écran) et met à jour ce qui en dépend."""
    global PARAMETRES, MENTION
    PARAMETRES = charger_parametres_etablissement()
    MENTION = str(PARAMETRES["mention"])[:120] + (f" — {PARAMETRES['organisation']}" if PARAMETRES["organisation"] else "")
    try:
        ETABLISSEMENTS[:] = PARAMETRES["etablissements"]
    except NameError:   # premier chargement : ETABLISSEMENTS n'existe pas encore
        pass
    try:
        _INTERFACE.clear()   # la page servie dépend de l'organisation (habillage neutre)
    except NameError:
        pass


recharger_parametres()


# ---------------------------------------------------------------------------
# Évaluation des versions
# ---------------------------------------------------------------------------
def evaluer(version, source, php_detecte=True):
    """Qualification selon la SOURCE de la version :
    banniere        : en-tête HTTP, jamais une preuve -> potentiellement vulnérable / à confirmer
    paquet          : version de paquet dpkg/rpm -> correctif possible par backport distribution
    binaire_distrib : php -v sur un hôte où PHP vient d'un paquet distribution -> idem
    binaire, windows, conteneur : version réellement exécutée, sans backport -> confirmé
    """
    if not version:
        return "A VERIFIER (PHP détecté, version non lisible)" if php_detecte else "pas d'indice PHP"
    m = re.match(r"(\d+)\.(\d+)\.(\d+)", version)
    if not m:
        return f"A VERIFIER (version illisible : {version})"
    maj, mi, pa = (int(x) for x in m.groups())
    branche = f"{maj}.{mi}"
    fiable = source in ("binaire", "windows", "conteneur")
    distrib = source in ("paquet", "binaire_distrib")
    if (maj, mi) < BRANCHE_MIN_MAINTENUE:
        if fiable:
            return f"VULNERABLE CONFIRME - branche {branche} non maintenue, sans correctif : migrer"
        return f"POTENTIELLEMENT VULNERABLE - branche {branche} non maintenue (source : {source}) : confirmer sur l'hôte"
    fixe = VERSIONS_CORRIGEES.get(branche)
    if fixe is None:
        return f"A VERIFIER (branche {branche} hors référentiel)"
    cible = ".".join(map(str, fixe))
    if (maj, mi, pa) >= fixe:
        if fiable:
            return f"CORRECTIF CONFIRME (version {version} >= {cible})"
        if distrib:
            return f"CORRECTIF CONFIRME (paquet {version} >= {cible})"
        return f"A VERIFIER - version {version} >= {cible} d'après la bannière HTTP : confirmer sur l'hôte"
    if fiable:
        return f"VULNERABLE CONFIRME - {version} < {cible} : corriger"
    if distrib:
        return f"A VERIFIER - {version} < {cible} mais correctif rétroporté possible : consulter l'avis DSA/RHSA du paquet"
    return f"POTENTIELLEMENT VULNERABLE - bannière {version} < {cible} : confirmer sur l'hôte"


def classe_statut(statut):
    s = (statut or "").upper()
    if s.startswith("INSTALLATION PRESENTE"):
        return "vuln" if "VULNERABLE CONFIRME" in s else "verif"
    if s.startswith("NON CONCERNE"):
        return "ok"
    if s.startswith("VULNERABLE") or s.startswith("POTENTIELLEMENT VULNERABLE"):
        return "vuln"
    if s.startswith("CORRECTIF CONFIRME") or s.startswith("CORRIGE"):
        return "ok"
    if s.startswith("A VERIFIER") or "INCONNUE" in s or "VERIFIER" in s or "A TRAITER" in s or "INJOIGNABLE" in s or "SERVEUR WEB PRESENT" in s:
        return "verif"
    return "neutre"


# ---------------------------------------------------------------------------
# Réseaux, serveurs, cibles
# ---------------------------------------------------------------------------
def parse_reseaux(liste):
    res = []
    for v in liste:
        v = str(v).strip()
        if not v or v.startswith("#"):
            continue
        res.append(ipaddress.ip_network(v, strict=False))
    return res


def dans_autorisees(reseau, autorisees):
    return any(reseau.version == a.version and reseau.subnet_of(a) for a in autorisees)


def valider_cibles(cibles_txt):
    autorisees = parse_reseaux(CONFIG["plages_autorisees"])
    if not autorisees:
        raise ValueError("Aucune plage autorisée : renseignez l'onglet Paramétrage")
    cibles = parse_reseaux(cibles_txt)
    if not cibles:
        raise ValueError("Aucune cible sélectionnée")
    refus = [str(c) for c in cibles if not dans_autorisees(c, autorisees)]
    if refus:
        raise ValueError("Cibles hors des plages autorisées : " + ", ".join(refus[:15]) + (" …" if len(refus) > 15 else ""))
    return cibles


RE_IP = re.compile(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b")


def xlsx_vers_texte(octets, feuilles_preferees=("vInfo",)):
    """Classeur Excel (.xlsx/.xlsm) -> texte tabulé de la feuille utile (vInfo pour RVTools, sinon la première).
    Bibliothèque standard uniquement (zipfile + XML)."""
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
          "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
    try:
        z = zipfile.ZipFile(io.BytesIO(octets))
    except zipfile.BadZipFile:
        raise ValueError("Fichier Excel illisible (classeur endommagé ou protégé par mot de passe)")
    noms = set(z.namelist())
    partages = []
    if "xl/sharedStrings.xml" in noms:
        for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", ns):
            partages.append("".join(t.text or "" for t in si.iter("{%s}t" % ns["m"])))
    wb = ET.fromstring(z.read("xl/workbook.xml"))
    rels = {r.get("Id"): r.get("Target") for r in ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))}
    feuilles = [(f.get("name"), rels.get(f.get("{%s}id" % ns["r"]), "")) for f in wb.find("m:sheets", ns)]
    if not feuilles:
        raise ValueError("Classeur sans feuille")
    nom, cible = next((f for f in feuilles if f[0] in feuilles_preferees), feuilles[0])
    chemin = cible.lstrip("/") if cible.startswith("/") else "xl/" + cible
    def col(ref):
        n = 0
        for c in re.match(r"[A-Z]+", ref).group(0):
            n = n * 26 + ord(c) - 64
        return n - 1
    lignes = []
    for row in ET.fromstring(z.read(chemin)).iter("{%s}row" % ns["m"]):
        cellules = {}
        for c in row.findall("m:c", ns):
            t, v = c.get("t"), c.find("m:v", ns)
            if t == "s" and v is not None:
                val = partages[int(v.text)]
            elif t == "inlineStr":
                val = "".join(x.text or "" for x in c.iter("{%s}t" % ns["m"]))
            else:
                val = v.text if v is not None and v.text else ""
            if c.get("r"):
                cellules[col(c.get("r"))] = val
        if cellules:
            larg = max(cellules) + 1
            lignes.append("\t".join(re.sub(r"[\t\r\n]+", " ", cellules.get(i, "")) for i in range(larg)))
    if not lignes:
        raise ValueError(f"Feuille « {nom} » vide")
    return "\n".join(lignes)


def texte_importe(octets):
    """Corps d'un import : classeur Excel (signature ZIP) ou texte UTF-8 / Windows-1252."""
    if octets[:2] == b"PK":
        return xlsx_vers_texte(octets)
    try:
        return octets.decode("utf-8")
    except UnicodeDecodeError:
        return octets.decode("cp1252", "replace")


def lire_tableau(texte):
    """Lit un CSV / texte tabulé / point-virgule. Retourne (entêtes_brutes, lignes, a_entete)."""
    texte = texte.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    if not texte.strip():
        raise ValueError("Fichier vide")
    # lignes de mention (« # Diffusion restreinte … ») en tête des exports de l'application
    lignes_txt = texte.split("\n")
    while lignes_txt and lignes_txt[0].lstrip("\ufeff").startswith("#"):
        lignes_txt.pop(0)
    texte = "\n".join(lignes_txt)
    if not texte.strip():
        raise ValueError("Fichier vide")
    premiere = texte.splitlines()[0]
    if "\t" in premiere:
        delim = "\t"
    else:
        try:
            delim = csv.Sniffer().sniff(texte[:3000], delimiters=";,|").delimiter
        except csv.Error:
            delim = ";"
    lignes = [l for l in csv.reader(io.StringIO(texte), delimiter=delim)]
    lignes = [l for l in lignes if any(c.strip() for c in l)]
    if not lignes:
        raise ValueError("Fichier vide")
    a_entete = not any(RE_IP.search(c) for c in lignes[0])
    return ([c.strip() for c in lignes[0]] if a_entete else [f"Colonne {i+1}" for i in range(len(lignes[0]))]), (lignes[1:] if a_entete else lignes), a_entete


# Synonymes reconnus dans les en-têtes, du plus spécifique au plus général
CHAMPS_SERVEUR = {
    "ip": ["primary ip address", "adresse ip", "ip address", "ip #1", "ipv4", "adresse", "address", "ip"],
    "nom": ["vm", "nom du serveur", "hostname", "dns name", "nom", "name", "host", "serveur", "server", "fqdn", "machine"],
    "os": ["os according to the vmware tools", "os according to the configuration file", "système d'exploitation", "systeme", "système", "operating system", "os installé", "os"],
    "site": ["datacenter", "établissement", "etablissement", "site", "localisation", "location"],
    "commentaire": ["fonction", "network #1", "vlan", "application", "rôle", "role", "description", "annotation", "commentaire", "comment", "remarque"],
    "etat": ["powerstate", "power state", "état", "etat", "statut", "status"],
}
CHAMPS_VLAN = {
    "numero": ["n° vlan", "numéro de vlan", "numero de vlan", "vlan id", "id vlan", "numéro", "numero", "n°", "id"],
    "nom": ["nom du vlan", "libellé", "libelle", "nom", "name", "vlan"],
    "plages": ["plage", "plages", "sous-réseau", "sous-reseau", "subnet", "cidr", "réseau ip", "adresse réseau", "réseau", "reseau", "network", "ip"],
    "contenu": ["contenu", "description", "usage", "fonction", "détail", "detail"],
    "decision": ["décision", "decision", "à scanner", "a scanner", "action", "scan"],
    "site": ["site", "établissement", "etablissement"],
    "commentaire": ["commentaire", "comment", "remarque", "observation"],
}


def detecter_colonnes(entetes, champs):
    """Associe chaque champ à l'index de colonne dont l'en-tête correspond le mieux (égalité d'abord, puis inclusion).
    Une colonne n'est attribuée qu'une fois."""
    norm = [e.strip().lower() for e in entetes]
    pris, res = set(), {}
    for champ, syn in champs.items():
        trouve = None
        for n in syn:
            for i, e in enumerate(norm):
                if i not in pris and e == n:
                    trouve = i; break
            if trouve is not None:
                break
        if trouve is None:
            for n in syn:
                for i, e in enumerate(norm):
                    if i not in pris and (n in e if len(n) > 2 else re.search(r"(^|[^a-z])" + re.escape(n) + r"([^a-z]|$)", e)):
                        trouve = i; break
                if trouve is not None:
                    break
        if trouve is not None:
            res[champ] = trouve
            pris.add(trouve)
    return res


def apercu_import(texte, champs):
    entetes, lignes, a_entete = lire_tableau(texte)
    det = detecter_colonnes(entetes, champs) if a_entete else {}
    if "ip" in champs and "ip" not in det:
        # pas d'en-tête reconnu : la colonne qui contient le plus d'adresses IP
        scores = [sum(1 for l in lignes[:200] if i < len(l) and RE_IP.search(l[i])) for i in range(len(entetes))]
        if scores and max(scores) > 0:
            det["ip"] = scores.index(max(scores))
    if "plages" in champs and "plages" not in det:
        scores = [sum(1 for l in lignes[:200] if i < len(l) and RE_IP.search(l[i])) for i in range(len(entetes))]
        if scores and max(scores) > 0:
            det["plages"] = scores.index(max(scores))
    return {"entetes": entetes, "detection": det, "exemples": lignes[:5], "nb_lignes": len(lignes),
            "champs": list(champs)}


def corbeille(chemin, nom):
    """Copie une liste (VLAN, serveurs) dans donnees/corbeille avant de la vider ou de la remplacer."""
    contenu = lire_json(chemin, [])
    if not contenu:
        return ""
    dossier = os.path.join(DATA, "corbeille")
    os.makedirs(dossier, exist_ok=True)
    f = os.path.join(dossier, f"{nom}_{datetime.now():%Y%m%d_%H%M%S}.json")
    with open(f, "w", encoding="utf-8") as h:
        json.dump(contenu, h, ensure_ascii=False, indent=1)
    return f


def importer_vlans_tableau(texte, mapping=None, remplacer=False):
    entetes, lignes, _ = lire_tableau(texte)
    m = {k: int(v) for k, v in (mapping or apercu_import(texte, CHAMPS_VLAN)["detection"]).items() if v not in (None, "")}
    if ("nom" not in m and "numero" not in m) or "plages" not in m:
        raise ValueError("Colonnes « nom » (ou « numéro ») et « plages » obligatoires : les désigner dans l'aperçu")
    synon = {"p1": "P1", "priorité 1": "P1", "priorite 1": "P1", "scanner": "scanner", "oui": "scanner", "à scanner": "scanner",
             "a scanner": "scanner", "exclure": "exclure", "non": "exclure", "exclu": "exclure", "réserve": "reserve",
             "reserve": "reserve", "sous réserve": "reserve", "à décider": "a_decider", "a decider": "a_decider"}
    val = lambda l, c: l[m[c]].strip() if c in m and m[c] < len(l) else ""
    par_nom = {}
    for l in lignes:
        nom, num = val(l, "nom"), val(l, "numero")
        if num and nom and num not in nom:
            nom = f"VLAN {num} – {nom}"
        nom = nom or (f"VLAN {num}" if num else "")
        if not nom:
            continue
        pl = []
        for x in re.split(r"[,;\s]+", val(l, "plages")):
            if not x:
                continue
            try:
                pl.append(str(ipaddress.ip_network(x, strict=False)))
            except ValueError:
                pass
        v = par_nom.setdefault(nom, {"nom": nom[:80], "site": val(l, "site")[:40], "plages": [], "contenu": val(l, "contenu")[:1500],
                                     "decision": next((synon[k] for k in sorted(synon, key=len, reverse=True) if val(l, "decision").lower().startswith(k)), "a_decider"), "commentaire": val(l, "commentaire")[:1500]})
        v["plages"] += [x for x in pl if x not in v["plages"]]
    if not par_nom:
        raise ValueError("Aucun VLAN reconnu")
    if remplacer:
        corbeille(VLANS_PATH, "vlans")
    existants = [] if remplacer else charger_vlans()
    noms = {v["nom"].lower() for v in par_nom.values()}
    vlans = [v for v in existants if v["nom"].lower() not in noms]
    for i, v in enumerate(par_nom.values()):
        vlans.append(dict(v, cle=secrets.token_hex(4)))
    sauver_json(VLANS_PATH, vlans)
    return {"importes": len(par_nom), "total": len(vlans), "sans_plage": [v["nom"] for v in par_nom.values() if not v["plages"]]}


def importer_serveurs(texte, mapping=None, remplacer=False):
    """Import d'une liste de serveurs (RVTools, GLPI, plan d'adressage, Excel enregistré en CSV…).
    mapping = {champ: index de colonne} ; à défaut, détection automatique par les en-têtes."""
    entetes, lignes, a_entete = lire_tableau(texte)
    m = {k: int(v) for k, v in (mapping or apercu_import(texte, CHAMPS_SERVEUR)["detection"]).items() if v not in (None, "")}
    if "ip" not in m:
        raise ValueError("Aucune colonne d'adresses IP reconnue : la désigner dans l'aperçu")
    val = lambda l, c: l[m[c]].strip() if c in m and m[c] < len(l) else ""
    anciens = {x["ip"]: x for x in lire_json(SERVEURS_PATH, [])}
    if remplacer:
        corbeille(SERVEURS_PATH, "serveurs")
    serveurs = [] if remplacer else list(anciens.values())
    index = {x["ip"]: x for x in serveurs}
    ajoutes = maj = eteints = 0
    sans_ip = []
    for l in lignes:
        if val(l, "etat").lower() in ("poweredoff", "off", "arrêté", "arrete", "suspended", "éteint", "eteint"):
            eteints += 1
            continue
        ips = [x for x in RE_IP.findall(val(l, "ip")) if not x.startswith(("169.254.", "0."))]
        if not ips:
            sans_ip.append(val(l, "nom") or ";".join(l)[:60])
            continue
        for ip in ips:          # « 192.0.2.7 + 192.0.2.8 » -> deux serveurs
            try:
                ipaddress.ip_address(ip)
            except ValueError:
                sans_ip.append(ip)
                continue
            x = {"ip": ip, "nom": val(l, "nom"), "os": val(l, "os"), "site": val(l, "site"),
                 "commentaire": val(l, "commentaire")[:200], "importe": datetime.now().isoformat(timespec="minutes")}
            if ip in index:
                index[ip].update({k: v for k, v in x.items() if v})
                maj += 1
            else:
                if remplacer and ip in anciens and anciens[ip].get("systeme_force"):
                    x["systeme_force"] = anciens[ip]["systeme_force"]
                serveurs.append(x)
                index[ip] = x
                ajoutes += 1
    serveurs.sort(key=lambda x: ipaddress.ip_address(x["ip"]))
    sauver_json(SERVEURS_PATH, serveurs)
    autorisees = parse_reseaux(CONFIG["plages_autorisees"])
    hors = [x["ip"] for x in serveurs if not dans_autorisees(ipaddress.ip_network(x["ip"]), autorisees)]
    return {"ajoutes": ajoutes, "mis_a_jour": maj, "ignores": sans_ip[:10], "nb_ignores": len(sans_ip),
            "eteints": eteints, "hors_plage": hors, "total": len(serveurs)}


RE_LINUX = re.compile(r"linux|debian|ubuntu|red ?hat|rhel|centos|alma|rocky|suse|sles|oracle ?linux|fedora|photon|amazon", re.I)
RE_WINDOWS = re.compile(r"windows|microsoft|win20|win ?srv", re.I)


def systeme_de(os_txt):
    """'linux', 'windows' ou '' d'après la colonne OS (texte libre de RVTools, GLPI, saisie…)."""
    if RE_WINDOWS.search(os_txt or ""):
        return "windows"
    if RE_LINUX.search(os_txt or ""):
        return "linux"
    return ""


def serveur_exclu(ip):
    """Adresse couverte par une exclusion permanente (VLAN « Exclure » compris) : jamais interrogée, même par le scan hôtes."""
    try:
        return dans_autorisees(ipaddress.ip_network(ip), parse_reseaux(CONFIG["exclusions"]))
    except ValueError:
        return False


def compte_ssh_planifie():
    """Compte SSH du cycle planifié : variable d'environnement INVENTAIRE_PHP_COMPTE_SSH du poste, sinon le compte de la
    session. Jamais enregistré par l'outil."""
    return os.environ.get("INVENTAIRE_PHP_COMPTE_SSH", "").strip()


def serveurs_annotes():
    autorisees = parse_reseaux(CONFIG["plages_autorisees"])
    php_vu = {}
    try:
        for r in services_cumules():
            if r.get("php_detecte") in ("oui", "faible"):
                php_vu[r["ip"]] = r.get("classe", "")
    except Exception:  # noqa - le bilan ne doit jamais bloquer la liste
        pass
    out = []
    for s in lire_json(SERVEURS_PATH, []):
        s = dict(s)
        s["autorise"] = dans_autorisees(ipaddress.ip_network(s["ip"]), autorisees)
        s["systeme"] = s.get("systeme_force") or systeme_de(s.get("os", ""))
        s["php_vu"] = php_vu.get(s["ip"], "")
        out.append(s)
    return out


# ---------------------------------------------------------------------------
# Noms d'hôtes (v2.0) : import DNS / proxys / listes, résolution, sonde par nom
# ---------------------------------------------------------------------------
RE_NOM = re.compile(r"\b((?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{1,62}|[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)\b", re.I)
MOTS_EXCLUS = {"in", "a", "aaaa", "cname", "ns", "mx", "soa", "txt", "ptr", "srv", "servername", "serveralias", "server_name",
               "listen", "include", "localhost", "localhost.localdomain", "www", "http", "https", "on", "off", "yes", "no"}


def extraire_noms(texte):
    """Extrait des noms d'hôtes d'un export de zone DNS (BIND, dnscmd), d'une configuration Apache/nginx/HAProxy
    ou d'une liste simple (un nom par ligne, ou CSV avec colonne nom/fqdn/host). Les noms courts d'une zone
    reçoivent le $ORIGIN courant."""
    noms = []
    vus = set()
    origine = ""
    for ligne in texte.splitlines():
        l = ligne.strip()
        mo = re.match(r"^\$ORIGIN\s+([A-Za-z0-9._-]+)", l, re.I)
        if mo:
            origine = mo.group(1).rstrip(".").lower()
            continue
        if not l or l.startswith((";", "#", "//", "$")):
            continue
        m = re.match(r"^([A-Za-z0-9._-]+)\s+(?:\d+\s+)?(?:IN\s+)?(A|AAAA|CNAME)\s+", l, re.I)
        mv = re.search(r"\b(ServerName|ServerAlias|server_name)\s+([^;{}]+)", l)
        if m:
            cand = [m.group(1)]
            if origine and "." not in cand[0] and cand[0] != "@":
                cand = [cand[0] + "." + origine]
        elif mv:
            cand = re.split(r"\s+", mv.group(2).strip())
        elif re.search(r"\b(hdr\(host\)|req\.hdr\(host\))\b", l):
            cand = RE_NOM.findall(l)
        else:
            cand = [x.strip() for x in re.split(r"[;,\t]", l)] if ("." in l or ";" in l or "," in l) else [l]
        for c in cand:
            c = c.strip().strip("\"'").rstrip(".").lower()
            if not c or c in MOTS_EXCLUS or c.startswith(("*", "@")) or "/" in c or " " in c:
                continue
            if RE_IP.fullmatch(c) or not RE_NOM.fullmatch(c) or c.isdigit():
                continue
            if c not in vus:
                vus.add(c)
                noms.append(c)
    return noms


def resoudre(nom):
    try:
        ips = sorted({i[4][0] for i in socket.getaddrinfo(nom, None, socket.AF_INET)})
        return ips[0] if ips else ""
    except (socket.gaierror, OSError, UnicodeError):
        return ""


def importer_noms(texte, source, remplacer=False):
    noms = extraire_noms(texte)
    if not noms:
        raise ValueError("Aucun nom d'hôte reconnu dans ce fichier")
    autorisees = parse_reseaux(CONFIG["plages_autorisees"])
    if remplacer:
        corbeille(NOMS_PATH, "noms")
    existants = {} if remplacer else {x["nom"]: x for x in lire_json(NOMS_PATH, [])}
    with ThreadPoolExecutor(max_workers=20) as ex:
        ips = list(ex.map(resoudre, noms))
    dans, hors, nonres = 0, 0, 0
    for nom, ip in zip(noms, ips):
        etat = "non résolu" if not ip else ("dans le périmètre" if dans_autorisees(ipaddress.ip_network(ip), autorisees) else "hors périmètre")
        dans += etat == "dans le périmètre"; hors += etat == "hors périmètre"; nonres += etat == "non résolu"
        existants[nom] = {"nom": nom, "ip": ip, "etat": etat, "site": existants.get(nom, {}).get("site", "") or site_de(ip),
                          "source": source, "importe": datetime.now().isoformat(timespec="minutes")}
    sauver_json(NOMS_PATH, sorted(existants.values(), key=lambda x: x["nom"]))
    return {"reconnus": len(noms), "dans_perimetre": dans, "hors_perimetre": hors, "non_resolus": nonres, "total": len(existants)}


# ---------------------------------------------------------------------------
# Scan réseau : nmap (ou moteur Python de secours) + sonde HTTP
# ---------------------------------------------------------------------------
def estimer(cibles, exclusions, ports, debit):
    """Nombre d'adresses et durée indicative avant lancement (ordre de grandeur, pas une promesse)."""
    nb = 0
    for c in cibles:
        n = c.num_addresses if c.num_addresses <= 2 else c.num_addresses - 2
        for e in exclusions:
            if e.version == c.version and e.subnet_of(c):
                n -= e.num_addresses
            elif e.version == c.version and c.subnet_of(e):
                n = 0
        nb += max(0, n)
    nb_ports = 0
    for part in ports.split(","):
        if "-" in part:
            a, b = part.split("-")
            nb_ports += int(b) - int(a) + 1
        elif part:
            nb_ports += 1
    # découverte ~1 paquet/hôte puis scan ~nb_ports paquets/hôte joignable (hypothèse 20 % joignables), + marge
    paquets = nb * 1.0 + nb * 0.2 * nb_ports
    secondes = int(paquets / max(20, debit) * 1.4) + 15
    return {"adresses": nb, "ports": nb_ports, "secondes": secondes}


def adresses_a_tester(cibles, exclusions):
    """Énumération cohérente : /32 -> 1 adresse, /31 -> 2, /30 et plus larges -> hôtes utilisables ; exclusions retirées."""
    out = []
    for c in cibles:
        it = list(c) if c.num_addresses <= 2 else c.hosts()
        for a in it:
            if not any(e.version == a.version and a in e for e in exclusions):
                out.append(str(a))
    return out


def scan_python(cibles, exclusions, ports, debit, connexions=None):
    """Moteur de secours sans nmap : connexions TCP directes.
    connexions = nombre maximal de connexions simultanées (CONFIG py_connexions, 16 par défaut, plafond 64) ;
    debit = rythme maximal de tentatives par seconde, imposé par un limiteur partagé."""
    liste_ports = []
    for part in ports.split(","):
        if "-" in part:
            a, b = part.split("-")
            liste_ports += list(range(int(a), int(b) + 1))
        elif part:
            liste_ports.append(int(part))
    adresses = adresses_a_tester(cibles, exclusions)
    total = len(adresses) * len(liste_ports)
    connexions = max(1, min(64, int(connexions or CONFIG.get("py_connexions", 16))))
    with VERROU:
        ETAT.update({"adresses_total": len(adresses), "adresses_vues": 0, "courant_lib": "En cours"})
    journal(ETAT, f"Moteur Python : {len(adresses)} adresse(s) × {len(liste_ports)} port(s) = {total} tentatives, {connexions} connexions simultanées, {debit} tentatives/s max")
    with VERROU:
        ETAT["nmap_pourcent"] = 0.0
    services = []
    fait = [0]
    verrou = threading.Lock()
    prochain = [time.monotonic()]
    intervalle = 1.0 / max(1, debit)

    def attendre_slot():
        with verrou:
            t = max(prochain[0], time.monotonic())
            prochain[0] = t + intervalle
        delai = t - time.monotonic()
        if delai > 0:
            time.sleep(delai)

    def tester(ipport):
        if ETAT["stop"]:
            return None
        attendre_slot()
        if ETAT["stop"]:
            return None
        ip, port = ipport
        if port == liste_ports[0]:
            fil(ETAT, f"{ip}  test des ports web…", ip)
        try:
            with socket.create_connection((ip, port), timeout=0.8):
                ok = True
        except OSError:
            ok = False
        if ok:
            fil(ETAT, f"{ip}:{port}  port ouvert")
        with verrou:
            fait[0] += 1
            if fait[0] % 20 == 0 or fait[0] == total:
                with VERROU:
                    ETAT["nmap_pourcent"] = round(100 * fait[0] / max(1, total), 1)
                    ETAT["pourcent"] = round(70 * fait[0] / max(1, total), 1)
                    ETAT["restant"] = int((total - fait[0]) * intervalle)
                    ETAT["adresses_vues"] = fait[0] // max(1, len(liste_ports))
        return (ip, port) if ok else None

    with ThreadPoolExecutor(max_workers=connexions) as ex:
        for r in ex.map(tester, ((ip, p) for ip in adresses for p in liste_ports)):
            if r:
                services.append(r)
    return services


def npcap_present():
    if platform.system() != "Windows":
        return True
    return (os.path.isdir(os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "Npcap"))
            or os.path.isdir(r"C:\Program Files\Npcap"))


def nmap_utilisable():
    """nmap trouvé ET, sous Windows, Npcap installé (sans Npcap, nmap ne peut pas émettre ses sondes)."""
    return bool(shutil.which("nmap")) and npcap_present()


def scan_nmap(cibles, exclusions, ports, debit):
    moteur = CONFIG.get("moteur", "auto")
    if moteur == "python" or (moteur == "auto" and not nmap_utilisable()):
        if moteur == "auto":
            cause = "nmap absent" if not shutil.which("nmap") else "nmap présent mais Npcap absent"
            journal(ETAT, f"{cause} : bascule sur le moteur Python")
            with VERROU:
                ETAT["avertissements"].append(f"{cause}, moteur Python utilisé")
        with VERROU:
            ETAT["moteur_utilise"] = "python"
        return scan_python(cibles, exclusions, ports, debit)
    with VERROU:
        ETAT["moteur_utilise"] = "nmap"
    cmd = ["nmap", "-n", "--open", "-p", ports, "-PS80,443,8080,8443", "-PE", "-T3",
           "--max-rate", str(debit), "--max-retries", "2", "--host-timeout", "5m", "--stats-every", "3s", "-oX", "-"]
    fexcl = None
    if exclusions:
        fexcl = tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False)
        fexcl.write("\n".join(str(e) for e in exclusions) + "\n")
        fexcl.close()
        cmd += ["--excludefile", fexcl.name]
    cmd += [str(c) for c in cibles]
    journal(ETAT, "nmap : " + " ".join(cmd))
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    except FileNotFoundError:
        raise RuntimeError("nmap introuvable dans le PATH : installer nmap sur ce poste (https://nmap.org)")
    with VERROU:
        ETAT["proc"] = proc
    lignes = []
    hote_xml = ""
    # nmap traite la plage par lots (4096 adresses au plus) ; ses pourcentages portent sur le lot en cours.
    # Progression globale = adresses des lots terminés + part du lot en cours, rapportées au total prévu.
    total = max(1, estimer(cibles, exclusions, ports, debit)["adresses"])
    faits, lot, actifs_lot, t0 = 0, None, 0, time.time()
    with VERROU:
        ETAT.update({"adresses_total": total, "adresses_vues": 0, "courant_lib": "Dernier hôte actif trouvé"})

    def avancer(vues):
        g = min(1.0, vues / total)
        ecoule = time.time() - t0
        with VERROU:
            ETAT["adresses_vues"] = int(vues)
            ETAT["nmap_pourcent"] = round(100 * g, 1)
            ETAT["pourcent"] = round(70 * g, 1)
            ETAT["restant"] = int(ecoule * (1 - g) / g) if g >= 0.02 else None
    for ligne in proc.stdout:
        lignes.append(ligne)
        ma = re.search(r'<address addr="([^"]+)" addrtype="ipv4"', ligne)
        if ma:
            hote_xml = ma.group(1)
            actifs_lot += 1
            fil(ETAT, f"{hote_xml}  hôte actif", hote_xml)
        mp = re.search(r'<port protocol="tcp" portid="(\d+)"><state state="open"', ligne)
        if mp and hote_xml:
            fil(ETAT, f"{hote_xml}:{mp.group(1)}  port ouvert")
        mt = re.search(r'<taskprogress[^>]*task="([^"]*)"[^>]*percent="([\d.]+)"', ligne)
        if mt and "Ping" in mt.group(1):
            taille = min(lot or 4096, total - faits) if total > faits else 1
            avancer(faits + float(mt.group(2)) / 100 * taille)
            fil(ETAT, f"nmap : recherche des machines actives — {int(faits + float(mt.group(2)) / 100 * taille)} / {total} adresses")
        elif mt:
            fil(ETAT, f"nmap : test des ports web des machines actives du lot — {float(mt.group(2)):.0f} %")
        me = re.search(r'<taskend task="Ping Scan"[^>]*extrainfo="(\d+) total hosts"', ligne)
        if me:
            lot = int(me.group(1))
            faits += lot
            avancer(faits)
            journal(ETAT, f"nmap : lot de {lot} adresses examiné ({faits} / {total})")
            fil(ETAT, f"nmap : lot de {lot} adresses examiné — {faits} / {total} au total")
        if "</host>" in ligne and actifs_lot and "<runstats" in ligne:
            actifs_lot = 0
    err = proc.stderr.read()
    proc.wait()
    out = "".join(lignes)
    with VERROU:
        ETAT["proc"] = None
    if fexcl:
        os.unlink(fexcl.name)
    if proc.returncode not in (0, None) and not out.strip():
        raise RuntimeError(f"nmap a échoué (code {proc.returncode}) : {err.strip()[:300]}")
    services = []
    try:
        root = ET.fromstring(out)
    except ET.ParseError:
        if ETAT["stop"]:
            return services
        raise RuntimeError("Sortie nmap illisible")
    for host in root.iter("host"):
        addr = host.find("address")
        if addr is None:
            continue
        for p in host.iter("port"):
            st = p.find("state")
            if st is not None and st.get("state") == "open":
                services.append((addr.get("addr"), int(p.get("portid"))))
    return services


_CTX_NV = ssl.create_default_context()
_CTX_NV.check_hostname = False
_CTX_NV.verify_mode = ssl.CERT_NONE


def contexte_verifie():
    ctx = ssl.create_default_context()
    ca = CONFIG.get("ca_interne", "")
    if ca and os.path.exists(ca):
        try:
            ctx.load_verify_locations(ca)
        except (ssl.SSLError, OSError):
            pass
    return ctx


class _HTTPSVersIP(http.client.HTTPSConnection):
    """Connexion TCP vers une IP déjà validée ; SNI et vérification du certificat sur le nom applicatif."""
    def __init__(self, ip, port, sni, ctx, timeout):
        super().__init__(ip, port, timeout=timeout, context=ctx)
        self._ip, self._sni, self._ctx = ip, sni, ctx

    def connect(self):
        sock = socket.create_connection((self._ip, self.port), self.timeout)
        self.sock = self._ctx.wrap_socket(sock, server_hostname=self._sni or self._ip)


class EchecTLS(Exception):
    pass


def http_get(scheme, ip, port, chemin="/", hote=None, tls_verifier=True):
    """UNE requête GET vers l'IP donnée (aucune résolution DNS ici) ; Host = hote, SNI = hote.
    Retourne (code, en-têtes, corps, tls) avec tls dans {'', 'vérifié', 'non vérifié'}.
    Lève OSError si le service ne répond pas, EchecTLS si la poignée de main échoue même sans vérification."""
    hote_entete = hote or ip
    if port not in (80, 443):
        hote_entete = f"{hote_entete}:{port}"
    entetes = {"User-Agent": USER_AGENT, "Host": hote_entete, "Connection": "close", "Accept": "*/*"}
    sni = hote if hote and not RE_IP.fullmatch(hote) else None
    if scheme == "https":
        verif = tls_verifier and CONFIG.get("tls_verifier", True)
        tentatives = ([("vérifié", contexte_verifie())] if verif else []) + [("non vérifié", _CTX_NV)]
        derniere = None
        for etiquette, ctx in tentatives:
            conn = _HTTPSVersIP(ip, port, sni, ctx, TIMEOUT_HTTP)
            try:
                conn.request("GET", chemin, headers=entetes)
                r = conn.getresponse()
                corps = r.read(200000).decode("utf-8", "ignore")
                conn.close()
                return r.status, r.msg, corps, etiquette
            except ssl.SSLError as e:
                derniere = e
                conn.close()
                continue
            except OSError:
                conn.close()
                raise
        raise EchecTLS(str(derniere)[:120])
    conn = http.client.HTTPConnection(ip, port, timeout=TIMEOUT_HTTP)
    try:
        conn.request("GET", chemin, headers=entetes)
        r = conn.getresponse()
        corps = r.read(200000).decode("utf-8", "ignore")
        return r.status, r.msg, corps, ""
    finally:
        conn.close()


def resoudre_dans_perimetre(hote, autorisees, exclusions):
    """Résout un nom (ou accepte une IP) et renvoie l'IP à contacter si, et seulement si, TOUTES ses adresses
    sont dans les plages autorisées et hors exclusions ; sinon ''. Aucune seconde résolution n'a lieu ensuite."""
    try:
        if RE_IP.fullmatch(hote):
            ips = [hote]
        else:
            ips = sorted({i[4][0] for i in socket.getaddrinfo(hote, None, socket.AF_INET)})
    except (socket.gaierror, OSError, UnicodeError, ValueError):
        return ""
    if not ips:
        return ""
    for ip in ips:
        r = ipaddress.ip_network(ip)
        if not dans_autorisees(r, autorisees) or any(e.version == r.version and r.subnet_of(e) for e in exclusions):
            return ""
    return ips[0]


def http_get_perimetre(scheme, ip, port, hote, autorisees, exclusions, max_sauts=3):
    """GET puis suivi d'au plus max_sauts redirections, chacune résolue et validée AVANT connexion ; la connexion
    va vers l'IP validée. Changements de protocole et de port contrôlés comme le reste.
    Retourne (url_finale, code, en-têtes, corps, chaine, hors, tls)."""
    chaine, chemin = [], "/"
    for _ in range(max_sauts + 1):
        code, h, corps, tls = http_get(scheme, ip, port, chemin, hote)
        url = f"{scheme}://{hote or ip}:{port}{chemin}"
        loc = h.get("Location") if h else None
        if code in (301, 302, 303, 307, 308) and loc:
            cible = urllib.parse.urljoin(url, loc)
            u = urllib.parse.urlparse(cible)
            if u.scheme not in ("http", "https") or not u.hostname:
                chaine.append(cible[:120])
                return url, code, h, corps, chaine, True, tls
            port_c = u.port or (443 if u.scheme == "https" else 80)
            ip_c = resoudre_dans_perimetre(u.hostname, autorisees, exclusions)
            chaine.append(f"{u.scheme}://{u.hostname}:{port_c}")
            if not ip_c:
                return url, code, h, corps, chaine, True, tls
            scheme, ip, port = u.scheme, ip_c, port_c
            hote = None if RE_IP.fullmatch(u.hostname) else u.hostname
            chemin = (u.path or "/") + (f"?{u.query}" if u.query else "")
            continue
        return url, code, h, corps, chaine, False, tls
    return url, code, h, corps, chaine, False, tls


def analyser(ip, port, noms, autorisees, exclusions, hote=None):
    """Sonde un service. La connexion va TOUJOURS vers ip (validée en amont) ; hote sert d'en-tête Host et de SNI."""
    schemes = ["https"] if port in (443, 8443, 9443, 10000) else ["http", "https"]
    base_res = {"ip": ip, "port": port, "nom": hote or noms.get(ip, ""), "vhost": bool(hote), "url": "", "titre": "", "server": "",
                "x_powered_by": "", "php_detecte": "?", "version_php": "", "source_version": "", "tls": "",
                "statut": "PAS DE REPONSE HTTP", "classe": "neutre", "indices": "", "redirection": ""}
    r_ip = ipaddress.ip_network(ip)
    if not dans_autorisees(r_ip, autorisees) or any(e.version == r_ip.version and r_ip.subnet_of(e) for e in exclusions):
        base_res["statut"] = "HORS PERIMETRE - non sondé"
        return base_res
    echec_tls = ""
    for scheme in schemes:
        if ETAT["stop"]:
            break
        try:
            url, code, h, corps, chaine, hors, tls = http_get_perimetre(scheme, ip, port, hote, autorisees, exclusions)
        except EchecTLS as e:
            echec_tls = str(e)
            continue
        except (OSError, ValueError, http.client.HTTPException):
            continue
        server = h.get("Server", "") or ""
        powered = h.get("X-Powered-By", "") or ""
        cookies = " ".join(h.get_all("Set-Cookie") or [])
        forts, faibles = [], []
        if "php" in powered.lower():
            forts.append(f"X-Powered-By={powered}")
        if "php" in server.lower():
            forts.append(f"Server={server}")
        if "phpsessid" in cookies.lower():
            forts.append("cookie PHPSESSID")
        if any(c.lower().endswith(".php") or ".php?" in c.lower() for c in chaine) or url.lower().endswith(".php") or ".php?" in url.lower():
            forts.append("redirection vers une page .php")
        bas = corps.lower()
        if "/wp-content/" in bas or "/wp-includes/" in bas:
            faibles.append("traces WordPress")
        if re.search(r'(href|src|action)=["\'][^"\']*\.php', bas):
            faibles.append("liens *.php dans la page")
        if h.get("X-Pingback"):
            faibles.append("en-tête X-Pingback")
        try:
            c_idx, _, _, _ = http_get(scheme, ip, port, "/index.php", hote)
            c_rnd, _, _, _ = http_get(scheme, ip, port, "/zz_inexistant_8f3k2.php", hote)
            if c_idx == 200 and c_rnd == 404:
                faibles.append("/index.php répond 200 (chemin aléatoire 404)")
        except (OSError, ValueError, EchecTLS, http.client.HTTPException):
            pass
        detecte = "oui" if (forts or len(faibles) >= 2) else ("faible" if faibles else "non")
        m = re.search(r"PHP/(\d+\.\d+\.\d+)", server + " " + powered)
        version = m.group(1) if m else ""
        mt = re.search(r"<title[^>]*>(.*?)</title>", corps, re.I | re.S)
        titre = re.sub(r"\s+", " ", mt.group(1)).strip()[:80] if mt else ""
        statut = evaluer(version, "banniere", detecte == "oui")
        if detecte == "faible" and not version:
            statut = "A VERIFIER (indice PHP faible)"
        redir = ""
        if chaine:
            redir = " -> ".join(chaine) + (" [HORS PÉRIMÈTRE, non suivie]" if hors else "")
        indices = [f"[fort] {x}" for x in forts] + [f"[faible] {x}" for x in faibles]
        if hors:
            indices.append("[info] redirection hors périmètre ou exclue, non suivie")
        if hote:
            indices.append(f"[info] connexion vers {ip}, Host/SNI {hote}")
        if tls == "non vérifié":
            indices.append("[info] certificat TLS non vérifié : identité du serveur non authentifiée")
        base_res.update({"url": url, "titre": titre, "server": server, "x_powered_by": powered,
                         "php_detecte": detecte, "version_php": version,
                         "source_version": "bannière HTTP" if version else "", "tls": tls,
                         "statut": statut, "classe": classe_statut(statut), "indices": " | ".join(indices),
                         "redirection": redir})
        return base_res
    if echec_tls:
        base_res["statut"] = "ECHEC TLS (poignée de main impossible, service présent)"
        base_res["indices"] = f"[info] {echec_tls}"
    return base_res


def lancer_scan(params):
    scan_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    with VERROU:
        ETAT.update({"en_cours": True, "phase": "nmap", "fait": 0, "total": 0, "journal": [],
                     "scan_id": scan_id, "erreur": None, "stop": False, "pourcent": 0.0, "restant": None,
                     "debut": time.time(), "nmap_pourcent": 0.0, "moteur_utilise": "", "avertissements": [],
                     "fil": [], "courant": "", "courant_lib": "En cours", "adresses_total": 0, "adresses_vues": 0})
    resultats = []
    try:
        cibles, exclusions = params["cibles"], params["exclusions"]
        srvs = lire_json(SERVEURS_PATH, [])
        noms = {s["ip"]: s["nom"] for s in srvs}
        sites = {s["ip"]: s.get("site", "") for s in srvs}
        autorisees = parse_reseaux(CONFIG["plages_autorisees"])
        journal(ETAT, f"Scan {scan_id} — {len(cibles)} cible(s)")
        if exclusions:
            journal(ETAT, f"Exclusions : {', '.join(map(str, exclusions))}")
        services = scan_nmap(cibles, exclusions, params["ports"], params["debit"])
        journal(ETAT, f"{len(services)} service(s) web ouvert(s)")
        # sondes par nom : chaque nom résolu vers une IP ayant un port ouvert est sondé avec son Host/SNI
        taches = [(ip, port, None) for ip, port in services]
        ips_ouvertes = {}
        for ip, port in services:
            ips_ouvertes.setdefault(ip, []).append(port)
        nb_noms = 0
        for n in lire_json(NOMS_PATH, []):
            if n["etat"] == "dans le périmètre" and n["ip"] in ips_ouvertes:
                for port in ips_ouvertes[n["ip"]]:
                    taches.append((n["ip"], port, n["nom"]))
                    nb_noms += 1
        if nb_noms:
            journal(ETAT, f"{nb_noms} sonde(s) supplémentaire(s) par nom d'hôte (vhosts)")
        with VERROU:
            ETAT["phase"], ETAT["total"], ETAT["pourcent"], ETAT["restant"] = "http", len(taches), 70.0, None
        fil(ETAT, f"Analyse HTTP de {len(taches)} service(s)")
        with ThreadPoolExecutor(max_workers=params["threads"]) as ex:
            for res in ex.map(lambda s: analyser(s[0], s[1], noms, autorisees, exclusions, s[2]), taches):
                res["site"] = sites.get(res["ip"], "")
                resultats.append(res)
                fil(ETAT, f"{res['ip']}:{res['port']}{' ' + res['nom'] if res.get('vhost') else ''}  " +
                    (f"PHP {res['version_php'] or '?'} — {res['statut']}" if res["php_detecte"] in ("oui", "faible") else res["statut"])[:110],
                    f"{res['ip']}:{res['port']}")
                with VERROU:
                    ETAT["fait"] += 1
                    ETAT["pourcent"] = round(70 + 30 * ETAT["fait"] / max(1, ETAT["total"]), 1)
                    ETAT["restant"] = None
                if res["php_detecte"] in ("oui", "faible"):
                    journal(ETAT, f"PHP {res['ip']}:{res['port']} {res['version_php'] or 'version ?'} -> {res['statut']}")
        ordre = {"vuln": 0, "verif": 1, "ok": 2, "neutre": 3}
        resultats.sort(key=lambda r: (ordre[r["classe"]], ipaddress.ip_address(r["ip"]), r["port"], r.get("nom", "")))
        est = estimer(cibles, exclusions, params["ports"], params["debit"])
        refus = sum(1 for r in resultats if "HORS PÉRIMÈTRE" in r.get("redirection", ""))
        if refus:
            journal(ETAT, f"{refus} redirection(s) refusée(s) (hors périmètre ou exclue)")
        sauver_json(os.path.join(RESULTATS, f"scan_{scan_id}.json"), {
            "id": scan_id, "date": datetime.now().isoformat(timespec="seconds"), "version": VERSION,
            "debut": datetime.fromtimestamp(ETAT["debut"]).isoformat(timespec="seconds"),
            "fin": datetime.now().isoformat(timespec="seconds"),
            "cibles": [str(c) for c in cibles], "exclusions": [str(e) for e in exclusions],
            "sites": sorted({sites.get(r["ip"], "") for r in resultats} - {""}),
            "ports": params["ports"], "debit": params["debit"], "moteur": ETAT.get("moteur_utilise", ""),
            "connexions_py": CONFIG.get("py_connexions", 16), "threads_http": params["threads"],
            "adresses_prevues": est["adresses"], "services_interroges": len(taches),
            "sans_reponse": sum(1 for r in resultats if r["statut"] == "PAS DE REPONSE HTTP"),
            "echecs_tls": sum(1 for r in resultats if r["statut"].startswith("ECHEC TLS")),
            "tls_non_verifie": sum(1 for r in resultats if r.get("tls") == "non vérifié"),
            "redirections_refusees": refus,
            "etat": "interrompu" if ETAT["stop"] else "terminé",
            "interrompu": ETAT["stop"], "avertissements": list(ETAT.get("avertissements", [])), "resultats": resultats})
        with VERROU:
            ETAT["pourcent"] = 100.0
        journal(ETAT, "Scan terminé" + (" (interrompu)" if ETAT["stop"] else ""))
    except Exception as e:  # noqa
        with VERROU:
            ETAT["erreur"] = str(e)
        journal(ETAT, "ERREUR : " + str(e))
        try:
            sauver_json(os.path.join(RESULTATS, f"scan_{scan_id}.json"), {
                "id": scan_id, "date": datetime.now().isoformat(timespec="seconds"), "version": VERSION,
                "cibles": [str(c) for c in params["cibles"]], "exclusions": [str(e_) for e_ in params["exclusions"]],
                "ports": params["ports"], "debit": params["debit"], "etat": "échoué", "interrompu": False,
                "erreur": str(e), "resultats": resultats})
        except Exception:  # noqa
            pass
    finally:
        with VERROU:
            ETAT["en_cours"], ETAT["phase"] = False, "inactif"


def appliquer_retention():
    """Supprime les scans plus anciens que retention_jours (0 = conservation illimitée). Jamais le dernier scan."""
    jours = int(CONFIG.get("retention_jours", 365) or 0)
    if jours <= 0 or not os.path.isdir(RESULTATS):
        return 0
    limite = time.time() - jours * 86400
    fichiers = sorted(f for f in os.listdir(RESULTATS) if f.startswith("scan_") and f.endswith(".json"))
    n = 0
    for f in fichiers[:-1]:
        chemin = os.path.join(RESULTATS, f)
        try:
            if os.path.getmtime(chemin) < limite:
                os.unlink(chemin)
                n += 1
        except OSError:
            pass
    return n


def sauvegarde_zip():
    """Archive zip de la configuration et du suivi (sans les scans, volumineux et reproductibles)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in ("config.json", "serveurs.json", "noms.json", "hotes.json", "suivi.json", "externes.json", "plan_action.json", "planification.log"):
            chemin = os.path.join(RESULTATS if f in ("hotes.json", "planification.log") else DATA, f)
            if os.path.exists(chemin):
                z.write(chemin, f)
        z.writestr("LISEZMOI.txt", f"{MENTION}\nSauvegarde Inventaire PHP v{VERSION} du {datetime.now():%Y-%m-%d %H:%M}\nRestaurer : copier ces fichiers dans le dossier de données puis relancer l'application.\n")
    return buf.getvalue()


def liste_scans():
    out = []
    if not os.path.isdir(RESULTATS):
        return out
    for fn in sorted(os.listdir(RESULTATS), reverse=True):
        if fn.startswith("scan_") and fn.endswith(".json"):
            d = lire_json(os.path.join(RESULTATS, fn), None)
            if not d:
                continue
            r = d.get("resultats", [])
            out.append({"id": d.get("id", fn[5:-5]), "date": d.get("date", ""), "cibles": d.get("cibles", []), "services": len(r),
                        "php": sum(1 for x in r if x.get("php_detecte") == "oui"),
                        "vuln": sum(1 for x in r if x.get("classe") == "vuln"),
                        "verif": sum(1 for x in r if x.get("classe") == "verif"), "interrompu": d.get("interrompu", False),
                        "etat": d.get("etat", "interrompu" if d.get("interrompu") else "terminé")})
    return out


def charger_scan(scan_id):
    if not re.fullmatch(r"\d{8}_\d{6}", scan_id or ""):
        return None
    return lire_json(os.path.join(RESULTATS, f"scan_{scan_id}.json"), None)


# ---------------------------------------------------------------------------
# Inventaire hôtes
# ---------------------------------------------------------------------------
SCRIPT_LINUX_DISTANT = r"""
SUDO=""; command -v sudo >/dev/null && sudo -n true 2>/dev/null && SUDO="sudo -n"
if command -v dpkg >/dev/null; then
  dpkg-query -W -f='${binary:Package}|${Version}|${Status}\n' 'php*' 'libapache2-mod-php*' 2>/dev/null | grep 'install ok installed' | while IFS='|' read -r p v s; do echo "paquet dpkg|$p|$v"; done
fi
if command -v rpm >/dev/null; then
  rpm -qa --qf '%{NAME}|%{VERSION}-%{RELEASE}\n' 'php*' 2>/dev/null | while IFS='|' read -r p v; do echo "paquet rpm|$p|$v"; done
fi
for b in $(ls /usr/bin/php* /usr/sbin/php-fpm* /usr/local/bin/php* /usr/local/sbin/php-fpm* /opt/*/bin/php /opt/remi/php*/root/usr/bin/php 2>/dev/null | sort -u); do
  [ -x "$b" ] || continue
  v=$("$b" -n -v 2>/dev/null | head -1 | awk '{print $2}')
  echo "binaire|$b|$v"
done
for rt in docker podman; do
  command -v $rt >/dev/null || continue
  $SUDO $rt ps --format '{{.Names}}|{{.Image}}' 2>/dev/null | while IFS='|' read -r n img; do
    v=$($SUDO $rt exec "$n" php -n -v 2>/dev/null | head -1 | awk '{print $2}')
    if [ -n "$v" ] || echo "$img" | grep -qiE 'php|wordpress|nextcloud|glpi|drupal|joomla|laravel|symfony'; then
      echo "conteneur $rt|$n ($img)|$v"
    fi
  done
done
# Moteurs PHP réellement actifs (processus php-fpm maîtres, module Apache) : seule base d'un "correctif confirmé"
for pid in $(pgrep -f 'php-fpm: master' 2>/dev/null; pgrep -x php-fpm 2>/dev/null); do
  exe=$($SUDO readlink -f /proc/$pid/exe 2>/dev/null); [ -n "$exe" ] || continue
  v=$("$exe" -n -v 2>/dev/null | head -1 | awk '{print $2}')
  echo "moteur actif php-fpm|$exe (pid $pid)|$v"
done | sort -u
for mod in $( (apache2ctl -M 2>/dev/null || httpd -M 2>/dev/null) | grep -oiE 'php[0-9._]*_module'); do
  so=$(ls /usr/lib/apache2/modules/libphp*.so /etc/httpd/modules/libphp*.so 2>/dev/null | head -1)
  v=""; for b in $(ls /usr/bin/php[0-9]* 2>/dev/null); do bv=$("$b" -n -v 2>/dev/null | head -1 | awk '{print $2}'); case "$mod" in *$(echo "$bv" | cut -d. -f1,2)*) v=$bv;; esac; done
  echo "moteur actif apache|$mod ${so:+($so)}|$v"
done
($SUDO ss -ltnp 2>/dev/null || $SUDO netstat -ltnp 2>/dev/null) | awk 'NR>1' | grep -E ':(80|81|443|8000|8080|8081|8443|8888|9000)\s' | sed -E 's/\s+/ /g' | while read -r l; do
  port=$(echo "$l" | grep -oE ':[0-9]+ ' | head -1 | tr -d ': ')
  proc=$(echo "$l" | grep -oE 'users:\(\("[^"]+"' | head -1 | cut -d'"' -f2)
  echo "ecoute :$port|${proc:-?}|"
done
ls /etc/apache2/sites-enabled /etc/httpd/conf.d /etc/nginx/sites-enabled /etc/nginx/conf.d 2>/dev/null | grep -vE '^/|^$|default' | sort -u | tr '\n' ' ' | sed 's/ $//' | xargs -r -I{} echo "vhosts|{}|"
"""

SCRIPT_WINDOWS = r"""
param([string[]]$Serveurs, [string]$Sortie = "inventaire_php_windows.csv", [int]$Parallele = 20, [switch]$Approfondi, [string]$Utilisateur)
# Compte facultatif : -Utilisateur DOMAINE\compte ; le mot de passe est lu dans la variable d'environnement INVPHP_MDP
# (transmise par l'application, jamais écrite sur disque) ou demandé à l'écran.
$Cred = $null
if ($Utilisateur) {
    if ($env:INVPHP_MDP) { $Cred = New-Object System.Management.Automation.PSCredential($Utilisateur, (ConvertTo-SecureString $env:INVPHP_MDP -AsPlainText -Force)); $env:INVPHP_MDP = $null }
    else { $Cred = Get-Credential -UserName $Utilisateur -Message "Compte d'administration des serveurs Windows" }
}
$OptCred = @{}; if ($Cred) { $OptCred.Credential = $Cred }
# Délais bornés par serveur : 15 s pour ouvrir la session WinRM, 5 min par opération ; aucune nouvelle tentative
$OptCred.SessionOption = New-PSSessionOption -OpenTimeout 15000 -OperationTimeout 300000
# -Serveurs "a,b" transmis par -File arrive en une seule chaîne : la découper
$Serveurs = @($Serveurs | ForEach-Object { $_ -split '[,; ]' } | Where-Object { $_ })
$VersionsCorrigees = @{ "8.5" = [version]"8.5.12"; "8.4" = [version]"8.4.27"; "8.3" = [version]"8.3.36"; "8.2" = [version]"8.2.35" }
function Evaluer([string]$v) {
    if (-not $v) { return "VERSION INCONNUE - verifier manuellement" }
    try { $ver = [version]$v } catch { return "version illisible ($v)" }
    $branche = "$($ver.Major).$($ver.Minor)"
    if ($ver -lt [version]"8.2.0") { return "VULNERABLE CONFIRME - branche $branche non maintenue, sans correctif : migrer" }
    if (-not $VersionsCorrigees.ContainsKey($branche)) { return "A VERIFIER (branche $branche hors referentiel)" }
    if ($ver -ge $VersionsCorrigees[$branche]) { return "CORRECTIF CONFIRME (version $v)" }
    return "VULNERABLE CONFIRME - $v < $($VersionsCorrigees[$branche]) : corriger"
}
if (-not $Serveurs) {
    # Jamais de cible devinée : la liste des serveurs vient de l'inventaire fourni (application ou paramètre -Serveurs)
    Write-Error "Aucun serveur indiqué (-Serveurs) : rien n'est interrogé."
    exit 2
}
Write-Host "[+] $($Serveurs.Count) serveurs"
$bloc = {
    param($Approfondi)
    $res = @(); $hote = $env:COMPUTERNAME
    # Par defaut : emplacements applicatifs connus uniquement (rapide, sans parcours des volumes de donnees)
    $racines = @("C:\php*", "C:\inetpub", "C:\xampp", "C:\wamp*", "C:\laragon", "C:\Bitnami*", "C:\tools\php*")
    if ($Approfondi) { $racines += @("C:\Program Files", "C:\Program Files (x86)", "C:\ProgramData", "D:\", "E:\") }
    $bins = foreach ($r in $racines) { Get-ChildItem -Path $r -Recurse -Depth 4 -Include php.exe, php-cgi.exe, php-fpm.exe -File -ErrorAction SilentlyContinue }
    foreach ($b in ($bins | Sort-Object FullName -Unique)) {
        $v = ""; try { $v = (& $b.FullName -n -v 2>$null | Select-Object -First 1) -replace '^PHP\s+(\S+).*', '$1' } catch {}
        if (-not $v) { $v = $b.VersionInfo.ProductVersion }
        $res += [pscustomobject]@{ Serveur = $hote; Source = "binaire"; Detail = $b.FullName; Version = $v }
    }
    if (Get-Module -ListAvailable WebAdministration) {
        Import-Module WebAdministration -ErrorAction SilentlyContinue
        foreach ($a in (Get-WebConfiguration -Filter "system.webServer/fastCgi/application" -ErrorAction SilentlyContinue)) {
            if ($a.fullPath -match 'php') {
                $v = ""; try { $v = (& $a.fullPath -n -v 2>$null | Select-Object -First 1) -replace '^PHP\s+(\S+).*', '$1' } catch {}
                $res += [pscustomobject]@{ Serveur = $hote; Source = "IIS FastCGI"; Detail = $a.fullPath; Version = $v }
            }
        }
        $sites = Get-Website -ErrorAction SilentlyContinue | ForEach-Object { "$($_.Name) [$($_.State)] $($_.PhysicalPath)" }
        if ($sites) { $res += [pscustomobject]@{ Serveur = $hote; Source = "IIS sites"; Detail = ($sites -join " ; "); Version = "" } }
        # Association site IIS -> moteur PHP (handler scriptProcessor) : seule base d'un "correctif confirmé" par site
        foreach ($site in (Get-Website -ErrorAction SilentlyContinue)) {
            $hs = Get-WebConfiguration -Filter "system.webServer/handlers/add" -PSPath "IIS:\Sites\$($site.Name)" -ErrorAction SilentlyContinue | Where-Object { $_.scriptProcessor -match 'php' }
            foreach ($hd in ($hs | Sort-Object scriptProcessor -Unique)) {
                $exe = ($hd.scriptProcessor -split '\|')[0]
                $v = ""; try { $v = (& $exe -n -v 2>$null | Select-Object -First 1) -replace '^PHP\s+(\S+).*', '$1' } catch {}
                $res += [pscustomobject]@{ Serveur = $hote; Source = "moteur actif IIS"; Detail = "site $($site.Name) [$($site.State)] -> $exe"; Version = $v }
            }
        }
    }
    Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object { $_.PathName -match 'httpd|apache|nginx|xampp|wamp|php' } |
        ForEach-Object { $res += [pscustomobject]@{ Serveur = $hote; Source = "service $($_.State)"; Detail = "$($_.Name) : $($_.PathName)"; Version = "" } }
    $ports = 80, 81, 443, 8000, 8080, 8081, 8443, 8888, 9000
    Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.LocalPort -in $ports } | ForEach-Object {
        $proc = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
        $res += [pscustomobject]@{ Serveur = $hote; Source = "ecoute :$($_.LocalPort)"; Detail = "$($proc.ProcessName) ($($proc.Path))"; Version = "" }
    }
    if (-not $res) { $res += [pscustomobject]@{ Serveur = $hote; Source = "aucun indice"; Detail = ""; Version = "" } }
    $res
}
$brut = Invoke-Command -ComputerName $Serveurs -ScriptBlock $bloc -ArgumentList $Approfondi.IsPresent -ThrottleLimit $Parallele @OptCred -ErrorAction SilentlyContinue -ErrorVariable erreurs
$resultats = @($brut | ForEach-Object {
    [pscustomobject]@{ Serveur = $_.Serveur; Source = $_.Source; Detail = $_.Detail; Version = $_.Version
        Statut = if ($_.Source -eq "aucun indice") { "pas de PHP detecte" } elseif ($_.Version) { Evaluer $_.Version }
                 elseif ($_.Source -match 'ecoute|service|IIS sites') { "SERVEUR WEB PRESENT - verifier PHP" } else { "A VERIFIER (version non lue)" } }
})
foreach ($e in $erreurs) {
    $s = "$($e.TargetObject)"; if (-not $s) { $s = "$($e.OriginInfo.PSComputerName)" }
    $motif = if ("$e" -match 'Acc.s refus|Access is denied|access denied') { "ACCES REFUSE (WinRM) - compte sans droits d'administration" }
             elseif ("$e" -match 'WinRM') { "INJOIGNABLE (WinRM) - service WinRM ferme ou filtre" } else { "INJOIGNABLE (WinRM)" }
    $resultats += [pscustomobject]@{ Serveur = $s; Source = $motif; Detail = ("$e" -replace '\s+', ' ').Substring(0, [Math]::Min(150, "$e".Length)); Version = ""; Statut = "A TRAITER MANUELLEMENT" }
}
$resultats | Export-Csv -Path $Sortie -NoTypeInformation -Encoding UTF8 -Delimiter ";"
Write-Host "[=] $($resultats.Count) lignes -> $Sortie"
"""


def ecrire_scripts():
    os.makedirs(SCRIPTS, exist_ok=True)
    with open(os.path.join(SCRIPTS, "inventaire_php_windows.ps1"), "w", encoding="utf-8-sig") as f:
        f.write(SCRIPT_WINDOWS.lstrip())
    with open(os.path.join(SCRIPTS, "inventaire_php_linux_distant.sh"), "w", encoding="utf-8", newline="\n") as f:
        f.write("#!/usr/bin/env bash\n# Script exécuté sur chaque serveur Linux via ssh host bash -s\n" + SCRIPT_LINUX_DISTANT.lstrip())


def consolider_hote(lignes):
    """Règles P1-02 sur les lignes d'UN hôte :
    - plusieurs moteurs actifs de versions différentes -> chaque 'CORRECTIF CONFIRME' devient 'A VERIFIER' (association
      service/moteur à démontrer) ; les vulnérables confirmés restent vulnérables ;
    - aucun indice PHP et aucun port web -> 'NON CONCERNE CONFIRME'."""
    actifs = [l for l in lignes if l["source"].startswith(("moteur actif", "conteneur"))]
    versions = {re.match(r"\d+\.\d+\.\d+", l["version"]).group(0) for l in actifs if re.match(r"\d+\.\d+\.\d+", l["version"] or "")}
    if len(versions) > 1:
        for l in lignes:
            if l["statut"].startswith("CORRECTIF CONFIRME"):
                l["statut"] = f"A VERIFIER - plusieurs moteurs PHP actifs ({', '.join(sorted(versions))}) : associer chaque service à son moteur ; ce moteur est {l['statut']}"
                l["classe"] = classe_statut(l["statut"])
    if lignes and all(l["source"] == "aucun indice" for l in lignes):
        for l in lignes:
            l["statut"] = "NON CONCERNE CONFIRME (aucun PHP, aucun service web)"
            l["classe"] = "ok"
    return lignes


def fusionner_hotes(lignes):
    par_hote = {}
    for l in lignes:
        par_hote.setdefault(cle_hote(l), []).append(l)
    lignes = [l for grp in par_hote.values() for l in consolider_hote(grp)]
    existants = lire_json(HOTES_PATH, [])
    maj = {cle_hote(l) for l in lignes}
    tous = [h for h in existants if cle_hote(h) not in maj] + lignes
    sauver_json(HOTES_PATH, tous)
    return len(maj)


def ip_de(serveur):
    """IP connue pour ce nom via la liste des serveurs, ou le nom lui-même s'il est une IP."""
    try:
        return str(ipaddress.ip_address(serveur.split("@")[-1]))
    except ValueError:
        pass
    for s in lire_json(SERVEURS_PATH, []):
        if s["nom"] and s["nom"].lower().split(".")[0] == serveur.lower().split("@")[-1].split(".")[0]:
            return s["ip"]
    return ""


def ligne_hote(serveur, source, detail, version, statut, origine):
    return {"serveur": serveur, "ip": ip_de(serveur), "source": source, "detail": detail, "version": version,
            "statut": statut, "classe": classe_statut(statut), "origine": origine,
            "importe": datetime.now().isoformat(timespec="minutes")}


def cle_hote(h):
    return h.get("ip") or h["serveur"].lower().split(".")[0]


def importer_csv_hotes(texte, origine):
    texte = texte.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    if not texte.strip():
        raise ValueError("Fichier vide")
    try:
        dialecte = csv.Sniffer().sniff(texte[:2000], delimiters=";,")
    except csv.Error:
        dialecte = csv.excel
        dialecte.delimiter = ";"
    lignes = []
    for row in csv.DictReader(io.StringIO(texte), dialect=dialecte):
        row = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
        serveur = row.get("serveur") or row.get("server") or ""
        if serveur:
            src, ver = row.get("source", ""), row.get("version", "")
            if src.startswith("paquet"):
                st = evaluer(ver, "paquet")
            elif src.startswith("conteneur"):
                st = evaluer(ver, "conteneur")
            elif src.startswith("moteur actif"):
                st = evaluer(ver, "windows" if origine == "windows" else "binaire")
            elif src in ("binaire", "IIS FastCGI"):
                st = ("INSTALLATION PRESENTE - " + evaluer(ver, "windows" if origine == "windows" else "binaire") + " (association au site non démontrée)") if ver else row.get("statut", "")
            else:
                st = row.get("statut", "")
            lignes.append(ligne_hote(serveur, src, row.get("detail", ""), ver, st, origine))
    if not lignes:
        raise ValueError("Ce fichier n'est pas un relevé produit par les scripts (colonnes attendues : Serveur, Source, Detail, Version, Statut). Une liste de serveurs (RVTools, GLPI…) s'importe dans Paramétrage › Serveurs.")
    return len(lignes), fusionner_hotes(lignes)


RE_HOTE_SUR = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._@-]{0,253}$")


def hote_valide(h):
    """Nom d'hôte ou IP transmis à une commande externe : jeu de caractères restreint, jamais une option."""
    return bool(h) and RE_HOTE_SUR.match(h) is not None and not h.startswith("-")


# SSH en lecture seule, borné : clé uniquement (aucune saisie), une seule tentative, 8 s pour se connecter, session coupée
# après 30 s sans réponse ; empreinte du serveur mémorisée à la première connexion (known_hosts du poste).
OPTIONS_SSH = ["-o", "BatchMode=yes", "-o", "ConnectTimeout=8", "-o", "ConnectionAttempts=1", "-o", "ServerAliveInterval=15",
               "-o", "ServerAliveCountMax=2", "-o", "StrictHostKeyChecking=accept-new", "-o", "LogLevel=ERROR"]


def inventaire_linux_hote(hote, user, timeout):
    if not hote_valide(hote) or (user and not RE_HOTE_SUR.match(user)):
        return [ligne_hote(hote, "NOM INVALIDE", "caractères non autorisés", "", "A TRAITER MANUELLEMENT", "linux")]
    cible = f"{user}@{hote}" if user and "@" not in hote else hote
    cmd = ["ssh"] + OPTIONS_SSH + [cible, "bash -s"]
    try:
        p = subprocess.run(cmd, input=SCRIPT_LINUX_DISTANT, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError:
        raise RuntimeError("ssh introuvable sur ce poste")
    except subprocess.TimeoutExpired:
        return [ligne_hote(hote, "DELAI DEPASSE (ssh)", "", "", "A TRAITER MANUELLEMENT", "linux")]
    if p.returncode != 0 and not p.stdout.strip():
        return [ligne_hote(hote, "INJOIGNABLE (ssh)", p.stderr.strip()[:120], "", "A TRAITER MANUELLEMENT", "linux")]
    brut = [(l.split("|") + ["", ""])[:3] for l in p.stdout.splitlines() if "|" in l]
    paquets_distrib = any(src.startswith("paquet") for src, _, _ in brut)
    lignes = []
    for src, det, ver in brut:
        ver = ver.strip()
        if src.startswith("ecoute") or src == "vhosts":
            st = "SERVEUR WEB PRESENT - verifier PHP"
        elif src.startswith("paquet"):
            st = evaluer(ver, "paquet")
        elif src.startswith("conteneur"):
            st = evaluer(ver, "conteneur") if ver else "A VERIFIER (conteneur PHP probable, version non lue)"
        elif src.startswith("moteur actif"):
            st = evaluer(ver, "binaire_distrib" if paquets_distrib else "binaire") if ver else "A VERIFIER (moteur actif, version non lue)"
        elif src == "binaire":
            st = ("INSTALLATION PRESENTE - " + evaluer(ver, "binaire_distrib" if paquets_distrib else "binaire") + " (non associée à un service web : CLI ou installation inactive ?)") if ver else "A VERIFIER (version non lue)"
        else:
            st = evaluer(ver, "binaire") if ver else "A VERIFIER (version non lue)"
        lignes.append(ligne_hote(hote, src, det, ver, st, "linux"))
    return lignes or [ligne_hote(hote, "aucun indice", "", "", "NON CONCERNE CONFIRME (aucun PHP, aucun service web)", "linux")]


def _powershell_windows(hotes, win_user, win_mdp):
    """Exécute le script embarqué sur un lot de serveurs Windows ; mot de passe transmis par variable d'environnement
    au seul processus PowerShell (jamais sur la ligne de commande, jamais écrit)."""
    ecrire_scripts()
    ps1 = os.path.join(SCRIPTS, "inventaire_php_windows.ps1")
    os.makedirs(RESULTATS, exist_ok=True)
    sortie = os.path.join(RESULTATS, f"inventaire_php_windows_{secrets.token_hex(4)}.csv")
    cmd = ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", ps1, "-Sortie", sortie,
           "-Serveurs", ",".join(hotes)]
    if CONFIG["ps_approfondi"]:
        cmd.append("-Approfondi")
    env = dict(os.environ)
    env.pop("INVPHP_MDP", None)
    if win_user:
        cmd += ["-Utilisateur", win_user]
        env["INVPHP_MDP"] = win_mdp or ""
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=1800, env=env)
    for l in (p.stdout + p.stderr).splitlines():
        if l.strip():
            journal(ETAT_INV, l.strip()[:200])
    if not os.path.exists(sortie):
        raise RuntimeError("PowerShell n'a produit aucun résultat (WinRM, droits du compte ?)")
    with open(sortie, encoding="utf-8-sig") as f:
        texte = f.read()
    os.unlink(sortie)
    return importer_csv_hotes(texte, "windows")


def lancer_inventaire(linux, windows, ssh_user="", win_user="", win_mdp=""):
    """linux, windows : listes d'hôtes (IP pour Linux, nom DNS sinon IP pour Windows)."""
    with VERROU:
        ETAT_INV.update({"en_cours": True, "phase": "linux" if linux else "windows", "fait": 0, "total": len(linux) + len(windows),
                         "journal": [], "erreur": None, "stop": False, "fil": [], "courant": ""})
    try:
        if linux and not shutil.which("ssh"):
            msg = "Client SSH absent de ce poste : serveurs Linux non scannés (activer « Client OpenSSH » dans les fonctionnalités facultatives de Windows, ou importer un relevé fait à part)"
            journal(ETAT_INV, "ERREUR : " + msg)
            fil(ETAT_INV, "ERREUR : " + msg)
            with VERROU:
                ETAT_INV["fait"] += len(linux)
                ETAT_INV["erreur"] = msg
            linux = []
        if linux:
            journal(ETAT_INV, f"Linux par SSH : {len(linux)} serveur(s), {'compte saisi à l’écran' if ssh_user else 'compte de la session'} (non journalisé), authentification par clé")
            def un(h):
                if ETAT_INV["stop"]:
                    return []
                fil(ETAT_INV, f"{h}  Linux : connexion SSH…", h)
                r = inventaire_linux_hote(h, ssh_user, CONFIG["ssh_timeout"])
                with VERROU:
                    ETAT_INV["fait"] += 1
                vul = [x for x in r if x["classe"] == "vuln"]
                ver = sorted({x["version"] for x in r if x["version"]})
                fil(ETAT_INV, f"{h}  " + (r[0]["source"] + " " + r[0]["detail"][:70] if "INJOIGNABLE" in r[0]["source"] or "DELAI" in r[0]["source"]
                                          else f"{len(r)} élément(s)" + (f", PHP {', '.join(ver)}" if ver else ", pas de PHP") + (f" — {len(vul)} VULNÉRABLE" if vul else "")))
                return r
            lignes = []
            with ThreadPoolExecutor(max_workers=CONFIG["ssh_parallele"]) as ex:
                for r in ex.map(un, linux):
                    lignes += r
            if lignes:
                fusionner_hotes(lignes)
        if windows and not ETAT_INV["stop"]:
            with VERROU:
                ETAT_INV["phase"] = "windows"
            if platform.system() != "Windows":
                raise RuntimeError("Les serveurs Windows ne peuvent être interrogés que depuis un poste Windows : utiliser « Importer un relevé fait à part »")
            journal(ETAT_INV, f"Windows par WinRM : {len(windows)} serveur(s), {'compte saisi à l’écran' if win_user else 'compte de la session Windows'} (non journalisé)")
            lot = 8
            for k in range(0, len(windows), lot):
                if ETAT_INV["stop"]:
                    break
                paquet = windows[k:k + lot]
                fil(ETAT_INV, f"Windows : interrogation de {', '.join(paquet)}…", paquet[0])
                n, _ = _powershell_windows(paquet, win_user, win_mdp)
                with VERROU:
                    ETAT_INV["fait"] += len(paquet)
                hotes = {h["serveur"].lower().split(".")[0]: h for h in lire_json(HOTES_PATH, []) if h.get("origine") == "windows"} if "HOTES_PATH" in globals() else {}
                for h in paquet:
                    x = hotes.get(h.lower().split(".")[0])
                    fil(ETAT_INV, f"{h}  " + (f"{x['source']} — {x['statut']}"[:110] if x else "relevé reçu"))
        journal(ETAT_INV, "Scan des serveurs terminé" + (" (interrompu)" if ETAT_INV["stop"] else ""))
        fil(ETAT_INV, "Terminé" + (" (interrompu)" if ETAT_INV["stop"] else ""), "")
    except Exception as e:  # noqa
        with VERROU:
            ETAT_INV["erreur"] = str(e)
        journal(ETAT_INV, "ERREUR : " + str(e))
        fil(ETAT_INV, "ERREUR : " + str(e), "")
    finally:
        win_mdp = None
        with VERROU:
            ETAT_INV["en_cours"], ETAT_INV["phase"] = False, "inactif"


def tester_connexion(hote, systeme, ssh_user="", win_user="", win_mdp=""):
    """Essai de connexion sur un serveur, sans rien relever. Retourne (ok, message)."""
    if not hote_valide(hote):
        return False, "Nom ou adresse invalide"
    if systeme == "linux":
        if not shutil.which("ssh"):
            return False, "Client SSH absent de ce poste (Windows : Paramètres › Applications › Fonctionnalités facultatives › Client OpenSSH)"
        if ssh_user and not RE_HOTE_SUR.match(ssh_user):
            return False, "Nom de compte invalide"
        rc, out = _cmd(["ssh"] + OPTIONS_SSH + [f"{ssh_user}@{hote}" if ssh_user else hote, "id -un; command -v php || true"], 25)
        if rc == 0:
            return True, "Connexion SSH réussie : " + " ".join(out.split())[:120]
        if "Permission denied" in out:
            return False, "Serveur joint mais clé refusée : déposer la clé publique de ce poste dans ~/.ssh/authorized_keys du compte utilisé"
        return False, "Échec SSH : " + " ".join(out.split())[:200]
    if platform.system() != "Windows":
        return False, "Test WinRM possible uniquement depuis un poste Windows"
    if win_user and not re.fullmatch(r"[A-Za-z0-9._\\@-]{1,120}", win_user):
        return False, "Nom de compte invalide"
    ps = ("$o=@{}; if ($env:INVPHP_U) { $o.Credential = New-Object System.Management.Automation.PSCredential($env:INVPHP_U,"
          " (ConvertTo-SecureString $env:INVPHP_MDP -AsPlainText -Force)) }; "
          "$o.SessionOption = New-PSSessionOption -OpenTimeout 15000 -OperationTimeout 30000; "
          f"Invoke-Command -ComputerName '{hote}' @o -ScriptBlock {{ \"$env:COMPUTERNAME, PowerShell $($PSVersionTable.PSVersion)\" }} -ErrorAction Stop")
    env = dict(os.environ)
    env.pop("INVPHP_MDP", None)
    if win_user:
        env["INVPHP_U"], env["INVPHP_MDP"] = win_user, win_mdp or ""
    try:
        p = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True, text=True, timeout=40, env=env)
    except subprocess.TimeoutExpired:
        return False, "Délai dépassé : serveur injoignable ou WinRM filtré (port 5985)"
    out = " ".join((p.stdout + p.stderr).split())
    if p.returncode == 0 and p.stdout.strip():
        return True, "Connexion WinRM réussie : " + out[:120]
    if re.search(r"Acc.s refus|Access is denied", out):
        return False, "Serveur joint mais accès refusé : le compte doit être administrateur du serveur"
    return False, "Échec WinRM : " + out[:220]


# ---------------------------------------------------------------------------
# Planification, comparaison, courriel
# ---------------------------------------------------------------------------
def cibles_planifiees():
    cibles = []
    if CONFIG["planif_cibles"] in ("plages", "les_deux"):
        cibles += CONFIG["plages_autorisees"]
    if CONFIG["planif_cibles"] in ("serveurs", "les_deux"):
        autorisees = parse_reseaux(CONFIG["plages_autorisees"])
        cibles += [s["ip"] for s in lire_json(SERVEURS_PATH, []) if dans_autorisees(ipaddress.ip_network(s["ip"]), autorisees)]
    return cibles


def comparer_scans(nouveau, ancien):
    def cle(r):
        return f"{r['ip']}:{r['port']}"
    vn = {cle(r): r for r in nouveau["resultats"] if r["classe"] == "vuln"}
    va = {cle(r): r for r in ancien["resultats"] if r["classe"] == "vuln"} if ancien else {}
    pn = {cle(r) for r in nouveau["resultats"] if r["php_detecte"] == "oui"}
    pa = {cle(r) for r in ancien["resultats"] if r["php_detecte"] == "oui"} if ancien else set()
    return {"nouveaux_vuln": [vn[k] for k in sorted(vn) if k not in va],
            "corriges": [va[k] for k in sorted(va) if k not in vn],
            "nouveaux_php": sorted(pn - pa), "disparus_php": sorted(pa - pn)}


def synthese_texte(doc, delta, hotes_vuln):
    r = doc["resultats"]
    n = {k: sum(1 for x in r if x["classe"] == k) for k in ("vuln", "verif", "ok")}
    php = sum(1 for x in r if x["php_detecte"] == "oui")
    lignes = [f"Inventaire PHP — scan du {doc['date'].replace('T', ' ')} ({CVE_LIBELLE})", "",
              f"Services web : {len(r)} | PHP détecté : {php} | VULNÉRABLES : {n['vuln']} | à vérifier : {n['verif']} | corrigés : {n['ok']}", ""]
    if delta["nouveaux_vuln"]:
        lignes.append("NOUVEAUX VULNÉRABLES depuis le scan précédent :")
        lignes += [f"  - {x['ip']}:{x['port']} {x['nom'] or x['titre']} — PHP {x['version_php']}" for x in delta["nouveaux_vuln"]]
    if delta["corriges"]:
        lignes.append("Corrigés / disparus depuis le scan précédent :")
        lignes += [f"  - {x['ip']}:{x['port']} {x['nom'] or x['titre']}" for x in delta["corriges"]]
    if delta["nouveaux_php"]:
        lignes.append("Nouveaux services PHP détectés : " + ", ".join(delta["nouveaux_php"]))
    if not any(delta.values()):
        lignes.append("Aucun changement par rapport au scan précédent.")
    vulns = [x for x in r if x["classe"] == "vuln"]
    if vulns:
        lignes += ["", "Ensemble des services vulnérables (version exposée) :"]
        lignes += [f"  - {x['ip']}:{x['port']} {x['nom'] or x['titre']} — PHP {x['version_php']}" for x in vulns[:60]]
        if len(vulns) > 60:
            lignes.append(f"  … et {len(vulns) - 60} autres")
    if hotes_vuln:
        lignes += ["", "Scan hôtes — lignes vulnérables :"]
        lignes += [f"  - {h['serveur']} : {h['source']} {h['detail']} {h['version']}" for h in hotes_vuln[:60]]
    lignes += ["", f"Détails dans l'application (dossier {DATA})."]
    return "\n".join(lignes)


def envoyer_courriel(sujet, corps):
    if not (CONFIG["smtp_serveur"] and CONFIG["smtp_a"]):
        return False
    import smtplib
    from email.message import EmailMessage
    msg = EmailMessage()
    msg["Subject"], msg["From"] = sujet, CONFIG["smtp_de"] or CONFIG["smtp_a"]
    msg["To"] = ", ".join(a.strip() for a in CONFIG["smtp_a"].replace(";", ",").split(",") if a.strip())
    msg.set_content(corps)
    with smtplib.SMTP(CONFIG["smtp_serveur"], int(CONFIG["smtp_port"] or 25), timeout=30) as s:
        if CONFIG["smtp_tls"]:
            s.starttls(context=ssl.create_default_context())
        s.send_message(msg)  # relais interne sans authentification : aucun identifiant conservé
    return True


def executer_cycle(origine="planification"):
    """Scan complet selon la planification, puis inventaire Linux si demandé, comparaison et courriel."""
    journal(ETAT_PLANIF, f"Cycle lancé ({origine})")
    try:
        scans_avant = liste_scans()
        ancien = charger_scan(scans_avant[0]["id"]) if scans_avant else None
        cibles = valider_cibles(cibles_planifiees())
        params = {"cibles": cibles, "exclusions": parse_reseaux(CONFIG["exclusions"]), "ports": CONFIG["ports"],
                  "debit": CONFIG["debit"], "threads": CONFIG["threads"]}
        if ETAT["en_cours"]:
            raise RuntimeError("un scan manuel est déjà en cours")
        lancer_scan(params)
        if ETAT["erreur"]:
            raise RuntimeError(ETAT["erreur"])
        doc = charger_scan(ETAT["scan_id"])
        hotes_vuln = []
        if CONFIG["planif_inventaire_linux"]:
            hotes = [x["ip"] for x in serveurs_annotes() if x["systeme"] == "linux" and not serveur_exclu(x["ip"])]
            if hotes and not ETAT_INV["en_cours"]:
                lancer_inventaire(hotes, [], compte_ssh_planifie())
            hotes_vuln = [h for h in lire_json(HOTES_PATH, []) if h["classe"] == "vuln"]
        delta = comparer_scans(doc, ancien)
        texte = synthese_texte(doc, delta, hotes_vuln)
        nb_vuln = sum(1 for x in doc["resultats"] if x["classe"] == "vuln")
        sujet = f"[Inventaire PHP] {nb_vuln} vulnérable(s), {len(delta['nouveaux_vuln'])} nouveau(x) — {doc['date'][:10]}"
        envoye = False
        try:
            envoye = envoyer_courriel(sujet, texte)
        except Exception as e:  # noqa
            journal(ETAT_PLANIF, f"Courriel non envoyé : {e}")
        with VERROU:
            ETAT_PLANIF["dernier"] = {"date": doc["date"], "scan_id": doc["id"], "vuln": nb_vuln,
                                      "nouveaux": len(delta["nouveaux_vuln"]), "corriges": len(delta["corriges"]),
                                      "courriel": envoye, "synthese": texte}
        journal(ETAT_PLANIF, f"Cycle terminé : {nb_vuln} vulnérable(s), {len(delta['nouveaux_vuln'])} nouveau(x)" + (", courriel envoyé" if envoye else ""))
        return texte
    except Exception as e:  # noqa
        journal(ETAT_PLANIF, "ERREUR : " + str(e))
        with VERROU:
            ETAT_PLANIF["dernier"] = {"date": datetime.now().isoformat(timespec="seconds"), "erreur": str(e)}
        try:
            envoyer_courriel("[Inventaire PHP] ÉCHEC du cycle planifié", str(e))
        except Exception:  # noqa
            pass
        return None


def prochain_passage(maintenant=None):
    from datetime import timedelta
    maintenant = maintenant or datetime.now()
    try:
        h, m = (int(x) for x in CONFIG["planif_heure"].split(":"))
    except ValueError:
        return None
    jours = set(int(j) for j in CONFIG["planif_jours"]) or set(range(7))
    for d in range(0, 8):
        t = (maintenant + timedelta(days=d)).replace(hour=h, minute=m, second=0, microsecond=0)
        if t.weekday() in jours and t > maintenant:
            return t
    return None


def boucle_planificateur():
    dernier_declenche = None
    while True:
        try:
            if CONFIG["planif_actif"]:
                p = prochain_passage()
                with VERROU:
                    ETAT_PLANIF["prochain"] = p.isoformat(timespec="minutes") if p else None
                maintenant = datetime.now()
                cle = maintenant.strftime("%Y-%m-%d %H:%M")
                if (maintenant.strftime("%H:%M") == CONFIG["planif_heure"] and maintenant.weekday() in set(int(j) for j in CONFIG["planif_jours"])
                        and cle != dernier_declenche and not ETAT["en_cours"]):
                    dernier_declenche = cle
                    threading.Thread(target=executer_cycle, daemon=True).start()
            else:
                with VERROU:
                    ETAT_PLANIF["prochain"] = None
        except Exception as e:  # noqa
            journal(ETAT_PLANIF, "Planificateur : " + str(e))
        time.sleep(20)


# ---------------------------------------------------------------------------
# Référentiel des VLAN (v2.1) — cartographie initiale CH Brive, modifiable dans l'application
# ---------------------------------------------------------------------------
DECISIONS_VLAN = {"P1": "Priorité 1 — exposé à Internet", "scanner": "À scanner", "a_decider": "À décider",
                  "reserve": "Sous réserve d'accord (biomédical, fournisseur)", "exclure": "Exclure"}
VLANS_INITIAUX = []  # cartographie vierge : chaque site importe la sienne (Paramétrage › VLAN › Importer)


def charger_vlans():
    v = lire_json(VLANS_PATH, None)
    if v is None:
        v = [dict(x, cle=f"v{i}") for i, x in enumerate(VLANS_INITIAUX)]
        sauver_json(VLANS_PATH, v)
    return v


# Données d'exemple (v2.8) : adresses réservées à la documentation (RFC 5737), qui n'existent sur aucun réseau.
EXEMPLE_VLANS = [
    {"nom": "DMZ (exemple)", "site": "Exemple", "plages": ["192.0.2.0/24"], "decision": "P1",
     "contenu": "Exemple : reverse proxy et serveurs web publiés sur Internet", "commentaire": "Donnée d'exemple, à supprimer"},
    {"nom": "Serveurs applicatifs (exemple)", "site": "Exemple", "plages": ["198.51.100.0/25"], "decision": "scanner",
     "contenu": "Exemple : serveurs Windows et Linux des applications métier", "commentaire": "Donnée d'exemple, à supprimer"},
    {"nom": "Biomédical (exemple)", "site": "Exemple", "plages": ["198.51.100.128/25"], "decision": "reserve",
     "contenu": "Exemple : équipements biomédicaux, scannés seulement avec l'accord du biomédical", "commentaire": "Donnée d'exemple, à supprimer"},
    {"nom": "Téléphonie (exemple)", "site": "Exemple", "plages": ["203.0.113.0/24"], "decision": "exclure",
     "contenu": "Exemple : téléphones IP et autocommutateur, jamais scannés", "commentaire": "Donnée d'exemple, à supprimer"},
]
EXEMPLE_SERVEURS = [
    {"ip": "192.0.2.10", "nom": "ex-proxy-dmz", "os": "Debian 12", "site": "Exemple", "commentaire": "Reverse proxy (exemple)"},
    {"ip": "198.51.100.20", "nom": "ex-intranet", "os": "Windows Server 2019", "site": "Exemple", "commentaire": "Intranet IIS (exemple)"},
    {"ip": "198.51.100.21", "nom": "ex-gestdoc", "os": "Ubuntu 22.04", "site": "Exemple", "commentaire": "Gestion documentaire (exemple)"},
    {"ip": "198.51.100.30", "nom": "ex-labo", "os": "Windows Server 2016", "site": "Exemple", "commentaire": "Laboratoire (exemple)"},
    {"ip": "203.0.113.50", "nom": "ex-ipbx", "os": "Linux", "site": "Exemple", "commentaire": "Autocommutateur, VLAN exclu (exemple)"},
]
EXEMPLE_NOMS = [
    {"nom": "intranet.exemple.invalid", "ip": "198.51.100.20"}, {"nom": "rh.exemple.invalid", "ip": "198.51.100.20"},
    {"nom": "portail.exemple.invalid", "ip": "192.0.2.10"}, {"nom": "ancien-site.exemple.invalid", "ip": ""},
]


def recalculer_etat_noms():
    """Met à jour l'état « dans / hors périmètre » des noms d'après leur adresse déjà résolue (sans requête DNS)."""
    autorisees = parse_reseaux(CONFIG["plages_autorisees"])
    noms = lire_json(NOMS_PATH, [])
    for x in noms:
        ip = x.get("ip", "")
        x["etat"] = "non résolu" if not ip else ("dans le périmètre" if dans_autorisees(ipaddress.ip_network(ip), autorisees) else "hors périmètre")
    sauver_json(NOMS_PATH, noms)


def charger_exemples():
    maintenant = datetime.now().isoformat(timespec="minutes")
    vlans = charger_vlans()
    cles = {v["cle"] for v in vlans}
    nv = 0
    for i, v in enumerate(EXEMPLE_VLANS):
        if f"ex{i}" not in cles:
            vlans.append(dict(v, cle=f"ex{i}", exemple=True))
            nv += 1
    sauver_json(VLANS_PATH, vlans)
    srv = lire_json(SERVEURS_PATH, [])
    ips = {x["ip"] for x in srv}
    ajout = [dict(x, exemple=True, importe=maintenant) for x in EXEMPLE_SERVEURS if x["ip"] not in ips]
    sauver_json(SERVEURS_PATH, srv + ajout)
    noms = lire_json(NOMS_PATH, [])
    connus = {x["nom"] for x in noms}
    an = [dict(x, etat="", site="Exemple", source="exemple", importe=maintenant, exemple=True) for x in EXEMPLE_NOMS if x["nom"] not in connus]
    sauver_json(NOMS_PATH, sorted(noms + an, key=lambda x: x["nom"]))
    recalculer_etat_noms()
    return {"vlans": nv, "serveurs": len(ajout), "noms": len(an)}


def supprimer_exemples():
    vlans = charger_vlans()
    plages_ex = {p for v in vlans if v.get("exemple") for p in v["plages"]}
    sauver_json(VLANS_PATH, [v for v in vlans if not v.get("exemple")])
    srv = lire_json(SERVEURS_PATH, [])
    ips_ex = {x["ip"] for x in srv if x.get("exemple")}
    sauver_json(SERVEURS_PATH, [x for x in srv if not x.get("exemple")])
    noms = lire_json(NOMS_PATH, [])
    noms_ex = {x["nom"] for x in noms if x.get("exemple")}
    sauver_json(NOMS_PATH, [x for x in noms if not x.get("exemple")])
    CONFIG["plages_autorisees"] = [p for p in CONFIG["plages_autorisees"] if p not in plages_ex and p not in ips_ex]
    CONFIG["exclusions"] = [p for p in CONFIG["exclusions"] if p not in plages_ex]
    if CONFIG.get("perimetre_vlans"):
        CONFIG["perimetre_vlans"] = [c for c in CONFIG["perimetre_vlans"] if not str(c).startswith("ex")]
    CONFIG["perimetre_serveurs"] = [i for i in CONFIG.get("perimetre_serveurs", []) if i not in ips_ex]
    CONFIG["perimetre_noms"] = [n for n in CONFIG.get("perimetre_noms", []) if n not in noms_ex]
    sauver_json(CONFIG_PATH, CONFIG)
    recalculer_etat_noms()
    return {"vlans": len([1 for v in vlans if v.get("exemple")]), "serveurs": len(ips_ex), "noms": len(noms_ex)}


def ajouter_adresses_perimetre(adresses):
    """Ajoute au périmètre des adresses ou sous-réseaux saisis dans le scan réseau (après confirmation).
    Refuse ce qui tombe dans une exclusion. Ces adresses sont conservées quand on ré-applique le périmètre."""
    exclus = parse_reseaux(CONFIG["exclusions"])
    nouv = []
    for a in adresses:
        r = ipaddress.ip_network(str(a).strip(), strict=False)
        if dans_autorisees(r, exclus):
            raise ValueError(f"{a} est dans une exclusion (VLAN exclu ou exclusion permanente) : il ne peut pas être scanné")
        nouv.append(str(r) if r.num_addresses > 1 else str(r.network_address))
    CONFIG["perimetre_adresses"] = sorted(set(CONFIG.get("perimetre_adresses", [])) | set(nouv), key=lambda x: ipaddress.ip_network(x))
    CONFIG["plages_autorisees"] = sorted(set(CONFIG["plages_autorisees"]) | set(nouv), key=lambda x: ipaddress.ip_network(x))
    sauver_json(CONFIG_PATH, CONFIG)
    recalculer_etat_noms()
    return nouv


def calculer_perimetre(cles_vlans, ips_serveurs, noms_choisis):
    """Périmètre = plages des VLAN cochés + adresse de chaque serveur coché + adresse de chaque nom coché.
    Exclusions = VLAN « exclure » + VLAN « sous réserve » non cochés. Les exclusions l'emportent toujours au moment du scan."""
    vlans = charger_vlans()
    cles = set(cles_vlans or [])
    choisis = [v for v in vlans if v["cle"] in cles]
    aut = plages_selon_decision(choisis, {"P1", "scanner", "a_decider", "reserve"})
    exc = plages_selon_decision(vlans, {"exclure"}) + plages_selon_decision([v for v in vlans if v["cle"] not in cles], {"reserve"})
    reseaux = parse_reseaux(aut)
    exclus = parse_reseaux(exc)
    ips_srv = {x["ip"] for x in lire_json(SERVEURS_PATH, [])}
    srv = [i for i in dict.fromkeys(ips_serveurs or []) if i in ips_srv]
    idx_noms = {x["nom"]: x for x in lire_json(NOMS_PATH, [])}
    noms = [n for n in dict.fromkeys(noms_choisis or []) if n in idx_noms and idx_noms[n].get("ip")]
    adresses_ajoutees, deja, exclues = [], 0, []
    for ip in srv + [idx_noms[n]["ip"] for n in noms]:
        r = ipaddress.ip_network(ip)
        if dans_autorisees(r, exclus):
            exclues.append(ip)
            continue
        if dans_autorisees(r, reseaux) or ip in adresses_ajoutees:
            deja += 1
            continue
        adresses_ajoutees.append(ip)
    libres = []
    for a in CONFIG.get("perimetre_adresses", []):
        try:
            r = ipaddress.ip_network(a, strict=False)
        except ValueError:
            continue
        if dans_autorisees(r, exclus):
            exclues.append(a)
            continue
        libres.append(str(r) if r.num_addresses > 1 else str(r.network_address))
    toutes = sorted(set(aut) | set(adresses_ajoutees) | set(libres), key=lambda x: ipaddress.ip_network(x))
    nb = sum(n.num_addresses for n in ipaddress.collapse_addresses(parse_reseaux(toutes))) if toutes else 0
    return {"autorisees": toutes, "exclusions": sorted(set(exc), key=lambda x: ipaddress.ip_network(x)),
            "nb_vlans": len(choisis), "nb_serveurs": len(srv), "nb_noms": len(noms), "adresses": nb,
            "adresses_individuelles": len(adresses_ajoutees), "deja_couvertes": deja, "exclues": sorted(set(exclues)),
            "vlans": [v["cle"] for v in choisis], "serveurs": srv, "noms": noms, "adresses_libres": libres}


def plages_selon_decision(vlans, decisions):
    out = []
    for v in vlans:
        if v["decision"] in decisions:
            out += v["plages"]
    return out


# ---------------------------------------------------------------------------
# Diagnostic du poste (v1.2)
# ---------------------------------------------------------------------------
def _cmd(cmd, timeout=15):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout + p.stderr).strip()
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
        return -1, str(e)


def diagnostic(complet=False):
    """Liste de contrôles {nom, etat: ok|avert|ko|info, detail, conseil}. Rapide par défaut."""
    win = platform.system() == "Windows"
    c = []
    def add(nom, etat, detail, conseil=""):
        c.append({"nom": nom, "etat": etat, "detail": detail, "conseil": conseil})
    portable = os.path.normcase(os.path.dirname(sys.executable)).startswith(os.path.normcase(BASE))
    add("Python", "ok", f"{platform.python_version()} — {'version portable (embarquée, sans installation)' if portable else sys.executable}")
    add("Poste", "info", f"{platform.node()} — {platform.system()} {platform.release()}")
    nm = shutil.which("nmap")
    if nm:
        rc, out = _cmd(["nmap", "--version"], 10)
        add("nmap", "ok" if rc == 0 else "avert", (out.splitlines()[0] if out else nm), "" if rc == 0 else "nmap présent mais ne démarre pas")
    else:
        add("nmap", "avert", "introuvable : le moteur Python de secours sera utilisé (plus lent, sans estimation de durée)", "Facultatif : nmap accélère les grands scans (option 3 du lanceur « Inventaire PHP.bat », droits d'administration nécessaires).")
    add("Moteur de découverte", "info", {"auto": "automatique (nmap si présent, sinon Python)", "nmap": "nmap imposé", "python": "Python imposé"}[CONFIG.get("moteur", "auto")])
    nn = lire_json(NOMS_PATH, [])
    add("Noms d'hôtes (vhosts)", "ok" if nn else "info", f"{len(nn)} nom(s), {sum(1 for x in nn if x['etat']=='dans le périmètre')} dans le périmètre" if nn else "aucun : import DNS / proxys facultatif (onglet Serveurs)")
    if win:
        npcap = npcap_present()
        add("Npcap", "ok" if npcap else ("avert" if nm else "info"), "présent" if npcap else "non détecté",
            "" if npcap else ("nmap ne peut pas fonctionner sans Npcap : le moteur Python est utilisé automatiquement." if nm else "Inutile sans nmap."))
    add("ssh (inventaire Linux)", "ok" if shutil.which("ssh") else "avert", shutil.which("ssh") or "introuvable", "" if shutil.which("ssh") else "Sous Windows : activer « Client OpenSSH » dans Applications > Fonctionnalités facultatives.")
    if win:
        ps = shutil.which("powershell.exe") or shutil.which("powershell")
        add("PowerShell (inventaire Windows)", "ok" if ps else "ko", ps or "introuvable")
    else:
        add("PowerShell (inventaire Windows)", "info", "poste non Windows : inventaire Windows par script exporté puis import CSV")
    plages = CONFIG["plages_autorisees"]
    add("Plages autorisées", "ok" if plages else "ko", ", ".join(plages) if plages else "aucune", "" if plages else "Définir le périmètre (action 1).")
    add("Exclusions permanentes", "ok" if CONFIG["exclusions"] else "avert", ", ".join(CONFIG["exclusions"]) or "aucune", "" if CONFIG["exclusions"] else "Déclarer les VLAN biomédicaux et dispositifs médicaux.")
    srv = lire_json(SERVEURS_PATH, [])
    add("Liste des serveurs", "ok" if srv else "avert", f"{len(srv)} serveur(s)", "" if srv else "Importer la liste des serveurs (facultatif mais recommandé).")
    add("Dossier de données", "ok" if os.access(DATA, os.W_OK) else "ko", DATA)
    if RESULTATS != DATA:
        add("Dossier des résultats", "ok" if os.path.isdir(RESULTATS) and os.access(RESULTATS, os.W_OK) else "info", RESULTATS)
    if complet:
        if win and shutil.which("powershell.exe"):
            rc, out = _cmd(["powershell.exe", "-NoProfile", "-Command", "if (Get-Module -ListAvailable ActiveDirectory) {'ok'} else {'absent'}"], 40)
            add("Module ActiveDirectory (RSAT)", "ok" if "ok" in out else "avert", out[:80], "" if "ok" in out else "Installer RSAT : Active Directory Domain Services and Lightweight Directory Tools.")
            cible = next((x["nom"] or x["ip"] for x in srv if re.search("windows", x["os"], re.I) and not serveur_exclu(x["ip"])), None)
            if cible:
                rc, out = _cmd(["powershell.exe", "-NoProfile", "-Command", f"try {{ Test-WSMan -ComputerName '{cible}' -ErrorAction Stop | Out-Null; 'ok' }} catch {{ 'ko ' + $_.Exception.Message }}"], 40)
                add(f"WinRM vers {cible}", "ok" if out.startswith("ok") else "avert", out[:120], "" if out.startswith("ok") else "Activer WinRM sur les serveurs (Enable-PSRemoting) ou lancer depuis un compte administrateur du domaine.")
        if shutil.which("ssh"):
            cible = next((x["nom"] or x["ip"] for x in srv if re.search("linux|debian|ubuntu|rhel|centos", x["os"], re.I) and not serveur_exclu(x["ip"])), None)
            if cible:
                u = compte_ssh_planifie()
                rc, out = _cmd(["ssh"] + OPTIONS_SSH + [f"{u}@{cible}" if u else cible, "true"], 20)
                add(f"SSH vers {cible}", "ok" if rc == 0 else "avert", "connexion par clé réussie" if rc == 0 else out[:120], "" if rc == 0 else "Déployer la clé SSH du poste sur les serveurs, vérifier l'utilisateur SSH.")
        if CONFIG["smtp_serveur"]:
            try:
                with socket.create_connection((CONFIG["smtp_serveur"], int(CONFIG["smtp_port"] or 25)), timeout=6):
                    add("Serveur de messagerie", "ok", f"{CONFIG['smtp_serveur']}:{CONFIG['smtp_port']} joignable")
            except OSError as e:
                add("Serveur de messagerie", "avert", str(e)[:100], "Vérifier le serveur SMTP et l'autorisation de relais du poste.")
        if win:
            rc, out = _cmd(["schtasks", "/Query", "/TN", "Inventaire PHP", "/FO", "LIST"], 15)
            add("Tâche planifiée Windows", "ok" if rc == 0 else "info", "présente" if rc == 0 else "absente", "" if rc == 0 else "Créable depuis l'onglet Planification.")
    return c


def tache_windows(creer):
    """Crée ou supprime la tâche planifiée Windows « Inventaire PHP » exécutant --cycle."""
    if platform.system() != "Windows":
        heure = CONFIG["planif_heure"]
        jours = ",".join(str((j + 1) % 7) for j in CONFIG["planif_jours"]) or "*"
        return {"ok": False, "message": "Poste non Windows. Ligne cron équivalente :",
                "commande": f"{heure.split(':')[1]} {heure.split(':')[0]} * * {jours} {sys.executable} {os.path.abspath(__file__)} --cycle"}
    if not creer:
        rc, out = _cmd(["schtasks", "/Delete", "/TN", "Inventaire PHP", "/F"], 20)
        return {"ok": rc == 0, "message": out}
    noms = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]
    jours = ",".join(noms[j] for j in sorted(CONFIG["planif_jours"])) or "MON,TUE,WED,THU,FRI"
    tr = (f'"{sys.executable}" --cycle --sans-navigateur --donnees "{DATA}"' if getattr(sys, "frozen", False)
          else f'"{sys.executable}" "{os.path.abspath(__file__)}" --cycle --sans-navigateur --donnees "{DATA}"')
    cmd = ["schtasks", "/Create", "/F", "/TN", "Inventaire PHP", "/SC", "WEEKLY", "/D", jours,
           "/ST", CONFIG["planif_heure"], "/TR", tr, "/RL", "HIGHEST"]
    rc, out = _cmd(cmd, 30)
    return {"ok": rc == 0, "message": out, "commande": " ".join(cmd)}


# ---------------------------------------------------------------------------
# Suivi SSI (v1.3) : sites, applications externes, suivi des corrections, export Excel
# ---------------------------------------------------------------------------
ETATS_SUIVI = ["à traiter", "en cours", "corrigé", "risque accepté", "non concerné"]
ETATS_EXTERNE = ["à contacter", "demande envoyée", "confirmé corrigé", "confirmé vulnérable", "non concerné"]


def site_de(ip):
    for x in lire_json(SERVEURS_PATH, []):
        if x["ip"] == ip:
            return x.get("site", "")
    return ""


def vlan_de(ip, vlans=None):
    """VLAN de la cartographie contenant cette adresse (le plus spécifique), ou None."""
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return None
    meilleur = None
    for v in (vlans if vlans is not None else charger_vlans()):
        for pl in v.get("plages", []):
            try:
                r = ipaddress.ip_network(pl, strict=False)
            except ValueError:
                continue
            if a.version == r.version and a in r and (meilleur is None or r.prefixlen > meilleur[1]):
                meilleur = (v, r.prefixlen)
    return meilleur[0] if meilleur else None


def services_cumules():
    """Dernier état connu de chaque service (ip, port, nom) sur l'ensemble des scans enregistrés, du plus ancien au plus récent."""
    etat = {}
    if not os.path.isdir(DATA):
        return []
    for f in sorted(x for x in os.listdir(RESULTATS) if x.startswith("scan_") and x.endswith(".json")) if os.path.isdir(RESULTATS) else []:
        d = lire_json(os.path.join(RESULTATS, f), None)
        if not d:
            continue
        for r in d.get("resultats", []):
            if r.get("statut", "").startswith("HORS PERIMETRE"):
                continue
            cle = (r["ip"], r["port"], r.get("nom", "") if r.get("vhost") else "")
            etat[cle] = dict(r, scan_id=d.get("id", ""))
    return list(etat.values())


def harmonisateur_sites():
    """Fusionne les écritures d'un même site (« CH Brive », « CH-BRIVE », « ch brive »…) : comparaison sans casse,
    espaces ni tirets ; l'écriture de la cartographie des VLAN est retenue, sinon la première rencontrée."""
    cle = lambda t: re.sub(r"[\s\-_.'’]", "", t or "").upper()
    canon = {}
    for v in charger_vlans():
        if (v.get("site") or "").strip():
            canon.setdefault(cle(v["site"]), v["site"].strip())
    for x in lire_json(SERVEURS_PATH, []):
        if (x.get("site") or "").strip():
            canon.setdefault(cle(x["site"]), x["site"].strip())
    return lambda t: canon.get(cle(t), t) if t else t


def bilan_sites(scan=None):
    """Bilan cumulatif par établissement sur tous les scans réseau et tous les scans hôtes.
    Site : celui du serveur importé, sinon celui du VLAN de la cartographie."""
    serveurs = {x["ip"]: x for x in lire_json(SERVEURS_PATH, [])}
    vlans = charger_vlans()
    def site_ip(ip):
        s_ = serveurs.get(ip, {}).get("site", "")
        if s_:
            return s_
        v = vlan_de(ip, vlans)
        return v.get("site", "") if v else ""
    sites = {}
    norm = harmonisateur_sites()

    def ligne(site):
        k = norm(site) or "(non renseigné)"
        return sites.setdefault(k, {"site": k, "serveurs": 0, "services": 0, "php": 0, "pot_vuln": 0, "a_verifier": 0,
                                    "hotes": 0, "vuln_confirme": 0, "corrige": 0})
    for x in serveurs.values():
        ligne(x.get("site", ""))["serveurs"] += 1
    for r in services_cumules():
        if r.get("statut") == "PAS DE REPONSE HTTP":
            continue
        l = ligne(site_ip(r["ip"]))
        l["services"] += 1
        if r.get("php_detecte") in ("oui", "faible"):
            l["php"] += 1
        if r.get("classe") == "vuln":
            l["pot_vuln"] += 1
        elif r.get("classe") == "verif":
            l["a_verifier"] += 1
    hotes_vus = set()
    for h in lire_json(HOTES_PATH, []):
        l = ligne(site_ip(h.get("ip", "")))
        k = (h.get("ip") or h["serveur"]).lower()
        if k not in hotes_vus:
            hotes_vus.add(k)
            l["hotes"] += 1
        if h["classe"] == "vuln":
            l["vuln_confirme"] += 1
        elif h["classe"] == "ok":
            l["corrige"] += 1
    return sorted(sites.values(), key=lambda x: (x["site"] == "(non renseigné)", x["site"]))


def alimenter_suivi():
    """Ajoute au suivi toute ligne vulnérable ou à vérifier du dernier scan et de l'inventaire hôtes, sans toucher aux lignes existantes."""
    suivi = lire_json(SUIVI_PATH, [])
    cles = {x["cle"] for x in suivi}
    ajout = 0
    scans = liste_scans()
    scan = charger_scan(scans[0]["id"]) if scans else None
    if scan:
        for r in scan["resultats"]:
            if r["classe"] in ("vuln", "verif") and r["php_detecte"] in ("oui", "faible"):
                cle = f"reseau:{r['ip']}:{r['port']}" + (f":{r['nom']}" if r.get("vhost") else "")
                if cle not in cles:
                    suivi.append({"cle": cle, "cible": (f"{r['nom']} ({r['ip']}:{r['port']})" if r.get("vhost") else f"{r['ip']}:{r['port']}"), "nom": r.get("nom", ""), "site": site_de(r["ip"]),
                                  "constat": r["statut"], "origine": "scan réseau", "responsable": "", "echeance": "",
                                  "etat": "à traiter", "preuve": "", "commentaire": "", "cree": datetime.now().isoformat(timespec="minutes")})
                    cles.add(cle); ajout += 1
    for h in lire_json(HOTES_PATH, []):
        if h["classe"] in ("vuln", "verif") and not h["source"].startswith(("ecoute", "vhosts", "INJOIGNABLE", "DELAI")):
            cle = f"hote:{h.get('ip') or h['serveur']}:{h['source']}:{h['detail']}"[:200]
            if cle not in cles:
                suivi.append({"cle": cle, "cible": h["serveur"] + (f" ({h['ip']})" if h.get("ip") else ""), "nom": h["serveur"],
                              "site": site_de(h.get("ip", "")), "constat": f"{h['source']} {h['detail']} {h['version']} — {h['statut']}",
                              "origine": "scan hôtes", "responsable": "", "echeance": "", "etat": "à traiter", "preuve": "",
                              "commentaire": "", "cree": datetime.now().isoformat(timespec="minutes")})
                cles.add(cle); ajout += 1
    sauver_json(SUIVI_PATH, suivi)
    return ajout


def xlsx(feuilles):
    """Écrit un classeur Excel minimal (chaînes inline) sans dépendance. feuilles = [(nom, [entêtes], [[lignes]])]."""
    def x(v):
        return str("" if v is None else v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
    def col(i):
        s_, i = "", i + 1
        while i:
            i, r = divmod(i - 1, 26)
            s_ = chr(65 + r) + s_
        return s_
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + "".join(f'<Override PartName="/xl/worksheets/sheet{i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(len(feuilles))) + "</Types>")
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + "".join(f'<sheet name="{x(n[:31])}" sheetId="{i+1}" r:id="rId{i+1}"/>' for i, (n, _, _) in enumerate(feuilles)) + "</sheets></workbook>")
        z.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + "".join(f'<Relationship Id="rId{i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i+1}.xml"/>' for i in range(len(feuilles))) + f'<Relationship Id="rId{len(feuilles)+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        z.writestr("xl/styles.xml", '<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="10"/><name val="Calibri"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF14314F"/></patternFill></fill></fills><borders count="1"><border/></borders><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" applyFont="1" applyFill="1"/></cellXfs></styleSheet>')
        for i, (nom, entetes, lignes) in enumerate(feuilles):
            rows = []
            for ri, row in enumerate([entetes] + lignes):
                cells = "".join(
                    (f'<c r="{col(ci)}{ri+1}"><v>{v}</v></c>' if ri > 0 and isinstance(v, (int, float)) and not isinstance(v, bool)
                     else f'<c r="{col(ci)}{ri+1}" t="inlineStr"{" s=\"1\"" if ri == 0 else ""}><is><t xml:space="preserve">{x(v)[:32000]}</t></is></c>')
                    for ci, v in enumerate(row))
                rows.append(f'<row r="{ri+1}">{cells}</row>')
            largeurs = "".join(f'<col min="{ci+1}" max="{ci+1}" width="{min(60, max(12, max([len(str(e))] + [len(str(l[ci])) for l in lignes[:500] if ci < len(l)]) + 2))}" customWidth="1"/>' for ci, e in enumerate(entetes))
            z.writestr(f"xl/worksheets/sheet{i+1}.xml", f'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>{largeurs}</cols><sheetData>{"".join(rows)}</sheetData><autoFilter ref="A1:{col(len(entetes)-1)}{len(lignes)+1}"/></worksheet>')
    return buf.getvalue()


ORDRE_CLASSE = {"vuln": 0, "verif": 1, "ok": 2, "neutre": 3}
# Degré de certitude que PHP est présent (et que la version est connue), du plus sûr au moins sûr
NIVEAUX_CERTITUDE = {5: "Confirmée (relevé sur le serveur)", 4: "Certaine (version annoncée)", 3: "Quasi certaine (indice fort)",
                     2: "Probable (plusieurs indices faibles)", 1: "Faible (un seul indice)"}
LIB_FINAL = {"vuln_conf": "VULNÉRABLE CONFIRMÉ", "vuln_pot": "POTENTIELLEMENT VULNÉRABLE", "verif": "À VÉRIFIER", "ok": "CORRIGÉ CONFIRMÉ"}


def machines_concernees():
    """Une ligne par machine où PHP a été vu (scan réseau, tous scans cumulés) ou relevé (scan hôtes).
    Statut retenu : le scan hôtes prime (vulnérable ou corrigé confirmé) ; sinon l'indice réseau."""
    serveurs = {x["ip"]: x for x in lire_json(SERVEURS_PATH, [])}
    noms_srv = {x["nom"].lower().split(".")[0]: x["ip"] for x in serveurs.values() if x.get("nom")}
    vlans = charger_vlans()
    par_ip = {}

    def machine(ip, nom=""):
        if ip not in par_ip:
            v = vlan_de(ip, vlans)
            srv = serveurs.get(ip, {})
            par_ip[ip] = {"ip": ip, "nom": srv.get("nom") or nom, "site": srv.get("site") or (v or {}).get("site", ""),
                          "vlan": (v or {}).get("nom", ""), "services": [], "versions_reseau": set(), "classe_reseau": "",
                          "statut_reseau": "", "versions_hote": set(), "classe_hote": "", "statut_hote": "", "vu_le": "",
                          "indices": [], "niveau": 0}
        elif nom and not par_ip[ip]["nom"]:
            par_ip[ip]["nom"] = nom
        return par_ip[ip]

    for r in services_cumules():
        if r.get("php_detecte") not in ("oui", "faible"):
            continue
        m = machine(r["ip"], r.get("nom", "") if not r.get("vhost") else "")
        m["services"].append(f"{r['port']}" + (f" ({r['nom']})" if r.get("vhost") and r.get("nom") else ""))
        if r.get("version_php"):
            m["versions_reseau"].add(r["version_php"])
        ind = [x.strip() for x in (r.get("indices") or "").split(" | ") if x.strip() and not x.startswith("[info]")]
        m["indices"] += [x for x in ind if x not in m["indices"]]
        fort = any(x.startswith("[fort]") for x in ind)
        niv = 4 if (r.get("version_php") and r.get("php_detecte") == "oui") else 3 if fort else 2 if r.get("php_detecte") == "oui" else 1
        m["niveau"] = max(m["niveau"], niv)
        c = r.get("classe", "neutre")
        if not m["classe_reseau"] or ORDRE_CLASSE.get(c, 3) < ORDRE_CLASSE.get(m["classe_reseau"], 3):
            m["classe_reseau"], m["statut_reseau"] = c, r.get("statut", "")
        sid = r.get("scan_id", "")
        quand = f"{sid[:4]}-{sid[4:6]}-{sid[6:8]} {sid[9:11]}:{sid[11:13]}" if len(sid) >= 13 else ""
        m["vu_le"] = max(m["vu_le"], quand)
    for h in lire_json(HOTES_PATH, []):
        if h.get("classe") not in ("vuln", "verif", "ok") and not h.get("version"):
            continue
        ip = h.get("ip") or noms_srv.get(h["serveur"].lower().split(".")[0], "")
        if not ip:
            ip = h["serveur"]
        m = machine(ip, h["serveur"])
        if h.get("version"):
            m["versions_hote"].add(h["version"])
            m["niveau"] = 5
        c = h.get("classe", "neutre")
        if not m["classe_hote"] or ORDRE_CLASSE.get(c, 3) < ORDRE_CLASSE.get(m["classe_hote"], 3):
            m["classe_hote"], m["statut_hote"] = c, h.get("statut", "")
        m["vu_le"] = max(m["vu_le"], (h.get("importe") or "").replace("T", " ")[:16])
    out = []
    norm = harmonisateur_sites()
    for m in par_ip.values():
        m["site"] = norm(m["site"])
        if m["classe_hote"] == "vuln":
            final = "vuln_conf"
        elif m["classe_hote"] == "ok" and m["classe_reseau"] != "vuln":
            final = "ok"
        elif m["classe_reseau"] == "vuln":
            final = "vuln_pot"
        elif m["classe_reseau"] == "ok" or m["classe_hote"] == "ok":
            final = "ok" if not m["classe_hote"] or m["classe_hote"] == "ok" else "verif"
        else:
            final = "verif"
        m["final"] = final
        m["statut"] = LIB_FINAL[final]
        m["classe"] = {"vuln_conf": "vuln", "vuln_pot": "vuln", "verif": "verif", "ok": "ok"}[final]
        m["niveau"] = m["niveau"] or 1
        m["certitude"] = NIVEAUX_CERTITUDE[m["niveau"]]
        m["indices"] = " | ".join(x.replace("[fort] ", "").replace("[faible] ", "(faible) ") for x in m["indices"])
        m["origine"] = " + ".join(x for x, c in (("réseau", m["classe_reseau"]), ("hôte", m["classe_hote"])) if c)
        m["services"] = ", ".join(sorted(set(m["services"]), key=lambda x: int(re.match(r"\d+", x).group(0)) if re.match(r"\d+", x) else 0))
        m["versions_reseau"] = ", ".join(sorted(m["versions_reseau"]))
        m["versions_hote"] = ", ".join(sorted(m["versions_hote"]))
        out.append(m)
    ordre = {"vuln_conf": 0, "vuln_pot": 1, "verif": 2, "ok": 3}

    def cle_ip(x):
        try:
            return (0, int(ipaddress.ip_address(x["ip"])))
        except ValueError:
            return (1, 0)
    return sorted(out, key=lambda x: (ordre[x["final"]], x["site"] or "~", cle_ip(x)))


# ---------------------------------------------------------------------------
# Consolidation territoriale (v2.10) : export du bilan d'un établissement, import des bilans des autres
# ---------------------------------------------------------------------------
CONSO_DIR = os.path.join(RESULTATS, "consolidation")
ETABLISSEMENTS = list(PARAMETRES["etablissements"])


def canon_etab(nom):
    """Écriture unique des hôpitaux du territoire (« CH TULLE », « CH-de-Tulle » → « CH Tulle »)."""
    n = (nom or "").strip()
    b = unicodedata.normalize("NFKD", n).encode("ascii", "ignore").decode().lower()
    def mots(x):
        return [m for m in re.split(r"[^a-z0-9]+", unicodedata.normalize("NFKD", x).encode("ascii", "ignore").decode().lower())
                if m and m not in ("ch", "chu", "chs", "centre", "hospitalier", "de", "du", "des", "la", "le", "les")]
    # tous les mots distinctifs présents, sinon le premier mot s'il ne désigne qu'un seul établissement
    complets = [c for c in ETABLISSEMENTS if mots(c) and all(m in b for m in mots(c))]
    if len(complets) == 1:
        return complets[0]
    premiers = [c for c in ETABLISSEMENTS if mots(c) and mots(c)[0] in b]
    if len(premiers) == 1:
        return premiers[0]
    return n


# Plan d'action (v2.11) : suivi de la remédiation, par machine ou par domaine (application, ensemble de serveurs)
PLAN_PATH = os.path.join(DATA, "plan_action.json")
ACTIONS_PLAN = {"patch": "Correctif (patch)", "reinstallation": "Réinstallation sur un nouveau serveur",
                "restriction": "Restriction d'accès", "arret": "Arrêt (application plus utilisée)", "acceptation": "Acceptation temporaire du risque"}
AVANCEMENTS_PLAN = ["À lancer", "En cours", "Terminé"]
DOMAINES_DEFAUT = ["Intranet", "Réanimation", "Radiothérapie", "Chimiothérapie", "Don d'organes et AVC", "Téléphonie",
                   "Gestion documentaire", "Dématérialisation"]
RESPONSABLES_DEFAUT = ["Pôle infrastructure", "Pôle support", "Pôle applications"]
CHAMPS_PLAN = ["demande", "reponse", "action", "responsable", "date_action", "avancement"]


def cle_machine(etab, ip):
    return f"{canon_etab(etab).lower()}|{ip}"


def lire_plan():
    pl = lire_json(PLAN_PATH, {})
    pl.setdefault("domaines", {})
    pl.setdefault("machines", {})
    return pl


def nettoyer_champs_plan(d):
    out = {}
    for k in CHAMPS_PLAN:
        if k in d:
            v = str(d.get(k) or "").strip()[:4000 if k == "reponse" else 500]
            if k == "action":
                v = ACTIONS_PLAN.get(v, v)[:200]
            if k == "avancement" and v and v not in AVANCEMENTS_PLAN:
                raise ValueError("Avancement inconnu")
            if k in ("demande", "date_action") and v and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
                raise ValueError("Date attendue au format AAAA-MM-JJ")
            out[k] = v
    return out


CHAMPS_COMPL = ["nom", "site", "vlan"]   # informations d'identification complétées à la main (vue territoire)


def maj_plan_machine(pl, etab, ip, d):
    """Met à jour le plan d'une machine : compléments (nom, site, VLAN), domaine, puis champs du plan
    (portés par le domaine si la machine y est rattachée)."""
    cm = pl["machines"].setdefault(cle_machine(etab, ip), {})
    for k in CHAMPS_COMPL:
        if k in d:
            v = str(d.get(k) or "").strip()[:120]
            cm.setdefault("complements", {})[k] = v
    if "domaine" in d:
        dom = str(d.get("domaine") or "").strip()[:80]
        if dom and dom not in pl["domaines"] and cm.get("domaine") != dom:
            # premier rattachement au domaine : il reprend le plan déjà saisi pour la machine
            pl["domaines"][dom] = {k: cm.get(k, "") for k in CHAMPS_PLAN}
        cm["domaine"] = dom
    champs = nettoyer_champs_plan(d)
    if champs:
        cible = pl["domaines"].setdefault(cm["domaine"], {}) if cm.get("domaine") else cm
        cible.update(champs)
        cible["modifie"] = datetime.now().isoformat(timespec="minutes")


def importer_complements(texte, appliquer):
    """Réponses saisies par un hôpital dans la page HTML exportée de la vue territoire (fichier .json).
    Seules les valeurs non vides et différentes de l'existant sont reprises ; les machines inconnues sont ignorées."""
    try:
        d = json.loads(texte)
    except ValueError:
        raise ValueError("Fichier de réponses illisible")
    if not isinstance(d, dict) or d.get("type") != "complements-plan" or not isinstance(d.get("lignes"), list):
        raise ValueError("Ce fichier n'est pas un fichier de réponses de la vue territoire")
    v = vue_territoire(True)
    connues = {cle_machine(m["etablissement"], m["ip"]): m for m in v["machines"]}
    pl = lire_plan()
    nb_machines, modifs, inconnues = 0, [], 0
    for l in d["lignes"][:20000]:
        if not isinstance(l, dict):
            continue
        cle = cle_machine(str(l.get("etablissement", "")), str(l.get("ip", "")))
        m = connues.get(cle)
        if not m:
            inconnues += 1
            continue
        ch = {}
        for k in CHAMPS_COMPL + ["domaine"] + CHAMPS_PLAN:
            val = str(l.get(k) or "").strip()
            if val and val != str(m.get(k) or "").strip():
                ch[k] = val
        if ch:
            nb_machines += 1
            modifs.append({"machine": f'{m.get("nom") or m["ip"]} ({m["etablissement"]})', "champs": sorted(ch)})
            if appliquer:
                maj_plan_machine(pl, m["etablissement"], m["ip"], ch)
                m.update(ch)
    if appliquer and nb_machines:
        sauver_json(PLAN_PATH, pl)
    return {"source": str(d.get("destinataire", ""))[:80], "date": str(d.get("date", ""))[:16], "lignes": len(d["lignes"]),
            "machines_modifiees": nb_machines, "modifications": sum(len(x["champs"]) for x in modifs), "detail": modifs[:50],
            "inconnues": inconnues, "applique": bool(appliquer)}


def appliquer_plan(machines):
    """Ajoute à chaque machine son domaine et les champs du plan : ceux du domaine s'il est renseigné, sinon les siens."""
    pl = lire_plan()
    for m in machines:
        cm = pl["machines"].get(cle_machine(m["etablissement"], m["ip"]), {})
        dom = (cm.get("domaine") or "").strip()
        src = pl["domaines"].get(dom, {}) if dom else cm
        for k, v in (cm.get("complements") or {}).items():
            if k in CHAMPS_COMPL and v:
                m[k + "_origine"] = m.get(k, "")
                m[k] = v
        m["domaine"] = dom
        m["plan_niveau"] = "domaine" if dom else "machine"
        for k in CHAMPS_PLAN:
            m[k] = src.get(k, "")
        m["action"] = ACTIONS_PLAN.get(m["action"], m["action"])   # anciens codes (2.11.0) -> libellé
        m["action_lib"] = m["action"]
    return pl
CHAMPS_BILAN = ["final", "statut", "classe", "niveau", "certitude", "site", "vlan", "ip", "nom", "services", "versions_reseau",
                "versions_hote", "origine", "indices", "statut_reseau", "statut_hote", "vu_le"]
FINALS = ("vuln_conf", "vuln_pot", "verif", "ok")


def slug_etab(nom):
    s = re.sub(r"[^a-z0-9]+", "_", unicodedata.normalize("NFKD", nom).encode("ascii", "ignore").decode().lower()).strip("_")
    return s[:60] or "etablissement"


def bilan_export(etablissement):
    etablissement = (etablissement or CONFIG.get("etablissement") or "").strip()[:80]
    if not etablissement:
        raise ValueError("Indiquer le nom de l'établissement")
    machines = [{k: m.get(k, "") for k in CHAMPS_BILAN} for m in machines_concernees()]
    return {"application": APP_ID, "type": "bilan-consolidation", "format": 1, "version": VERSION, "etablissement": etablissement,
            "date": datetime.now().isoformat(timespec="minutes"), "machines": machines, "sites": bilan_sites(),
            "mention": MENTION}


def lire_bilan(texte):
    """Valide un bilan reçu d'un autre établissement : fichier non fiable, on ne garde que des champs connus, en texte."""
    try:
        d = json.loads(texte)
    except ValueError:
        raise ValueError("Fichier illisible : un bilan exporté par Inventaire PHP (fichier .json) est attendu")
    if not isinstance(d, dict) or d.get("type") != "bilan-consolidation" or not isinstance(d.get("machines"), list):
        raise ValueError("Ce fichier n'est pas un bilan Inventaire PHP (menu 4 · Résultats › « Exporter mon bilan »)")
    if len(d["machines"]) > 50000:
        raise ValueError("Bilan trop volumineux")
    etab = str(d.get("etablissement", "")).strip()[:80]
    if not etab:
        raise ValueError("Bilan sans nom d'établissement")
    machines = []
    for m in d["machines"]:
        if not isinstance(m, dict):
            continue
        x = {k: str(m.get(k, "") if m.get(k) is not None else "")[:1000] for k in CHAMPS_BILAN}
        x["final"] = x["final"] if x["final"] in FINALS else "verif"
        x["classe"] = {"vuln_conf": "vuln", "vuln_pot": "vuln", "verif": "verif", "ok": "ok"}[x["final"]]
        x["statut"] = LIB_FINAL[x["final"]]
        try:
            x["niveau"] = max(1, min(5, int(m.get("niveau") or 1)))
        except (TypeError, ValueError):
            x["niveau"] = 1
        x["certitude"] = NIVEAUX_CERTITUDE[x["niveau"]]
        machines.append(x)
    sites = [{k: (v if isinstance(v, (int, float)) else str(v)[:120]) for k, v in s.items()} for s in d.get("sites", []) if isinstance(s, dict)][:200]
    return {"etablissement": canon_etab(etab), "date": str(d.get("date", ""))[:16], "version": str(d.get("version", ""))[:12],
            "machines": machines, "sites": sites}


ENTETES_MACHINES = {"statut": "statut", "certitude php": "certitude", "certitude": "certitude", "site": "site", "vlan": "vlan", "ip": "ip",
                    "nom": "nom", "ports php": "services", "services": "services", "version vue (réseau)": "versions_reseau",
                    "versions_reseau": "versions_reseau", "version installée (hôte)": "versions_hote", "versions_hote": "versions_hote",
                    "origine": "origine", "indices": "indices", "détail réseau": "statut_reseau", "statut_reseau": "statut_reseau",
                    "détail hôte": "statut_hote", "statut_hote": "statut_hote", "dernière observation": "vu_le", "vu_le": "vu_le"}
FINAL_DE_STATUT = {"vulnérable confirmé": "vuln_conf", "potentiellement vulnérable": "vuln_pot", "à vérifier": "verif",
                   "corrigé confirmé": "ok", "corrigé": "ok"}


def bilan_depuis_export(octets, etablissement=""):
    """Bilan reconstitué à partir d'un export d'une version antérieure (2.7 à 2.9) : CSV « Machines concernées »
    (inventaire_php_machines.csv) ou classeur « Export Excel complet » (feuille Machines concernées)."""
    date = ""
    if octets[:2] == b"PK":
        noms = []
        try:
            with zipfile.ZipFile(io.BytesIO(octets)) as z:
                noms = re.findall(r'<sheet[^>]*name="([^"]+)"', z.read("xl/workbook.xml").decode("utf-8", "replace"))
        except (zipfile.BadZipFile, KeyError):
            raise ValueError("Classeur Excel illisible")
        if "Machines concernées" not in noms:
            raise ValueError("Ce classeur n'a pas de feuille « Machines concernées » : utiliser l'« Export Excel complet » du menu 4 · Résultats")
        texte = xlsx_vers_texte(octets, ("Machines concernées",))
        if "Lisez-moi" in noms:
            m = re.search(r"Généré le\t(\d{4}-\d{2}-\d{2} \d{2}:\d{2})", xlsx_vers_texte(octets, ("Lisez-moi",)))
            date = m.group(1).replace(" ", "T") if m else ""
    else:
        texte = texte_importe(octets)
        m = re.match(r"\ufeff?#.*?(\d{4}-\d{2}-\d{2} \d{2}:\d{2})", texte)
        date = m.group(1).replace(" ", "T") if m else ""
    entetes, lignes, _ = lire_tableau(texte)
    cols = {ENTETES_MACHINES[e.strip().lower()]: i for i, e in enumerate(entetes) if e.strip().lower() in ENTETES_MACHINES}
    if "ip" not in cols or "statut" not in cols:
        raise ValueError("Colonnes « Statut » et « IP » introuvables : fichier attendu = export « Machines concernées » (CSV) ou « Export Excel complet »")
    niv = {v.split(" (")[0].lower(): k for k, v in NIVEAUX_CERTITUDE.items()}
    machines = []
    for l in lignes:
        val = lambda k: l[cols[k]].strip() if k in cols and cols[k] < len(l) else ""
        if not val("ip"):
            continue
        st = val("statut").lower()
        m = {k: val(k) for k in CHAMPS_BILAN if k in cols}
        m["final"] = next((f for t, f in FINAL_DE_STATUT.items() if st.startswith(t)), "verif")
        m["niveau"] = niv.get(val("certitude").split(" (")[0].lower(), 1)
        machines.append(m)
    if not etablissement:
        sites = [m.get("site", "") for m in machines if m.get("site")]
        etablissement = max(set(sites), key=sites.count) if sites else ""
    return lire_bilan(json.dumps({"type": "bilan-consolidation", "etablissement": etablissement or "Établissement à nommer",
                                  "date": date, "version": "antérieure", "machines": machines}))


def lire_bilan_recu(octets, q):
    """Bilan .json de la version 2.10, ou export d'une version antérieure (CSV / Excel), avec nom d'établissement saisi."""
    etab = q.get("etablissement", [""])[0].strip()[:80]
    date = q.get("date", [""])[0].strip()[:16]
    if octets.lstrip(b"\xef\xbb\xbf \r\n\t")[:1] == b"{":
        b = lire_bilan(octets.decode("utf-8", "replace"))
        if etab:
            b["etablissement"] = etab
    else:
        b = bilan_depuis_export(octets, etab)
        b["ancien_format"] = True
        if date and not b["date"]:
            b["date"] = date
    return b


def bilans_importes():
    out = []
    if os.path.isdir(CONSO_DIR):
        for f in sorted(os.listdir(CONSO_DIR)):
            if f.endswith(".json"):
                b = lire_json(os.path.join(CONSO_DIR, f), None)
                if isinstance(b, dict) and b.get("etablissement"):
                    b["fichier"] = f
                    b["etablissement"] = canon_etab(b["etablissement"])
                    out.append(b)
    return out


def resume_bilan(etab, date, version, importe, machines, local=False, sites=None):
    """Une ligne par hôpital : statuts comptés par machine, plus le contexte du scan (serveurs, services) quand le bilan le fournit.
    Sous-lignes par site quand le bilan en compte plusieurs."""
    def compte(ms):
        return {k: sum(1 for m in ms if m["final"] == k) for k in FINALS}
    def contexte(ss):
        if not ss:
            return {"serveurs": None, "services": None, "php": None, "hotes": None}
        return {k: sum(int(x.get(k) or 0) for x in ss if isinstance(x.get(k, 0), (int, float)) or str(x.get(k, "")).isdigit()) for k in ("serveurs", "services", "php", "hotes")}
    ligne = {"etablissement": etab, "date": date, "version": version, "importe": importe, "local": local, "machines": len(machines),
             **compte(machines), **contexte(sites)}
    noms_sites = sorted({(x.get("site") or "") for x in (sites or [])} | {(m.get("site") or "") for m in machines})
    if len([n for n in noms_sites if n]) > 1:
        ligne["sites"] = []
        for n in noms_sites:
            ms = [m for m in machines if (m.get("site") or "") == n]
            ss = [x for x in (sites or []) if (x.get("site") or "") == n]
            ligne["sites"].append(dict(site=n or "(site non renseigné)", machines=len(ms), **compte(ms), **contexte(ss)))
    return ligne


def vue_territoire(avec_local=True):
    machines, resumes = [], []
    if avec_local:
        loc = machines_concernees()
        nom = canon_etab(CONFIG.get("etablissement") or "") or "Ce poste"
        maint = datetime.now().isoformat(timespec="minutes")
        for m in loc:
            machines.append(dict({k: m.get(k, "") for k in CHAMPS_BILAN}, etablissement=nom, date_bilan=(m.get("vu_le") or "").replace(" ", "T")))
        scans = liste_scans()
        dernier = max([(x.get("date") or "") for x in scans[:1]] + [(m.get("vu_le") or "").replace(" ", "T") for m in loc] + [""])
        r = resume_bilan(nom, dernier[:16] or maint, VERSION, "", loc, True, bilan_sites())
        resumes.append(r)
    for b in bilans_importes():
        if avec_local and b["etablissement"].lower() == canon_etab(CONFIG.get("etablissement") or "").lower():
            continue
        for m in b["machines"]:
            machines.append(dict(m, etablissement=b["etablissement"], date_bilan=(m.get("vu_le") or "").replace(" ", "T")[:16] or b["date"]))
        resumes.append(resume_bilan(b["etablissement"], b["date"], b.get("version", ""), b.get("importe", ""), b["machines"], sites=b.get("sites") or None))
    ordre = {"vuln_conf": 0, "vuln_pot": 1, "verif": 2, "ok": 3}
    machines.sort(key=lambda x: (ordre.get(x["final"], 9), x["etablissement"], x.get("site") or "~", x.get("ip", "")))
    pl = appliquer_plan(machines)
    doms = {}
    for m in machines:
        if m["domaine"]:
            d = doms.setdefault(m["domaine"], {"domaine": m["domaine"], "machines": [], "etablissements": set(), "pire": 9})
            d["machines"].append(f'{m.get("nom") or m["ip"]} ({m["etablissement"]})')
            d["etablissements"].add(m["etablissement"])
            d["pire"] = min(d["pire"], ordre.get(m["final"], 9))
    domaines = []
    for nom_d, d in sorted(doms.items()):
        x = dict(pl["domaines"].get(nom_d, {}))
        x["action"] = ACTIONS_PLAN.get(x.get("action", ""), x.get("action", ""))
        domaines.append(dict({k: x.get(k, "") for k in CHAMPS_PLAN}, domaine=nom_d, nb=len(d["machines"]), machines=d["machines"],
                             etablissements=sorted(d["etablissements"]), pire=["vuln_conf", "vuln_pot", "verif", "ok"][d["pire"]] if d["pire"] < 4 else "verif"))
    connus = sorted(set(DOMAINES_DEFAUT) | set(doms) | set(pl["domaines"]), key=str.lower)
    resp = sorted(set(RESPONSABLES_DEFAUT) | {m["responsable"] for m in machines if m.get("responsable")}, key=str.lower)
    actions = list(ACTIONS_PLAN.values()) + sorted({m["action"] for m in machines if m.get("action") and m["action"] not in ACTIONS_PLAN.values()}, key=str.lower)
    return {"etablissements": resumes, "machines": machines, "domaines": domaines, "listes": {"domaines": connus, "responsables": resp,
            "actions": actions, "avancements": AVANCEMENTS_PLAN}, "sans_domaine": sum(1 for m in machines if not m["domaine"])}


CHAMPS_MACHINES = ["statut", "certitude", "site", "vlan", "ip", "nom", "services", "versions_reseau", "versions_hote", "origine",
                   "indices", "statut_reseau", "statut_hote", "vu_le"]


def classeur_bilan():
    scans = liste_scans()
    scan = charger_scan(scans[0]["id"]) if scans else None
    serveurs = {x["ip"]: x for x in lire_json(SERVEURS_PATH, [])}
    f = []
    f.append(("Lisez-moi", ["Information", "Valeur"], [
        ["Mention", MENTION], ["Application", f"Inventaire PHP v{VERSION}"], ["Généré le", f"{datetime.now():%Y-%m-%d %H:%M}"],
        ["Dernier scan", scan["id"] if scan else "aucun"], ["État du dernier scan", (scan.get("etat", "terminé") if scan else "")],
        ["Moteur", scan.get("moteur", "") if scan else ""], ["Périmètre", ", ".join(scan["cibles"]) if scan else ""],
        ["Exclusions", ", ".join(scan["exclusions"]) if scan else ""],
        ["Avertissement", "Un scan interrompu ou échoué n'est pas un inventaire complet." if scan and scan.get("etat", "terminé") != "terminé" else ""],
        ["TLS", "Les connexions HTTPS 'non vérifié' n'authentifient pas le serveur interrogé."]]))
    b = bilan_sites(scan)
    f.append(("Synthèse par site", ["Site", "Serveurs connus", "Services web (tous scans)", "Services PHP", "Potentiellement vulnérables (bannière)", "À vérifier", "Serveurs scannés (hôtes)", "Vulnérables confirmés", "Correctifs confirmés"],
              [[l["site"], l["serveurs"], l["services"], l["php"], l["pot_vuln"], l["a_verifier"], l["hotes"], l["vuln_confirme"], l["corrige"]] for l in b]))
    if scan:
        f.append((f"Scan {scan['id']}" + (" INCOMPLET" if scan.get("etat", "terminé") != "terminé" else ""), ["Site", "IP", "Nom", "Port", "URL", "Titre", "Server", "X-Powered-By", "PHP détecté", "Version", "Source", "TLS", "Statut", "Indices", "Redirection"],
                  [[serveurs.get(r["ip"], {}).get("site", ""), r["ip"], r.get("nom", "") + (" [vhost]" if r.get("vhost") else ""), r["port"], r["url"], r["titre"], r["server"], r["x_powered_by"], r["php_detecte"], r["version_php"], r.get("source_version", ""), r.get("tls", ""), r["statut"], r["indices"], r.get("redirection", "")] for r in scan["resultats"]]))
    f.append(("Machines concernées", ["Statut", "Certitude PHP", "Site", "VLAN", "IP", "Nom", "Ports PHP", "Version vue (réseau)", "Version installée (hôte)",
                                       "Origine", "Indices", "Détail réseau", "Détail hôte", "Dernière observation"],
              [[m[k] for k in CHAMPS_MACHINES] for m in machines_concernees()]))
    f.append(("Scan hôtes", ["Site", "Serveur", "IP", "Origine", "Source", "Détail", "Version", "Statut", "Relevé le"],
              [[serveurs.get(h.get("ip", ""), {}).get("site", ""), h["serveur"], h.get("ip", ""), h["origine"], h["source"], h["detail"], h["version"], h["statut"], h["importe"]] for h in lire_json(HOTES_PATH, [])]))
    f.append(("Suivi des corrections", ["Site", "Cible", "Nom", "Constat", "Origine", "Responsable", "Échéance", "État", "Preuve", "Commentaire", "Créé le"],
              [[x["site"], x["cible"], x["nom"], x["constat"], x["origine"], x["responsable"], x["echeance"], x["etat"], x["preuve"], x["commentaire"], x["cree"]] for x in lire_json(SUIVI_PATH, [])]))
    f.append(("Applications externes", ["Site", "Application", "Hébergeur", "Contact", "URL", "État", "Demande envoyée le", "Réponse", "Version confirmée", "Commentaire"],
              [[x["site"], x["nom"], x["hebergeur"], x["contact"], x["url"], x["etat"], x["date_demande"], x["reponse"], x["version_confirmee"], x["commentaire"]] for x in lire_json(EXTERNES_PATH, [])]))
    return xlsx(f)


# Page HTML autonome exportée depuis la vue territoire, à compléter par un hôpital (v2.12)
# Modèle de la page « HTML à compléter » : interface/complements.html, construit dans inventaire_php_complements.html



# ---------------------------------------------------------------------------
# Interface
# ---------------------------------------------------------------------------
# Interface : interface/source.html, construite par outils/construire.py dans inventaire_php_interface.html



# ---------------------------------------------------------------------------
# Serveur HTTP
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Interface (page construite par outils/construire.py avec la charte commune, à côté du programme)
# ---------------------------------------------------------------------------
INTERFACE_FICHIER = os.path.join(BASE, "inventaire_php_interface.html")
COMPLEMENTS_FICHIER = os.path.join(BASE, "inventaire_php_complements.html")
_SCRIPT_EN_LIGNE = re.compile(r'<script(?![^>]*\btype="application/json")[^>]*>(.*?)</script>', re.S)
_LOGOS_ENTETE = re.compile(r'<img class="hc-logo hc-logo-blanc"[^>]*><img class="hc-logo hc-logo-couleur"[^>]*>')


def habillage_organisation(page):
    """Si l'organisation configurée n'est pas celle de l'auteur, habillage neutre : le logo laisse place au nom de
    l'organisation et le bandeau la nomme ; le crédit d'auteur reste. Les scripts ne sont jamais modifiés (CSP)."""
    org = str(PARAMETRES.get("organisation") or "").strip()
    if not page or not org or org.lower() == ORGANISATION_ORIGINE.lower():
        return page
    org_html = org.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    sortie = []
    for i, part in enumerate(re.split(r"(<script\b.*?</script>)", page, flags=re.S)):
        if i % 2 == 0:   # hors scripts seulement
            part = _LOGOS_ENTETE.sub(f'<span class="hc-logo" style="height:auto;max-width:170px;'
                                     f'font:800 14.5px/1.2 var(--hc-police);color:inherit">{org_html}</span>', part)
            part = part.replace(f"{ORGANISATION_ORIGINE} (Brive · Tulle · Ussel · Bort)",
                                f"{ORGANISATION_ORIGINE}, partagé avec {org_html}")
            part = part.replace(f"<p>{ORGANISATION_ORIGINE} · ", f"<p>{org_html} · ")
            part = part.replace(f'alt="{ORGANISATION_ORIGINE}"', f'alt="{org_html}"')
        sortie.append(part)
    return "".join(sortie)
_INTERFACE = {}


def charger_interface():
    """Page de l'interface et sa politique de sécurité du contenu : chaque script en ligne est autorisé par son
    empreinte SHA-256 (aucun autre script, aucune ressource extérieure, aucun cadre)."""
    if not _INTERFACE:
        try:
            with open(INTERFACE_FICHIER, encoding="utf-8") as f:
                page = habillage_organisation(f.read())
        except OSError:
            page = None
        empreintes = sorted({"'sha256-" + base64.b64encode(hashlib.sha256(x.encode("utf-8")).digest()).decode() + "'"
                             for x in _SCRIPT_EN_LIGNE.findall(page or "")})
        _INTERFACE.update({"page": page, "csp": "; ".join([
            "default-src 'none'", "script-src " + (" ".join(empreintes) or "'none'"), "style-src 'unsafe-inline'",
            "img-src 'self' data: blob:", "font-src data:", "connect-src 'self'", "base-uri 'none'",
            "form-action 'none'", "object-src 'none'", "frame-ancestors 'none'"])})
    return _INTERFACE


def nom_cookie():
    return f"jeton_inventaire_php_{PORT_ECOUTE}"   # un cookie par port : deux instances ne se gênent pas


PAGE_REFUS = """<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Inventaire PHP — accès refusé</title>
<style>body{font:15px/1.5 Calibri,Carlito,"Segoe UI",Arial,sans-serif;margin:40px auto;max-width:640px;padding:0 16px;color:#1b2430}
h1{color:#B71251;font-size:20px}code{background:#eef3f9;padding:1px 5px;border-radius:4px}</style></head><body>
<h1>Accès refusé : jeton de session absent ou périmé</h1>
<p>L'outil n'accepte que les requêtes munies du jeton tiré à son lancement. Ouvrez-le depuis « Inventaire PHP.bat »
(le navigateur s'ouvre alors sur la bonne adresse), ou recopiez l'adresse complète, avec son <code>?jeton=…</code>,
affichée dans la fenêtre noire de l'outil.</p></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _securite(self, csp=None):
        """En-têtes de sécurité de toutes les réponses (cadre S2)."""
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("Content-Security-Policy", csp or "default-src 'none'; frame-ancestors 'none'; base-uri 'none'")

    def _json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self._securite()
        self.end_headers()
        self.wfile.write(data)

    def _fichier(self, data, ctype, nom=None, code=200, csp=None):
        if isinstance(data, str):
            data = data.encode("utf-8-sig" if ctype.startswith("text/csv") else "utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        if nom:
            self.send_header("Content-Disposition", f'attachment; filename="{nom}"')
        self.send_header("Content-Length", str(len(data)))
        self._securite(csp)
        self.end_headers()
        self.wfile.write(data)

    def _jeton_valide(self, q=None, en_tete_seul=False):
        """Jeton de session : en-tête X-Jeton (requêtes de l'interface), sinon cookie de session posé à l'ouverture
        (téléchargements par lien), sinon ?jeton= sur la seule page d'accueil. Comparaison à temps constant."""
        candidats = [self.headers.get("X-Jeton") or ""]
        if not en_tete_seul:
            for morceau in (self.headers.get("Cookie") or "").split(";"):
                k, _, v = morceau.strip().partition("=")
                if k == nom_cookie():
                    candidats.append(v)
            if q:
                candidats += q.get("jeton", [])[:1]
        return any(c and hmac.compare_digest(c.encode("utf-8"), JETON.encode("utf-8")) for c in candidats)

    @staticmethod
    def _csv(lignes, champs):
        buf = io.StringIO()
        buf.write(f"# {MENTION} — Inventaire PHP v{VERSION} — {datetime.now():%Y-%m-%d %H:%M}\n")
        w = csv.DictWriter(buf, fieldnames=champs, delimiter=";", extrasaction="ignore")
        w.writeheader()
        w.writerows(lignes)
        return buf.getvalue()

    TAILLE_MAX = 20 * 1024 * 1024  # 20 Mo par requête (imports CSV / DNS)

    def _corps(self):
        return self._octets().decode("utf-8", "ignore")

    def _octets(self):
        if hasattr(self, "_brut"):
            return self._brut
        n = int(self.headers.get("Content-Length", 0) or 0)
        if n > self.TAILLE_MAX:
            raise ValueError(f"Requête trop volumineuse ({n // 1024 // 1024} Mo, maximum 20 Mo)")
        self._brut = self.rfile.read(n) if n else b""
        return self._brut

    def _hote_legitime(self):
        h = (self.headers.get("Host") or "").lower()
        return re.fullmatch(rf"(127\.0\.0\.1|localhost)(:{PORT_ECOUTE})?", h) is not None

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        p = u.path
        if not self._hote_legitime():
            return self._json({"erreur": "En-tête Host inattendu"}, 421)
        if p == "/" and "jeton" in q:
            # ouverture par le lanceur : jeton dans l'adresse, échangé contre un cookie de session, puis adresse nettoyée
            if not self._jeton_valide(q):
                return self._fichier(PAGE_REFUS, "text/html; charset=utf-8", code=403)
            self.send_response(303)
            self.send_header("Location", "/")
            self.send_header("Set-Cookie", f"{nom_cookie()}={JETON}; Path=/; HttpOnly; SameSite=Strict")
            self.send_header("Content-Length", "0")
            self._securite()
            self.end_headers()
            return
        if not self._jeton_valide():
            if p == "/":
                return self._fichier(PAGE_REFUS, "text/html; charset=utf-8", code=403)
            return self._json({"erreur": "Requête refusée (jeton de session absent) : rouvrir l'outil depuis son lanceur"}, 403)
        if p == "/":
            ihm = charger_interface()
            if not ihm["page"]:
                return self._json({"erreur": f"Interface introuvable : {INTERFACE_FICHIER} (réinstaller l'outil)"}, 500)
            return self._fichier(ihm["page"].replace("__JETON__", JETON), "text/html; charset=utf-8", csp=ihm["csp"])
        if p == "/api/config":
            ref = ", ".join(f"{k} >= {'.'.join(map(str, v))}" for k, v in VERSIONS_CORRIGEES.items())
            ref += f" ; < {'.'.join(map(str, BRANCHE_MIN_MAINTENUE))} : branche non maintenue, sans correctif"
            scans = liste_scans()
            d = {k: CONFIG[k] for k in ("plages_autorisees", "exclusions", "ports", "debit", "planif_actif", "planif_heure",
                                        "planif_jours", "planif_cibles", "planif_inventaire_linux", "smtp_serveur", "smtp_port", "smtp_tls",
                                        "smtp_de", "smtp_a", "ps_approfondi", "plafond_hotes", "moteur", "py_connexions", "tls_verifier", "ca_interne", "retention_jours",
                                        "perimetre_vlans", "perimetre_serveurs", "perimetre_noms", "perimetre_adresses", "etablissement")}
            d["etablissements"] = ETABLISSEMENTS
            d["organisation"] = PARAMETRES["organisation"]
            d["mention_parametre"] = PARAMETRES["mention"]
            d.update({"cve": CVE_LIBELLE, "version": VERSION, "etats_suivi": ETATS_SUIVI, "etats_externe": ETATS_EXTERNE, "referentiel": ref, "chemins": f"{DATA}  (config.json, serveurs.json, hotes.json, scan_*.json)",
                      "scan_courant": ETAT["scan_id"] or (scans[0]["id"] if scans else None), "systeme": platform.system()})
            return self._json(d)
        if p == "/api/status":
            with VERROU:
                d = {k: ETAT.get(k) for k in ("en_cours", "phase", "fait", "total", "journal", "scan_id", "erreur", "pourcent", "restant", "nmap_pourcent",
                                               "courant", "courant_lib", "adresses_total", "adresses_vues", "moteur_utilise")}
                d["fil"] = ETAT["fil"][-300:]
                d["ecoule"] = int(time.time() - ETAT["debut"]) if ETAT["debut"] else None
                return self._json(d)
        if p == "/api/inventaire/status":
            with VERROU:
                d = {k: ETAT_INV[k] for k in ("en_cours", "phase", "fait", "total", "journal", "erreur", "courant")}
                d["fil"] = ETAT_INV["fil"][-300:]
                return self._json(d)
        if p == "/api/mise-a-jour":
            return self._json(etat_mises_a_jour())
        if p == "/api/diagnostic":
            return self._json(diagnostic(False))   # rapide, sans connexion aux serveurs ; le complet passe par POST
        if p == "/api/machines":
            return self._json(machines_concernees())
        if p == "/api/consolidation":
            return self._json(vue_territoire(q.get("local", ["1"])[0] == "1"))
        if p == "/api/modele/complements":
            try:
                with open(COMPLEMENTS_FICHIER, encoding="utf-8") as f:
                    return self._fichier(f.read(), "text/plain; charset=utf-8")
            except OSError:
                return self._json({"erreur": f"Modèle introuvable : {COMPLEMENTS_FICHIER} (réinstaller l'outil)"}, 500)
        if p == "/api/consolidation/export.csv":
            v = vue_territoire(q.get("local", ["1"])[0] == "1")
            return self._fichier(self._csv(v["machines"], ["etablissement", "date_bilan"] + CHAMPS_MACHINES + ["domaine", "demande", "reponse", "action_lib", "responsable", "date_action", "avancement"]),
                                 "text/csv; charset=utf-8", "inventaire_php_territoire.csv")
        if p == "/api/consolidation/bilan":
            b = bilan_export(q.get("etablissement", [""])[0])
            return self._fichier(json.dumps(b, ensure_ascii=False, indent=1), "application/json; charset=utf-8",
                                 f"bilan_inventaire_php_{slug_etab(b['etablissement'])}_{b['date'][:10]}.json")
        if p == "/api/machines/export":
            return self._fichier(self._csv(machines_concernees(), CHAMPS_MACHINES), "text/csv; charset=utf-8", "inventaire_php_machines.csv")
        if p == "/api/bilan":
            return self._json({"sites": bilan_sites(), "scans": len(liste_scans()),
                               "hotes": len({(h.get("ip") or h["serveur"]).lower() for h in lire_json(HOTES_PATH, [])})})
        if p == "/api/suivi":
            return self._json(lire_json(SUIVI_PATH, []))
        if p == "/api/vlans":
            return self._json({"vlans": charger_vlans(), "decisions": DECISIONS_VLAN})
        if p == "/api/vlans/export.csv":
            lignes = [{"nom": v["nom"], "plages": ", ".join(v["plages"]), "contenu": v.get("contenu", ""), "decision": DECISIONS_VLAN.get(v["decision"], v["decision"]),
                       "site": v.get("site", ""), "commentaire": v.get("commentaire", "")} for v in charger_vlans()]
            return self._fichier(self._csv(lignes, ["nom", "plages", "contenu", "decision", "site", "commentaire"]), "text/csv; charset=utf-8", "vlans.csv")
        if p == "/api/vlans/export":
            return self._fichier(json.dumps(charger_vlans(), ensure_ascii=False, indent=1), "application/json; charset=utf-8", "vlans.json")
        if p == "/api/noms":
            return self._json(lire_json(NOMS_PATH, []))
        if p == "/api/noms/export":
            return self._fichier(self._csv(lire_json(NOMS_PATH, []), ["nom", "ip", "etat", "site", "source", "importe"]), "text/csv; charset=utf-8", "noms_hotes.csv")
        if p == "/api/externes":
            return self._json(lire_json(EXTERNES_PATH, []))
        if p == "/api/sauvegarde":
            return self._fichier(sauvegarde_zip(), "application/zip", f"sauvegarde_inventaire_php_{datetime.now():%Y%m%d_%H%M}.zip")
        if p == "/api/export/excel":
            return self._fichier(classeur_bilan(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", f"Inventaire_PHP_{datetime.now():%Y%m%d}.xlsx")
        if p == "/api/planification/status":
            pr = prochain_passage() if CONFIG["planif_actif"] else None
            with VERROU:
                d = dict(ETAT_PLANIF)
            d["prochain"] = pr.isoformat(timespec="minutes") if pr else None
            return self._json(d)
        if p == "/api/results":
            d = charger_scan(q.get("id", [""])[0])
            return self._json(d) if d else self._json({"erreur": "scan introuvable"}, 404)
        if p == "/api/scans":
            return self._json(liste_scans())
        if p == "/api/export":
            d = charger_scan(q.get("id", [""])[0])
            if not d:
                return self._json({"erreur": "scan introuvable"}, 404)
            champs = ["site", "ip", "nom", "port", "url", "titre", "server", "x_powered_by", "php_detecte", "version_php", "source_version", "tls", "statut", "indices", "redirection"]
            return self._fichier(self._csv(d["resultats"], champs), "text/csv; charset=utf-8", f"inventaire_php_reseau_{d['id']}.csv")
        if p == "/api/serveurs":
            return self._json(serveurs_annotes())
        if p == "/api/serveurs/export":
            return self._fichier(self._csv(serveurs_annotes(), ["ip", "nom", "os", "site", "commentaire", "autorise"]), "text/csv; charset=utf-8", "serveurs.csv")
        if p == "/api/hotes":
            return self._json(lire_json(HOTES_PATH, []))
        if p == "/api/hotes/export":
            return self._fichier(self._csv(lire_json(HOTES_PATH, []), ["serveur", "ip", "origine", "source", "detail", "version", "statut", "importe"]), "text/csv; charset=utf-8", "inventaire_php_hotes.csv")
        if p == "/api/script/windows":
            return self._fichier("\ufeff" + SCRIPT_WINDOWS.lstrip(), "text/plain; charset=utf-8", "inventaire_php_windows.ps1")
        if p == "/api/script/linux":
            return self._fichier("#!/usr/bin/env bash\n# À exécuter sur chaque serveur : ssh hote bash -s < inventaire_php_linux_distant.sh\n" + SCRIPT_LINUX_DISTANT.lstrip(), "text/plain; charset=utf-8", "inventaire_php_linux_distant.sh")
        self._json({"erreur": "introuvable"}, 404)

    def _requete_legitime(self):
        """Anti-CSRF : jeton de session tiré au lancement, exigé dans l'en-tête X-Jeton (un cookie ne suffit pas),
        et contrôle de l'origine."""
        if not self._jeton_valide(en_tete_seul=True):
            return False
        if self.headers.get("Sec-Fetch-Site") not in (None, "same-origin", "none"):
            return False
        origine = self.headers.get("Origin") or self.headers.get("Referer") or ""
        if origine and not re.match(rf"^https?://(127\.0\.0\.1|localhost)(:{PORT_ECOUTE})?(/|$)", origine):
            return False
        return True

    def do_POST(self):
        self.__dict__.pop("_brut", None)
        u = urlparse(self.path)
        q = parse_qs(u.query)
        p = u.path
        if not self._hote_legitime():
            return self._json({"erreur": "En-tête Host inattendu"}, 421)
        if not self._requete_legitime():
            return self._json({"erreur": "Requête refusée (jeton de session absent ou origine inconnue) : rechargez la page"}, 403)
        try:
            corps = self._corps()
        except ValueError as e:
            return self._json({"erreur": str(e)}, 413)
        try:
            if p == "/api/diagnostic":
                return self._json(diagnostic(True))   # complet : essais SSH, WinRM et messagerie vers des serveurs de la liste
            if p == "/api/config":
                d = json.loads(corps or "{}")
                plages = [x.strip() for x in d.get("plages_autorisees", []) if x.strip()]
                excl = [x.strip() for x in d.get("exclusions", []) if x.strip()]
                parse_reseaux(plages)
                parse_reseaux(excl)
                ports = (d.get("ports") or PORTS_DEFAUT).replace(" ", "")
                if not re.fullmatch(r"[\d,\-]+", ports):
                    raise ValueError("Liste de ports invalide")
                ajoutees = [x for x in plages if x not in CONFIG["plages_autorisees"]]
                if ajoutees and not d.get("confirme_ajout"):
                    return self._json({"confirmation": ajoutees})
                CONFIG.update({"plages_autorisees": plages, "exclusions": excl, "ports": ports,
                               "debit": max(20, min(int(d.get("debit") or 200), 2000)),
                               "ps_approfondi": bool(d.get("ps_approfondi")),
                               "plafond_hotes": max(256, min(int(d.get("plafond_hotes") or 4096), 1 << 20)),
                               "moteur": d.get("moteur") if d.get("moteur") in ("auto", "nmap", "python") else "auto",
                               "py_connexions": max(1, min(64, int(d.get("py_connexions") or 16))),
                               "tls_verifier": bool(d.get("tls_verifier", True)),
                               "ca_interne": (d.get("ca_interne") or "").strip()[:500],
                               "retention_jours": max(0, min(int(d.get("retention_jours") or 365), 3650))})
                sauver_json(CONFIG_PATH, CONFIG)
                return self._json({"ok": True, "ajoutees": ajoutees})
            if p == "/api/serveurs/apercu":
                return self._json(apercu_import(texte_importe(self._octets()), CHAMPS_SERVEUR))
            if p == "/api/serveurs/import":
                mp = q.get("mapping", [""])[0]
                return self._json(importer_serveurs(texte_importe(self._octets()), json.loads(mp) if mp else None, q.get("remplacer", ["0"])[0] == "1"))
            if p == "/api/vlans/apercu":
                if corps.lstrip().startswith("["):
                    return self._json({"json": True, "nb_lignes": len(json.loads(corps))})
                return self._json(apercu_import(texte_importe(self._octets()), CHAMPS_VLAN))
            if p == "/api/vlans/import-tableau":
                mp = q.get("mapping", [""])[0]
                return self._json(importer_vlans_tableau(texte_importe(self._octets()), json.loads(mp) if mp else None, q.get("remplacer", ["0"])[0] == "1"))
            if p == "/api/serveurs/ajouter":
                d = json.loads(corps or "{}")
                ip = str(ipaddress.ip_address((d.get("ip") or "").strip()))
                if any(s["ip"] == ip for s in lire_json(SERVEURS_PATH, [])):
                    raise ValueError(f"Le serveur {ip} existe déjà : le modifier avec le crayon dans la liste")
                serveurs = lire_json(SERVEURS_PATH, [])
                serveurs.append({"ip": ip, "nom": d.get("nom", "").strip(), "os": d.get("os", "").strip(), "site": d.get("site", "").strip(),
                                 "commentaire": d.get("commentaire", "").strip(), "importe": datetime.now().isoformat(timespec="minutes")})
                serveurs.sort(key=lambda s: ipaddress.ip_address(s["ip"]))
                sauver_json(SERVEURS_PATH, serveurs)
                return self._json({"ok": True})
            if p == "/api/serveurs/modifier":
                d = json.loads(corps or "{}")
                orig = str(d.get("ip_origine", ""))
                try:
                    ip = str(ipaddress.ip_address((d.get("ip") or "").strip()))
                except ValueError:
                    raise ValueError("Adresse IP invalide")
                serveurs = lire_json(SERVEURS_PATH, [])
                x = next((s for s in serveurs if s["ip"] == orig), None)
                if not x:
                    raise ValueError("Serveur introuvable")
                if ip != orig and any(s["ip"] == ip for s in serveurs):
                    raise ValueError(f"Un autre serveur porte déjà l'adresse {ip}")
                x.update({"ip": ip, "nom": str(d.get("nom", "")).strip()[:120], "os": str(d.get("os", "")).strip()[:120],
                          "site": str(d.get("site", "")).strip()[:60], "commentaire": str(d.get("commentaire", "")).strip()[:200],
                          "modifie": datetime.now().isoformat(timespec="minutes")})
                if d.get("os_change"):
                    x.pop("systeme_force", None)
                serveurs.sort(key=lambda s: ipaddress.ip_address(s["ip"]))
                sauver_json(SERVEURS_PATH, serveurs)
                if ip != orig and orig in CONFIG.get("perimetre_serveurs", []):
                    CONFIG["perimetre_serveurs"] = [ip if i == orig else i for i in CONFIG["perimetre_serveurs"]]
                    if isinstance(CONFIG.get("perimetre_vlans"), list):
                        CONFIG["plages_autorisees"] = calculer_perimetre(CONFIG["perimetre_vlans"], CONFIG["perimetre_serveurs"], CONFIG.get("perimetre_noms"))["autorisees"]
                    sauver_json(CONFIG_PATH, CONFIG)
                return self._json({"ok": True})
            if p == "/api/serveurs/systeme":
                d = json.loads(corps or "{}")
                ip, sy = str(ipaddress.ip_address(d.get("ip", ""))), d.get("systeme", "")
                if sy not in ("linux", "windows", ""):
                    raise ValueError("Système inconnu")
                serveurs = lire_json(SERVEURS_PATH, [])
                for x in serveurs:
                    if x["ip"] == ip:
                        x["systeme_force"] = sy
                sauver_json(SERVEURS_PATH, serveurs)
                return self._json({"ok": True})
            if p == "/api/serveurs/supprimer":
                d = json.loads(corps or "{}")
                f = corbeille(SERVEURS_PATH, "serveurs") if d.get("tous") else ""
                serveurs = [] if d.get("tous") else [s for s in lire_json(SERVEURS_PATH, []) if s["ip"] != d.get("ip")]
                sauver_json(SERVEURS_PATH, serveurs)
                return self._json({"ok": True, "copie": f})
            if p == "/api/scan":
                if ETAT["en_cours"]:
                    return self._json({"erreur": "Un scan est déjà en cours"}, 409)
                d = json.loads(corps or "{}")
                cibles_txt = list(d.get("cibles", []))
                if d.get("serveurs"):
                    autorisees = parse_reseaux(CONFIG["plages_autorisees"])
                    cibles_txt += [s["ip"] for s in lire_json(SERVEURS_PATH, []) if dans_autorisees(ipaddress.ip_network(s["ip"]), autorisees)]
                if d.get("noms"):
                    cibles_txt += [n["ip"] for n in lire_json(NOMS_PATH, []) if n.get("etat") == "dans le périmètre" and n.get("ip")]
                autorisees = parse_reseaux(CONFIG["plages_autorisees"])
                hors_r = [c for c in parse_reseaux(cibles_txt) if not dans_autorisees(c, autorisees)]
                exclus_r = parse_reseaux(CONFIG["exclusions"]) + parse_reseaux(d.get("exclusions", []))
                interdits = [str(c.network_address) if c.num_addresses == 1 else str(c) for c in hors_r if dans_autorisees(c, exclus_r)]
                if interdits:
                    raise ValueError("Dans une exclusion (VLAN exclu ou exclusion permanente), donc jamais scanné : " + ", ".join(interdits[:15]))
                hors = [str(c.network_address) if c.num_addresses == 1 else str(c) for c in hors_r]
                if hors and d.get("ajouter_hors"):
                    ajouter_adresses_perimetre(hors)
                elif hors:
                    return self._json({"erreur": "Adresses hors du périmètre : " + ", ".join(hors[:15]), "hors_perimetre": hors[:200]}, 409)
                cibles = valider_cibles(cibles_txt)
                cibles = [c for c in ipaddress.collapse_addresses(cibles)]
                exclusions = parse_reseaux(CONFIG["exclusions"]) + parse_reseaux(d.get("exclusions", []))
                est = estimer(cibles, exclusions, CONFIG["ports"], CONFIG["debit"])
                if d.get("estimer"):
                    return self._json({"estimation": est, "plafond": CONFIG["plafond_hotes"],
                                       "depasse": est["adresses"] > CONFIG["plafond_hotes"]})
                if est["adresses"] > CONFIG["plafond_hotes"] and not d.get("confirme"):
                    return self._json({"erreur": f"{est['adresses']} adresses dépassent le plafond de {CONFIG['plafond_hotes']} : confirmation requise"}, 400)
                params = {"cibles": cibles, "exclusions": exclusions, "ports": CONFIG["ports"], "debit": CONFIG["debit"], "threads": CONFIG["threads"]}
                threading.Thread(target=lancer_scan, args=(params,), daemon=True).start()
                time.sleep(0.2)
                return self._json({"ok": True, "scan_id": ETAT["scan_id"]})
            if p == "/api/stop":
                with VERROU:
                    ETAT["stop"] = True
                    proc = ETAT["proc"]
                if proc:
                    try:
                        proc.terminate()
                    except OSError:
                        pass
                journal(ETAT, "Interruption demandée")
                return self._json({"ok": True})
            if p == "/api/inventaire/lancer":
                if ETAT_INV["en_cours"]:
                    return self._json({"erreur": "Un scan des serveurs est déjà en cours"}, 409)
                d = json.loads(corps or "{}")
                index = {x["ip"]: x for x in serveurs_annotes()}
                linux, windows, inconnus, exclus = [], [], [], []
                for ip in d.get("ips", []):
                    x = index.get(str(ip))
                    if not x:
                        continue   # seulement les serveurs de la liste importée (inventaire fourni)
                    if serveur_exclu(x["ip"]):
                        exclus.append(x.get("nom") or x["ip"])
                        continue
                    if x["systeme"] == "linux":
                        linux.append(x["ip"])
                    elif x["systeme"] == "windows":
                        n = x.get("nom", "")
                        windows.append(n if n and hote_valide(n) else x["ip"])
                    else:
                        inconnus.append(x.get("nom") or x["ip"])
                if not linux and not windows:
                    raise ValueError("Aucun serveur coché dont le système est connu" + (f" ({len(inconnus)} sans système : le préciser dans la liste)" if inconnus else ""))
                ssh_user = (d.get("ssh_user") or "").strip()
                win_user = (d.get("win_user") or "").strip() if d.get("win_mode") == "compte" else ""
                if ssh_user and not RE_HOTE_SUR.match(ssh_user):
                    raise ValueError("Compte SSH invalide")
                # comptes et mot de passe : en mémoire le temps du scan, jamais enregistrés ni journalisés
                threading.Thread(target=lancer_inventaire, args=(linux, windows, ssh_user, win_user, d.get("win_mdp") or ""), daemon=True).start()
                time.sleep(0.2)
                return self._json({"ok": True, "linux": len(linux), "windows": len(windows), "ignores": inconnus, "exclus": exclus})
            if p == "/api/inventaire/tester":
                d = json.loads(corps or "{}")
                x = next((x for x in serveurs_annotes() if x["ip"] == d.get("ip")), None)
                if not x:
                    raise ValueError("Serveur inconnu")
                if serveur_exclu(x["ip"]):
                    raise ValueError(f"{x['ip']} est dans une exclusion permanente : jamais interrogé")
                hote = x["ip"] if x["systeme"] == "linux" else (x.get("nom") if x.get("nom") and hote_valide(x["nom"]) else x["ip"])
                ok, msg = tester_connexion(hote, x["systeme"], (d.get("ssh_user") or "").strip(),
                                           (d.get("win_user") or "").strip() if d.get("win_mode") == "compte" else "", d.get("win_mdp") or "")
                return self._json({"ok": ok, "message": f"{hote} : {msg}"})
            if p == "/api/inventaire/stop":
                with VERROU:
                    ETAT_INV["stop"] = True
                journal(ETAT_INV, "Interruption demandée (les connexions en cours se terminent)")
                return self._json({"ok": True})
            if p == "/api/hotes/import":
                n, s = importer_csv_hotes(corps, q.get("origine", ["autre"])[0])
                return self._json({"lignes": n, "serveurs": s})
            if p == "/api/planification":
                d = json.loads(corps or "{}")
                heure = (d.get("planif_heure") or "06:30").strip()
                if not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", heure):
                    raise ValueError("Heure invalide (format HH:MM)")
                jours = [int(j) for j in d.get("planif_jours", []) if 0 <= int(j) <= 6]
                if d.get("planif_actif") and not jours:
                    raise ValueError("Choisir au moins un jour")
                if d.get("planif_cibles") not in ("les_deux", "plages", "serveurs"):
                    raise ValueError("Cibles invalides")
                maj = {"planif_actif": bool(d.get("planif_actif")), "planif_heure": heure, "planif_jours": jours,
                       "planif_cibles": d["planif_cibles"], "planif_inventaire_linux": bool(d.get("planif_inventaire_linux")),
                       "smtp_serveur": (d.get("smtp_serveur") or "").strip(), "smtp_port": int(d.get("smtp_port") or 25),
                       "smtp_tls": bool(d.get("smtp_tls")), "smtp_de": (d.get("smtp_de") or "").strip(),
                       "smtp_a": (d.get("smtp_a") or "").strip()}
                CONFIG.update(maj)
                sauver_json(CONFIG_PATH, CONFIG)
                return self._json({"ok": True})
            if p == "/api/planification/tache-windows":
                d = json.loads(corps or "{}")
                return self._json(tache_windows(bool(d.get("creer", True))))
            if p == "/api/vlans/enregistrer":
                d = json.loads(corps or "{}")
                vlans = charger_vlans()
                cle = d.get("cle") or secrets.token_hex(4)
                item = {"cle": cle, "nom": str(d.get("nom", ""))[:80], "site": str(d.get("site", ""))[:40],
                        "plages": [str(x) for x in parse_reseaux(d.get("plages", []))],
                        "contenu": str(d.get("contenu", ""))[:1500], "decision": d.get("decision") if d.get("decision") in DECISIONS_VLAN else "a_decider",
                        "commentaire": str(d.get("commentaire", ""))[:1500]}
                if not item["nom"]:
                    raise ValueError("Le nom du VLAN est obligatoire")
                vlans = [v for v in vlans if v["cle"] != cle] + [item]
                sauver_json(VLANS_PATH, vlans)
                return self._json({"ok": True, "cle": cle})
            if p == "/api/vlans/supprimer":
                d = json.loads(corps or "{}")
                f = corbeille(VLANS_PATH, "vlans") if d.get("tous") else ""
                sauver_json(VLANS_PATH, [] if d.get("tous") else [v for v in charger_vlans() if v["cle"] != d.get("cle")])
                return self._json({"ok": True, "copie": f})
            if p == "/api/vlans/import":
                d = json.loads(corps)
                if not isinstance(d, list):
                    raise ValueError("Fichier attendu : liste JSON de VLAN")
                vlans = []
                for i, x in enumerate(d):
                    vlans.append({"cle": x.get("cle") or f"i{i}", "nom": str(x.get("nom", ""))[:80], "site": str(x.get("site", ""))[:40],
                                  "plages": [str(y) for y in parse_reseaux(x.get("plages", []))], "contenu": str(x.get("contenu", ""))[:1500],
                                  "decision": x.get("decision") if x.get("decision") in DECISIONS_VLAN else "a_decider", "commentaire": str(x.get("commentaire", ""))[:1500]})
                corbeille(VLANS_PATH, "vlans")
                sauver_json(VLANS_PATH, vlans)
                return self._json({"ok": True, "total": len(vlans)})
            if p == "/api/perimetre/appliquer":
                d = json.loads(corps or "{}")
                r = calculer_perimetre(d.get("vlans"), d.get("serveurs"), d.get("noms"))
                if not r["autorisees"]:
                    raise ValueError("Rien n'est coché : sélectionner au moins un VLAN, un serveur ou un nom d'hôte")
                if not d.get("confirme"):
                    return self._json({"confirmation": r})
                CONFIG.update({"plages_autorisees": r["autorisees"], "exclusions": r["exclusions"],
                               "perimetre_vlans": r["vlans"], "perimetre_serveurs": r["serveurs"], "perimetre_noms": r["noms"]})
                sauver_json(CONFIG_PATH, CONFIG)
                recalculer_etat_noms()
                return self._json(dict(r, ok=True))
            if p == "/api/perimetre/retirer-adresse":
                d = json.loads(corps or "{}")
                a = str(d.get("adresse", ""))
                CONFIG["perimetre_adresses"] = [x for x in CONFIG.get("perimetre_adresses", []) if x != a]
                if isinstance(CONFIG.get("perimetre_vlans"), list):
                    r = calculer_perimetre(CONFIG["perimetre_vlans"], CONFIG.get("perimetre_serveurs"), CONFIG.get("perimetre_noms"))
                    CONFIG["plages_autorisees"] = r["autorisees"]
                else:
                    CONFIG["plages_autorisees"] = [x for x in CONFIG["plages_autorisees"] if x != a]
                sauver_json(CONFIG_PATH, CONFIG)
                recalculer_etat_noms()
                return self._json({"ok": True})
            if p == "/api/consolidation/apercu":
                b = lire_bilan_recu(self._octets(), q)
                f = os.path.join(CONSO_DIR, slug_etab(b["etablissement"]) + ".json")
                ancien = lire_json(f, None) if os.path.exists(f) else None
                n = {k: sum(1 for m in b["machines"] if m["final"] == k) for k in FINALS}
                return self._json({"etablissement": b["etablissement"], "date": b["date"], "machines": len(b["machines"]), **n,
                                   "ancien_format": bool(b.get("ancien_format")),
                                   "ancien": ancien.get("date") if isinstance(ancien, dict) else None,
                                   "est_local": b["etablissement"].lower() == (CONFIG.get("etablissement") or "").strip().lower()})
            if p == "/api/consolidation/import":
                b = lire_bilan_recu(self._octets(), q)
                os.makedirs(CONSO_DIR, exist_ok=True)
                f = os.path.join(CONSO_DIR, slug_etab(b["etablissement"]) + ".json")
                if os.path.exists(f):
                    os.makedirs(os.path.join(DATA, "corbeille"), exist_ok=True)
                    shutil.copy2(f, os.path.join(DATA, "corbeille", f"bilan_{slug_etab(b['etablissement'])}_{datetime.now():%Y%m%d_%H%M%S}.json"))
                b["importe"] = datetime.now().isoformat(timespec="minutes")
                sauver_json(f, b)
                return self._json({"ok": True, "etablissement": b["etablissement"], "machines": len(b["machines"])})
            if p == "/api/consolidation/supprimer":
                d = json.loads(corps or "{}")
                f = os.path.join(CONSO_DIR, slug_etab(str(d.get("etablissement", ""))) + ".json")
                if os.path.exists(f):
                    os.makedirs(os.path.join(DATA, "corbeille"), exist_ok=True)
                    shutil.move(f, os.path.join(DATA, "corbeille", f"bilan_{os.path.basename(f)[:-5]}_{datetime.now():%Y%m%d_%H%M%S}.json"))
                return self._json({"ok": True})
            if p == "/api/plan/machine":
                d = json.loads(corps or "{}")
                etab, ip = str(d.get("etablissement", "")), str(d.get("ip", ""))
                if not etab or not ip:
                    raise ValueError("Machine non précisée")
                pl = lire_plan()
                maj_plan_machine(pl, etab, ip, d)
                sauver_json(PLAN_PATH, pl)
                return self._json({"ok": True})
            if p == "/api/serveurs/renommer":
                # nom saisi dans la vue territoire pour une machine de ce poste : reporté dans la liste des serveurs
                d = json.loads(corps or "{}")
                ip = str(ipaddress.ip_address(str(d.get("ip", "")).strip()))
                nom = str(d.get("nom", "")).strip()[:120]
                serveurs = lire_json(SERVEURS_PATH, [])
                x = next((v for v in serveurs if v["ip"] == ip), None)
                if x is None and not d.get("ajouter"):
                    return self._json({"absent": True})
                if x is None:
                    x = {"ip": ip, "nom": "", "os": "", "site": str(d.get("site", "")).strip()[:60],
                         "commentaire": "ajouté depuis la vue territoire", "importe": datetime.now().isoformat(timespec="minutes")}
                    serveurs.append(x)
                    serveurs.sort(key=lambda v: ipaddress.ip_address(v["ip"]))
                    action = "ajoute"
                else:
                    action = "renomme"
                x["nom"] = nom
                x["modifie"] = datetime.now().isoformat(timespec="minutes")
                sauver_json(SERVEURS_PATH, serveurs)
                pl = lire_plan()
                cm = pl["machines"].get(cle_machine(str(d.get("etablissement", "")), ip))
                if cm and (cm.get("complements") or {}).get("nom") is not None:
                    cm["complements"].pop("nom", None)
                    sauver_json(PLAN_PATH, pl)
                return self._json({"ok": True, "action": action})
            if p in ("/api/plan/complements/apercu", "/api/plan/complements/import"):
                r = importer_complements(corps, p.endswith("import"))
                return self._json(r)
            if p == "/api/plan/domaine":
                d = json.loads(corps or "{}")
                dom = str(d.get("domaine", "")).strip()[:80]
                if not dom:
                    raise ValueError("Domaine non précisé")
                pl = lire_plan()
                x = pl["domaines"].setdefault(dom, {})
                x.update(nettoyer_champs_plan(d))
                x["modifie"] = datetime.now().isoformat(timespec="minutes")
                sauver_json(PLAN_PATH, pl)
                return self._json({"ok": True})
            if p == "/api/etablissement/parametres":
                # valeurs d'établissement modifiables à l'écran (édition partagée, D3) : écrites dans le dossier de
                # données, qui surcharge le fichier livré à côté du programme ; jamais dans le dossier du programme
                d = json.loads(corps or "{}")
                org = str(d.get("organisation", "")).strip()[:80]
                mention = str(d.get("mention", "")).strip()[:120] or "Diffusion restreinte"
                etabs = [str(x).strip()[:80] for x in (d.get("etablissements") or []) if str(x).strip()][:20]
                etabs = list(dict.fromkeys(etabs))
                if not org:
                    raise ValueError("Indiquer le nom de l'organisation (établissement ou groupement)")
                if not etabs:
                    raise ValueError("Indiquer au moins un établissement ou hôpital (un par ligne)")
                sauver_json(os.path.join(DATA, "parametres_etablissement.json"),
                            {"organisation": org, "mention": mention, "etablissements": etabs})
                recharger_parametres()
                if CONFIG.get("etablissement") and CONFIG["etablissement"] not in etabs:
                    CONFIG["etablissement"] = ""
                    sauver_json(CONFIG_PATH, CONFIG)
                journal(ETAT, f"Valeurs d'établissement modifiées : {org}, {len(etabs)} établissement(s)")
                return self._json({"ok": True, "organisation": org, "etablissements": etabs})
            if p == "/api/config/etablissement":
                d = json.loads(corps or "{}")
                CONFIG["etablissement"] = canon_etab(str(d.get("etablissement", "")).strip()[:80])
                sauver_json(CONFIG_PATH, CONFIG)
                return self._json({"ok": True})
            if p == "/api/exemples/charger":
                return self._json(charger_exemples())
            if p == "/api/exemples/supprimer":
                return self._json(supprimer_exemples())
            if p == "/api/vlans/appliquer":
                """Reporte la cartographie dans le paramétrage : plages autorisées = P1 + scanner (+ a_decider si demandé) ;
                exclusions = exclure (+ reserve)."""
                d = json.loads(corps or "{}")
                vlans = charger_vlans()
                cles = set(d.get("cles") or [])
                if not cles:
                    raise ValueError("Sélectionner au moins un VLAN")
                choisis = [v for v in vlans if v["cle"] in cles]
                aut = plages_selon_decision(choisis, {"P1", "scanner", "a_decider", "reserve"})
                exc = plages_selon_decision(vlans, {"exclure"}) + plages_selon_decision([v for v in vlans if v["cle"] not in cles], {"reserve"})
                if not d.get("confirme"):
                    return self._json({"confirmation": {"autorisees": aut, "exclusions": exc}})
                CONFIG["plages_autorisees"] = sorted(set(aut), key=lambda x: ipaddress.ip_network(x))
                CONFIG["exclusions"] = sorted(set(exc), key=lambda x: ipaddress.ip_network(x))
                sauver_json(CONFIG_PATH, CONFIG)
                return self._json({"ok": True, "autorisees": CONFIG["plages_autorisees"], "exclusions": CONFIG["exclusions"]})
            if p == "/api/noms/import":
                return self._json(importer_noms(corps, q.get("source", ["liste"])[0][:40], q.get("remplacer", ["0"])[0] == "1"))
            if p in ("/api/noms/ajouter", "/api/noms/modifier"):
                d = json.loads(corps or "{}")
                nom = str(d.get("nom", "")).strip().lower().rstrip(".")
                if not re.fullmatch(r"[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*", nom or "-"):
                    raise ValueError("Nom d'hôte invalide (lettres, chiffres, tirets et points)")
                ip = str(d.get("ip", "")).strip()
                if ip:
                    ip = str(ipaddress.ip_address(ip))
                noms = lire_json(NOMS_PATH, [])
                orig = str(d.get("nom_origine", "")) if p.endswith("modifier") else ""
                if any(x["nom"] == nom for x in noms) and nom != orig:
                    raise ValueError(f"Le nom {nom} existe déjà")
                ancien = next((x for x in noms if x["nom"] == orig), {}) if orig else {}
                noms = [x for x in noms if x["nom"] != orig]
                if not ip:
                    ip = resoudre(nom)
                    source_ip = "résolu"
                else:
                    source_ip = "saisi"
                autorisees = parse_reseaux(CONFIG["plages_autorisees"])
                etat = "non résolu" if not ip else ("dans le périmètre" if dans_autorisees(ipaddress.ip_network(ip), autorisees) else "hors périmètre")
                noms.append({"nom": nom, "ip": ip, "etat": etat, "site": str(d.get("site", "")).strip()[:60] or site_de(ip),
                             "source": ancien.get("source") or "saisie manuelle", "ip_source": source_ip,
                             "importe": ancien.get("importe") or datetime.now().isoformat(timespec="minutes")})
                sauver_json(NOMS_PATH, sorted(noms, key=lambda x: x["nom"]))
                if orig and orig != nom and orig in CONFIG.get("perimetre_noms", []):
                    CONFIG["perimetre_noms"] = [nom if n == orig else n for n in CONFIG["perimetre_noms"]]
                    sauver_json(CONFIG_PATH, CONFIG)
                return self._json({"ok": True, "ip": ip, "etat": etat})
            if p == "/api/noms/supprimer":
                d = json.loads(corps or "{}")
                f = corbeille(NOMS_PATH, "noms") if d.get("tous") else ""
                sauver_json(NOMS_PATH, [] if d.get("tous") else [x for x in lire_json(NOMS_PATH, []) if x["nom"] != d.get("nom")])
                return self._json({"ok": True, "copie": f})
            if p == "/api/noms/resoudre":
                noms = lire_json(NOMS_PATH, [])
                autorisees = parse_reseaux(CONFIG["plages_autorisees"])
                with ThreadPoolExecutor(max_workers=20) as ex:
                    ips = list(ex.map(resoudre, [x["nom"] for x in noms]))
                for x, ip in zip(noms, ips):
                    if x.get("exemple") or x.get("ip_source") == "saisi":
                        continue
                    x["ip"] = ip
                    x["etat"] = "non résolu" if not ip else ("dans le périmètre" if dans_autorisees(ipaddress.ip_network(ip), autorisees) else "hors périmètre")
                sauver_json(NOMS_PATH, noms)
                return self._json({"ok": True, "total": len(noms)})
            if p == "/api/suivi/alimenter":
                return self._json({"ajoutes": alimenter_suivi()})
            if p == "/api/suivi/modifier":
                d = json.loads(corps or "{}")
                suivi = lire_json(SUIVI_PATH, [])
                for x in suivi:
                    if x["cle"] == d.get("cle"):
                        for k in ("responsable", "echeance", "etat", "preuve", "commentaire", "site"):
                            if k in d:
                                x[k] = str(d[k])[:500]
                        if x["etat"] not in ETATS_SUIVI:
                            x["etat"] = ETATS_SUIVI[0]
                sauver_json(SUIVI_PATH, suivi)
                return self._json({"ok": True})
            if p == "/api/suivi/supprimer":
                d = json.loads(corps or "{}")
                sauver_json(SUIVI_PATH, [x for x in lire_json(SUIVI_PATH, []) if x["cle"] != d.get("cle")])
                return self._json({"ok": True})
            if p == "/api/externes/enregistrer":
                d = json.loads(corps or "{}")
                ext = lire_json(EXTERNES_PATH, [])
                cle = d.get("cle") or secrets.token_hex(6)
                item = {"cle": cle}
                for k in ("nom", "hebergeur", "contact", "site", "url", "etat", "date_demande", "reponse", "version_confirmee", "commentaire"):
                    item[k] = str(d.get(k, ""))[:500]
                if item["etat"] not in ETATS_EXTERNE:
                    item["etat"] = ETATS_EXTERNE[0]
                if not item["nom"]:
                    raise ValueError("Le nom de l'application est obligatoire")
                ext = [x for x in ext if x["cle"] != cle] + [item]
                sauver_json(EXTERNES_PATH, ext)
                return self._json({"ok": True, "cle": cle})
            if p == "/api/externes/supprimer":
                d = json.loads(corps or "{}")
                sauver_json(EXTERNES_PATH, [x for x in lire_json(EXTERNES_PATH, []) if x["cle"] != d.get("cle")])
                return self._json({"ok": True})
            if p == "/api/planification/test-courriel":
                if not (CONFIG["smtp_serveur"] and CONFIG["smtp_a"]):
                    raise ValueError("Renseigner le serveur SMTP et les destinataires")
                try:
                    envoyer_courriel("[Inventaire PHP] Courriel de test", f"Test d'envoi depuis l'application Inventaire PHP ({platform.node()}).")
                except Exception as e:  # noqa
                    raise ValueError(f"Envoi impossible : {e}")
                return self._json({"ok": True})
            if p == "/api/planification/cycle":
                if ETAT["en_cours"]:
                    return self._json({"erreur": "Un scan est déjà en cours"}, 409)
                valider_cibles(cibles_planifiees())
                threading.Thread(target=executer_cycle, args=("manuel",), daemon=True).start()
                return self._json({"ok": True})
        except (ValueError, json.JSONDecodeError, csv.Error) as e:
            return self._json({"erreur": str(e)}, 400)
        self._json({"erreur": "introuvable"}, 404)


# ---------------------------------------------------------------------------
# Signature des livraisons : la version INSTALLÉE vérifie l'archive avant toute mise à jour
# Format SSHSIG d'OpenSSH (PROTOCOL.sshsig), clé Ed25519 (RFC 8032), hachage sha512, espace de noms ci-dessous.
# La clé privée reste sur le poste du RSSI ; seules les clés PUBLIQUES figurent ici. Plusieurs clés peuvent être
# inscrites pour changer de clé : une version signée par l'ancienne clé livre la nouvelle liste.
# Aucun contournement : ni option, ni variable d'environnement.
# ---------------------------------------------------------------------------
CLES_SIGNATURE = [
    # RSSI des Hôpitaux de Corrèze, empreinte SHA256:ua+kcOxT3hsOeFxdyJADPogVig7D7jd4foQrMm/b0rg
    "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIKnS1RnyTPZC1zN6N9EHz2YHY8HnJdSfsPeFhHmeLHCK Signature Inventaire PHP - RSSI Hopitaux de Correze",
]
ESPACE_SIGNATURE = "inventaire-php"
HACHAGE_SIGNATURE = "sha512"
REFUS_SIGNATURE = "archive non signée ou signature invalide : installation refusée, prévenez le RSSI"

_ED_P = 2 ** 255 - 19
_ED_L = 2 ** 252 + 27742317777372353535851937790883648493
_ED_D = -121665 * pow(121666, _ED_P - 2, _ED_P) % _ED_P
_ED_I = pow(2, (_ED_P - 1) // 4, _ED_P)          # racine carrée de -1


def _ed_somme(a, b):
    """Addition de deux points en coordonnées étendues (RFC 8032, § 5.1.4)."""
    x1, y1, z1, t1 = a
    x2, y2, z2, t2 = b
    p = _ED_P
    a_, b_ = (y1 - x1) * (y2 - x2) % p, (y1 + x1) * (y2 + x2) % p
    c_, d_ = 2 * t1 * t2 * _ED_D % p, 2 * z1 * z2 % p
    e, f, g, h = b_ - a_, d_ - c_, d_ + c_, b_ + a_
    return (e * f % p, g * h % p, f * g % p, e * h % p)


def _ed_produit(s, point):
    resultat = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            resultat = _ed_somme(resultat, point)
        point = _ed_somme(point, point)
        s >>= 1
    return resultat


def _ed_egaux(a, b):
    p = _ED_P
    return (a[0] * b[2] - b[0] * a[2]) % p == 0 and (a[1] * b[2] - b[1] * a[2]) % p == 0


def _ed_abscisse(y, signe):
    p = _ED_P
    if y >= p:
        return None
    x2 = (y * y - 1) * pow(_ED_D * y * y + 1, p - 2, p) % p
    if x2 == 0:
        return None if signe else 0
    x = pow(x2, (p + 3) // 8, p)
    if (x * x - x2) % p:
        x = x * _ED_I % p
    if (x * x - x2) % p:
        return None
    return p - x if (x & 1) != signe else x


def _ed_point(octets):
    """Décodage d'un point (RFC 8032, § 5.1.3) ; None si le codage est invalide."""
    if len(octets) != 32:
        return None
    y = int.from_bytes(octets, "little")
    signe, y = y >> 255, y & ((1 << 255) - 1)
    x = _ed_abscisse(y, signe)
    return None if x is None else (x, y, 1, x * y % _ED_P)


_ED_B = _ed_point((4 * pow(5, _ED_P - 2, _ED_P) % _ED_P).to_bytes(32, "little"))


def ed25519_verifier(publique, message, signature):
    """Vérification Ed25519 (RFC 8032, § 5.1.7) : [S]B = R + [k]A, S < L. Bibliothèque standard seulement."""
    if len(publique) != 32 or len(signature) != 64:
        return False
    a, r = _ed_point(publique), _ed_point(signature[:32])
    s = int.from_bytes(signature[32:], "little")
    if a is None or r is None or s >= _ED_L:
        return False
    k = int.from_bytes(hashlib.sha512(signature[:32] + publique + message).digest(), "little") % _ED_L
    return _ed_egaux(_ed_produit(s, _ED_B), _ed_somme(r, _ed_produit(k, a)))


def _chaine_ssh(octets):
    return len(octets).to_bytes(4, "big") + octets


def _lire_chaines(blob, n):
    """Lit exactement n chaînes SSH (longueur sur 4 octets) qui occupent tout le blob ; ValueError sinon."""
    i, sortie = 0, []
    for _ in range(n):
        if i + 4 > len(blob):
            raise ValueError("structure tronquée")
        lg = int.from_bytes(blob[i:i + 4], "big")
        if i + 4 + lg > len(blob):
            raise ValueError("structure tronquée")
        sortie.append(blob[i + 4:i + 4 + lg])
        i += 4 + lg
    if i != len(blob):
        raise ValueError("octets en trop")
    return sortie


def cle_publique_ssh(ligne):
    """« ssh-ed25519 AAAA… commentaire » -> (blob de la clé, 32 octets de la clé) ; ValueError sinon."""
    parties = ligne.split()
    if len(parties) < 2 or parties[0] != "ssh-ed25519":
        raise ValueError("clé publique ssh-ed25519 attendue")
    blob = base64.b64decode(parties[1], validate=True)
    type_, cle = _lire_chaines(blob, 2)
    if type_ != b"ssh-ed25519" or len(cle) != 32:
        raise ValueError("clé publique ssh-ed25519 invalide")
    return blob, cle


def empreinte_cle_ssh(ligne):
    """Empreinte affichée par ssh-keygen -l : SHA256:<base64 sans « = »>."""
    return "SHA256:" + base64.b64encode(hashlib.sha256(cle_publique_ssh(ligne)[0]).digest()).decode().rstrip("=")


def lire_sshsig(texte):
    """Fichier .sig produit par ssh-keygen -Y sign (PROTOCOL.sshsig) -> dictionnaire ; ValueError si mal formé."""
    lignes = [l.strip() for l in texte.strip().splitlines()]
    if len(lignes) < 3 or lignes[0] != "-----BEGIN SSH SIGNATURE-----" or lignes[-1] != "-----END SSH SIGNATURE-----":
        raise ValueError("ce n'est pas une signature SSH (en-tête attendu « BEGIN SSH SIGNATURE »)")
    try:
        blob = base64.b64decode("".join(lignes[1:-1]), validate=True)
    except ValueError:
        raise ValueError("signature SSH illisible (base64)")
    if blob[:6] != b"SSHSIG" or len(blob) < 10:
        raise ValueError("préambule SSHSIG absent")
    if int.from_bytes(blob[6:10], "big") != 1:
        raise ValueError("version de signature SSHSIG non prise en charge")
    cle, espace, reserve, hachage, signature = _lire_chaines(blob[10:], 5)
    type_sig, octets_sig = _lire_chaines(signature, 2)
    return {"cle": cle, "espace": espace, "reserve": reserve, "hachage": hachage, "type": type_sig, "signature": octets_sig}


def verifier_signature(chemin, chemin_sig=None):
    """Vérifie la signature d'une archive (fichier <archive>.sig) pour une clé de CLES_SIGNATURE et l'espace de noms
    ESPACE_SIGNATURE. Renvoie (True, empreinte de la clé) ou (False, motif du refus)."""
    chemin_sig = chemin_sig or chemin + ".sig"
    if not os.path.isfile(chemin_sig):
        return False, f"signature absente ({os.path.basename(chemin_sig)} introuvable à côté de l'archive)"
    try:
        if os.path.getsize(chemin_sig) > 16384:
            return False, "fichier de signature anormalement gros"
        with open(chemin_sig, encoding="ascii") as f:
            s = lire_sshsig(f.read())
    except (OSError, UnicodeDecodeError, ValueError) as e:
        return False, f"signature illisible : {e}"
    if s["espace"] != ESPACE_SIGNATURE.encode():
        return False, f"espace de noms « {s['espace'].decode('utf-8', 'replace')} » au lieu de « {ESPACE_SIGNATURE} »"
    if s["hachage"] != HACHAGE_SIGNATURE.encode() or s["reserve"] or s["type"] != b"ssh-ed25519":
        return False, "signature d'un type non admis (Ed25519 et sha512 attendus)"
    autorisees = {}
    for ligne in CLES_SIGNATURE:
        blob, cle = cle_publique_ssh(ligne)
        autorisees[blob] = (cle, empreinte_cle_ssh(ligne))
    if s["cle"] not in autorisees:
        return False, "archive signée par une clé qui n'est pas celle du RSSI"
    cle, empreinte = autorisees[s["cle"]]
    h = hashlib.sha512()
    try:
        with open(chemin, "rb") as f:
            for bloc in iter(lambda: f.read(1 << 20), b""):
                h.update(bloc)
    except OSError as e:
        return False, f"archive illisible : {e}"
    signe = b"SSHSIG" + _chaine_ssh(s["espace"]) + _chaine_ssh(s["reserve"]) + _chaine_ssh(s["hachage"]) + _chaine_ssh(h.digest())
    if not ed25519_verifier(cle, signe, s["signature"]):
        return False, "signature invalide : l'archive a été modifiée depuis sa signature, ou la signature est fausse"
    return True, empreinte


def journal_mises_a_jour(cible, texte):
    """Trace dans le journal des mises à jour du dossier de données de l'installation (hors dépôt)."""
    try:
        donnees = os.path.join(os.path.abspath(cible), "donnees")
        os.makedirs(donnees, exist_ok=True)
        with open(os.path.join(donnees, "mises_a_jour.log"), "a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S}  {texte}\n")
    except OSError:
        pass


def refuser_paquet(cible, paquet, motif):
    """Refus d'une archive : message clair, archive et signature déplacées en quarantaine locale, refus journalisé.
    Ni le programme ni les données ne sont touchés."""
    quarantaine = os.path.join(os.path.abspath(cible), "quarantaine", datetime.now().strftime("%Y%m%d_%H%M%S"))
    deplaces = []
    for f in (paquet, (paquet or "") + ".sig"):
        if f and os.path.isfile(f):
            try:
                os.makedirs(quarantaine, exist_ok=True)
                shutil.move(f, os.path.join(quarantaine, os.path.basename(f)))
                deplaces.append(os.path.basename(f))
            except OSError:
                pass
    print(f"\n  [!!] {REFUS_SIGNATURE[0].upper()}{REFUS_SIGNATURE[1:]}.\n       Motif : {motif}.")
    if deplaces:
        print(f"       Rien n'a été modifié ; {' et '.join(deplaces)} déplacé(s) en quarantaine : {quarantaine}")
    else:
        print("       Rien n'a été modifié.")
    journal_mises_a_jour(cible, f"REFUS {os.path.basename(paquet or '(aucune archive)')} : {motif}"
                                + (f" ; quarantaine {os.path.basename(quarantaine)}" if deplaces else ""))
    return 6


def copie_verifiee(paquet, dossier):
    """Copie l'archive et sa signature dans un dossier temporaire et vérifie la COPIE : ce qui est ensuite décompressé
    est exactement ce qui a été vérifié. Renvoie (chemin de la copie ou None, motif ou empreinte de la clé)."""
    if not paquet or not os.path.isfile(paquet):
        return None, "archive absente"
    copie = os.path.join(dossier, os.path.basename(paquet))
    shutil.copyfile(paquet, copie)
    if os.path.isfile(paquet + ".sig"):
        shutil.copyfile(paquet + ".sig", copie + ".sig")
    ok, info = verifier_signature(copie)
    return (copie if ok else None), info


# ---------------------------------------------------------------------------
# Mise à jour : exécutée par le code de la NOUVELLE version, depuis l'archive décompressée
# ---------------------------------------------------------------------------
FICHIERS_PROGRAMME = ["inventaire_php_app.py", "inventaire_php_interface.html", "inventaire_php_complements.html",
                      "Cycle_planifie.bat", "CHANGELOG.txt", "LICENSE", "modele_serveurs.csv", "modele_vlans.csv",
                      "parametres_etablissement.json", "README.md", "Mode_emploi_Inventaire_PHP.docx",
                      "Inventaire_PHP_Guide_express.docx", "Inventaire_PHP_Mode_emploi_1_page.docx"]
FICHIERS_OBSOLETES = ["Installer.bat", "Construire_version_portable.bat", "build_windows.bat", "Installation_sans_droits_admin.bat",
                      "Installation_avec_droits_admin.bat", "RAPPORT-CORRECTIONS-v2.0.1.md", "RECETTE-v2.0.1.md",
                      "ERGONOMIE-remarques-v2.2.md", "tests_inventaire_php.py", "LISEZMOI-deploiement-autre-site.txt"]
SAUVEGARDES_CONSERVEES = 10


def version_de(texte):
    m = re.search(r'^VERSION = "([\d.]+)"', texte, re.M)
    return m.group(1) if m else "0"


def cle_version(v):
    return tuple(int(x) for x in re.findall(r"\d+", v)[:4]) or (0,)


def version_installee(dossier):
    try:
        with open(os.path.join(dossier, "inventaire_php_app.py"), encoding="utf-8", errors="ignore") as f:
            return version_de(f.read())
    except OSError:
        return "0"


def examiner_paquet(chemin):
    """Vérifie qu'une archive est bien une livraison de cette application et lit sa version.
    Critères : zip lisible ; un seul inventaire_php_app.py, à la racine ou dans un sous-dossier ; ce fichier porte la
    signature APP_ID (ou, pour les livraisons antérieures à 2.5.1, le titre « Inventaire PHP » et les CVE) et une VERSION."""
    try:
        with zipfile.ZipFile(chemin) as z:
            apps = [x for x in z.namelist() if x.replace("\\", "/").split("/")[-1] == "inventaire_php_app.py" and x.count("/") <= 1]
            if len(apps) != 1:
                return None
            texte = z.read(apps[0]).decode("utf-8", "ignore")
    except (zipfile.BadZipFile, OSError, KeyError):
        return None
    signe = APP_ID in texte or ("Inventaire PHP" in texte and "CVE-2026-109618" in texte)
    v = version_de(texte)
    if not signe or v == "0":
        return None
    return {"fichier": os.path.abspath(chemin), "version": v, "date": datetime.fromtimestamp(os.path.getmtime(chemin)).strftime("%Y-%m-%d %H:%M"),
            "signee": verifier_signature(chemin)[0]}


def paquets_disponibles(dossier):
    """Archives InventairePHP-v*.zip valides dans le dossier, son parent et Téléchargements — y compris dans leurs
    sous-dossiers « Envoi InventairePHP-vX.Y.Z » (préparés par le programme de signature) —, sans doublon de version
    (la plus récemment déposée l'emporte), triées de la plus récente version à la plus ancienne."""
    lieux = [dossier, os.path.dirname(os.path.abspath(dossier)), os.path.join(os.path.expanduser("~"), "Downloads")]
    par_version = {}
    for racine_lieu in dict.fromkeys(os.path.abspath(x) for x in lieux):
        try:
            contenus = os.listdir(racine_lieu)
        except OSError:
            continue
        sous = [os.path.join(racine_lieu, n) for n in contenus
                if n.lower().startswith("envoi inventairephp-v") and os.path.isdir(os.path.join(racine_lieu, n))]
        for lieu in [racine_lieu] + sous:
            try:
                noms = os.listdir(lieu)
            except OSError:
                continue
            for n in noms:
                if not (n.lower().startswith("inventairephp-v") and n.lower().endswith(".zip")):
                    continue
                x = examiner_paquet(os.path.join(lieu, n))
                if x and (x["version"] not in par_version or x["date"] > par_version[x["version"]]["date"]):
                    par_version[x["version"]] = x
    return sorted(par_version.values(), key=lambda x: cle_version(x["version"]), reverse=True)


def maj_disponible(dossier):
    inst = cle_version(version_installee(dossier))
    return next((x for x in paquets_disponibles(dossier) if cle_version(x["version"]) > inst), None)


def mettre_a_jour(dossier):
    """Option 5 du lanceur (exécutée par la version INSTALLÉE) : choisit l'archive, la décompresse et confie
    l'installation au code de la NOUVELLE version."""
    dossier = os.path.abspath(dossier)
    inst = version_installee(dossier)
    paquets = paquets_disponibles(dossier)
    print(f"\n  Version installée : {inst}")
    if not paquets:
        print("  Aucune archive InventairePHP-v*.zip valide dans ce dossier, son dossier parent ou Téléchargements.\n"
              "  Déposer l'archive reçue, sans la décompresser, puis refaire l'option 5.")
        return 5
    print("  Archives trouvées :")
    for k, x in enumerate(paquets, 1):
        rel = cle_version(x["version"])
        etat = "PLUS RÉCENTE" if rel > cle_version(inst) else ("déjà installée" if x["version"] == inst else "plus ancienne")
        signee = "signée" if verifier_signature(x["fichier"])[0] else "NON SIGNÉE"
        print(f"   {k}. version {x['version']:<8} {etat:<15} {signee:<11} {x['fichier']}")
    nouvelle = maj_disponible(dossier)
    if nouvelle:
        rep_ = input(f"\n  Installer la version {nouvelle['version']} ? [O/n] ").strip().lower()
        if rep_ not in ("", "o", "oui"):
            return 4
        choix, confirme = nouvelle, True
    else:
        print(f"\n  Aucune version plus récente que {inst}.")
        rep_ = input("  Pour revenir à une version antérieure, taper son numéro ; Entrée pour ne rien faire : ").strip()
        if not rep_.isdigit() or not 1 <= int(rep_) <= len(paquets):
            return 4
        choix = paquets[int(rep_) - 1]
        if input(f"  Confirmer le retour à la version {choix['version']} (les données sont conservées) ? [o/N] ").strip().lower() not in ("o", "oui"):
            return 4
        confirme = True
    tmp = tempfile.mkdtemp(prefix="inventaire_php_maj_")
    try:
        # la version INSTALLÉE vérifie la signature avant d'exécuter quoi que ce soit de l'archive
        copie, info = copie_verifiee(choix["fichier"], tmp)
        if not copie:
            return refuser_paquet(dossier, choix["fichier"], info)
        print(f"  [OK] Signature du RSSI vérifiée (clé {info}).")
        decompresse = os.path.join(tmp, "archive")
        with zipfile.ZipFile(copie) as z:
            z.extractall(decompresse)
        src = next(os.path.join(r, "inventaire_php_app.py") for r, _, f in os.walk(decompresse) if "inventaire_php_app.py" in f)
        with open(src, encoding="utf-8", errors="ignore") as f:
            sait_installer = "--installer-dans" in f.read()
        if not sait_installer:
            print(f"  [!!] Retour impossible vers la version {choix['version']} : les versions antérieures à 2.5.0 n'utilisent pas"
                  " le même dossier de données ni le même lanceur. Revenir au plus à la version 2.5.0.")
            return 4
        cmd = [sys.executable, src, "--installer-dans", dossier, "--paquet", choix["fichier"]] + (["--confirme"] if confirme else [])
        return subprocess.call(cmd)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def programme_de(z):
    """Fichiers du programme contenus dans une archive de livraison (à la racine ou dans son unique sous-dossier)."""
    noms = {n.replace("\\", "/"): n for n in z.namelist()}
    app = [n for n in noms if n.split("/")[-1] == "inventaire_php_app.py" and n.count("/") <= 1]
    if len(app) != 1:
        raise ValueError("l'archive doit contenir un et un seul inventaire_php_app.py")
    prefixe = app[0][:-len("inventaire_php_app.py")]
    return {f: z.read(noms[prefixe + f]) for f in FICHIERS_PROGRAMME + ["Inventaire PHP.bat"] if prefixe + f in noms}


def installer_dans(cible, paquet="", confirme=False):
    """Installe dans « cible », sans toucher aux données, le programme contenu dans l'archive « paquet », seulement si
    sa signature est valide (clé de CLES_SIGNATURE, espace de noms ESPACE_SIGNATURE) ; sinon refus et quarantaine.
    Étapes : vérification de la signature sur une copie, contrôles, migration du nom du dossier de données, sauvegarde
    (données + programme), copie du programme lu dans l'archive vérifiée, nouveau lanceur déposé en
    « Inventaire PHP.bat.new » (le lanceur en cours le met en place à sa sortie)."""
    cible = os.path.abspath(cible)
    if not paquet:
        return refuser_paquet(cible, "", "aucune archive indiquée : seule une archive signée s'installe (--paquet)")
    paquet = os.path.abspath(paquet)
    tmp = tempfile.mkdtemp(prefix="inventaire_php_inst_")
    try:
        copie, info = copie_verifiee(paquet, tmp)
        if not copie:
            return refuser_paquet(cible, paquet, info)
        if not examiner_paquet(copie):
            return refuser_paquet(cible, paquet, "archive signée mais qui n'est pas une livraison de cette application")
        with zipfile.ZipFile(copie) as z:
            contenu = programme_de(z)
        print(f"  [OK] Signature du RSSI vérifiée (clé {info}).")
        return _installer(cible, paquet, confirme, contenu, info)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _installer(cible, paquet, confirme, contenu, cle):
    v_old, v_new = version_installee(cible), version_de(contenu["inventaire_php_app.py"].decode("utf-8", "ignore"))
    print(f"\n  Version installée : {v_old if v_old != '0' else '(aucune)'}\n  Nouvelle version  : {v_new}\n  Dossier           : {cible}\n")
    try:
        socket.create_connection(("127.0.0.1", PORT_ECOUTE), timeout=1).close()
        print("  [!!] L'application est ouverte : fermer sa fenêtre noire, puis relancer la mise à jour.")
        return 2
    except OSError:
        pass
    if confirme:
        pass
    elif cle_version(v_new) < cle_version(v_old):
        if input(f"  [??] Cette archive ({v_new}) est PLUS ANCIENNE que la version installée ({v_old}). Installer quand même ? [o/N] ").strip().lower() != "o":
            return 4
    elif v_new == v_old:
        if input("  [??] Cette version est déjà installée. Réinstaller ? [o/N] ").strip().lower() != "o":
            return 4
    donnees = migrer_nom_donnees(os.path.join(cible, "donnees"))
    horo = datetime.now().strftime("%Y%m%d_%H%M%S")
    sauv = os.path.join(cible, "sauvegardes", f"{horo}_avant_v{v_new}")
    os.makedirs(os.path.join(sauv, "programme"), exist_ok=True)
    # 1. sauvegarde des données (archive) et du programme actuel
    if os.path.isdir(donnees):
        n = 0
        with zipfile.ZipFile(os.path.join(sauv, "donnees.zip"), "w", zipfile.ZIP_DEFLATED) as z:
            for rac, _, fichiers in os.walk(donnees):
                for f in fichiers:
                    z.write(os.path.join(rac, f), os.path.relpath(os.path.join(rac, f), cible))
                    n += 1
        print(f"  [OK] Données sauvegardées : {n} fichier(s) -> sauvegardes\\{os.path.basename(sauv)}\\donnees.zip")
    else:
        print("  [..] Pas encore de données : rien à sauvegarder")
    for f in FICHIERS_PROGRAMME + ["Inventaire PHP.bat"] + FICHIERS_OBSOLETES:
        if os.path.isfile(os.path.join(cible, f)):
            shutil.copy2(os.path.join(cible, f), os.path.join(sauv, "programme", f))
    # 2. copie de la nouvelle version, lue dans l'archive vérifiée (jamais « donnees », « python », « nmap », « sauvegardes »)
    for f, octets in contenu.items():
        with open(os.path.join(cible, "Inventaire PHP.bat.new" if f == "Inventaire PHP.bat" else f), "wb") as sortie:
            sortie.write(octets)
    deplaces = []
    for f in FICHIERS_OBSOLETES:
        if os.path.isfile(os.path.join(cible, f)):
            os.remove(os.path.join(cible, f))   # copie conservée dans la sauvegarde
            deplaces.append(f)
    old_scripts = os.path.join(cible, "scripts_inventaire_php")
    if os.path.isdir(old_scripts):
        shutil.rmtree(old_scripts, ignore_errors=True)   # régénéré au démarrage avec la nouvelle version
    print(f"  [OK] Programme mis à jour en version {v_new}" + (f" ; fichiers obsolètes retirés : {', '.join(deplaces)}" if deplaces else ""))
    # 3. archive livrée et sa signature rangées avec la sauvegarde (évite de les reproposer)
    for f in (paquet, paquet + ".sig"):
        if os.path.isfile(f):
            try:
                shutil.move(f, os.path.join(sauv, os.path.basename(f)))
            except OSError:
                pass
    # 4. traces et rotation des sauvegardes
    os.makedirs(donnees, exist_ok=True)
    with open(os.path.join(donnees, "mises_a_jour.log"), "a", encoding="utf-8") as f:
        f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S}  {v_old} -> {v_new}  signature vérifiée ({cle})  sauvegarde {os.path.basename(sauv)}\n")
    racine = os.path.join(cible, "sauvegardes")
    anciennes = sorted(d for d in os.listdir(racine) if os.path.isdir(os.path.join(racine, d)))
    for d in anciennes[:-SAUVEGARDES_CONSERVEES]:
        shutil.rmtree(os.path.join(racine, d), ignore_errors=True)
    print(f"  [OK] Mise à jour terminée. Sauvegarde : sauvegardes\\{os.path.basename(sauv)} ({SAUVEGARDES_CONSERVEES} dernières conservées)\n")
    return 0


def etat_mises_a_jour():
    hist = []
    try:
        with open(os.path.join(DATA, "mises_a_jour.log"), encoding="utf-8") as f:
            hist = [l.strip() for l in f if l.strip()][-10:]
    except OSError:
        pass
    dispo = [p for p in paquets_disponibles(BASE) if cle_version(p["version"]) > cle_version(VERSION)]
    autres = [p for p in paquets_disponibles(BASE) if cle_version(p["version"]) <= cle_version(VERSION)]
    racine = os.path.join(BASE, "sauvegardes")
    nb = len([d for d in os.listdir(racine) if os.path.isdir(os.path.join(racine, d))]) if os.path.isdir(racine) else 0
    return {"version": VERSION, "dossier": BASE, "donnees": DATA, "historique": hist, "sauvegardes": nb,
            "disponible": dispo[0] if dispo else None, "anciennes": autres}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--sans-navigateur", action="store_true", help="ne pas ouvrir le navigateur au démarrage (service, tâche planifiée)")
    ap.add_argument("--donnees", metavar="DOSSIER", help="dossier de données (défaut : à côté du programme ; exécutable : dossier utilisateur)")
    ap.add_argument("--resultats", metavar="DOSSIER", help="dossier des résultats : scans, inventaires, bilans reçus, journaux (défaut : dossier de données)")
    ap.add_argument("--cycle", action="store_true", help="exécuter un cycle complet (scan, inventaire, comparaison, courriel) puis quitter")
    ap.add_argument("--installer-dans", metavar="DOSSIER", help="mise à jour : installer l'archive signée --paquet dans DOSSIER (données conservées)")
    ap.add_argument("--paquet", metavar="ZIP", default="", help="archive signée à installer (sa signature ZIP.sig à côté), rangée dans la sauvegarde")
    ap.add_argument("--paquets", metavar="DOSSIER", help="lister les archives de mise à jour disponibles (version|chemin) puis quitter")
    ap.add_argument("--confirme", action="store_true", help="mise à jour : choix déjà confirmé par l'utilisateur")
    ap.add_argument("--maj-disponible", metavar="DOSSIER", help="afficher version|archive de la mise à jour la plus récente, s'il y en a une")
    ap.add_argument("--mettre-a-jour", metavar="DOSSIER", help="option 5 du lanceur : choisir une archive et l'installer")
    args = ap.parse_args()
    if args.maj_disponible:
        x = maj_disponible(args.maj_disponible)
        if x:
            print(f"{x['version']}|{x['fichier']}")
        sys.exit(0)
    if args.mettre_a_jour:
        sys.exit(mettre_a_jour(args.mettre_a_jour))
    if args.paquets:
        for x in paquets_disponibles(args.paquets):
            print(f"{x['version']}|{x['fichier']}")
        sys.exit(0)
    if args.installer_dans:
        try:
            sys.exit(installer_dans(args.installer_dans, args.paquet, args.confirme))
        except Exception as e:  # noqa
            print(f"  [!!] Échec de la mise à jour : {e}\n       Le programme précédent et les données sont dans le dossier sauvegardes.")
            sys.exit(1)
    os.makedirs(DATA, exist_ok=True)
    premiere = not any(os.path.exists(x) for x in (CONFIG_PATH, VLANS_PATH, SERVEURS_PATH, NOMS_PATH))
    # seules les clés connues sont reprises : un compte enregistré par une version antérieure est ainsi effacé
    CONFIG.update({k: v for k, v in lire_json(CONFIG_PATH, {}).items() if k in CONFIG})
    sauver_json(CONFIG_PATH, CONFIG)
    charger_vlans()   # crée la cartographie initiale au lancement : aucune requête GET n'écrit ensuite
    ecrire_scripts()
    if premiere and not args.cycle:
        charger_exemples()
        print("Première utilisation : VLAN, serveurs et noms d'hôtes d'exemple chargés (adresses fictives, à supprimer dans Périmètre).")
    n = appliquer_retention()
    if n:
        print(f"Rétention : {n} ancien(s) scan(s) supprimé(s)")
    if args.cycle:
        texte = executer_cycle("ligne de commande")
        print(texte or "\n".join(ETAT_PLANIF["journal"]))
        sys.exit(0 if texte else 1)
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    except OSError:
        # une instance tourne déjà : on se contente d'ouvrir l'interface existante
        print(f"Une instance est déjà active sur le port {args.port} : utiliser son onglet, ou l'adresse avec jeton affichée dans sa fenêtre")
        if not args.sans_navigateur:
            import webbrowser
            webbrowser.open(f"http://127.0.0.1:{args.port}")
        return
    global PORT_ECOUTE
    PORT_ECOUTE = args.port
    if not charger_interface()["page"]:
        print(f"  [!!] Interface introuvable : {INTERFACE_FICHIER}")
    # jeton tiré au lancement (secrets) : exigé à chaque requête ; l'adresse munie du jeton n'est affichée qu'ici, jamais journalisée
    url = f"http://127.0.0.1:{args.port}/?jeton={JETON}"
    print(f"Inventaire PHP v{VERSION} — {url}")
    print(f"Plages autorisées : {', '.join(CONFIG['plages_autorisees']) or 'aucune (onglet Paramétrage)'}")
    print(f"Données           : {DATA}")
    threading.Thread(target=boucle_planificateur, daemon=True).start()
    if not args.sans_navigateur:
        import webbrowser
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
