@echo off
rem Inventaire PHP - cycle automatique pour le Planificateur de taches Windows.
rem Meme choix de Python et de nmap que le lanceur. Journal : cycle.log
setlocal EnableExtensions
pushd "%~dp0" 2>nul || exit /b 1
set "ICI=%CD%\"

rem ---- choix du Python : embarque d'abord, sinon celui du poste ----
rem (le test "python -c" ecarte le faux python.exe du Microsoft Store)
if exist "%ICI%python\python.exe" goto :py_embarque
python -c "import sys" >nul 2>&1
if not errorlevel 1 goto :py_poste
py -3 -c "import sys" >nul 2>&1
if not errorlevel 1 goto :py_lanceur
goto :sans_python
:py_embarque
set "PYEXE=%ICI%python\python.exe"
set "MODE=portable - Python embarque"
goto :choix_nmap
:py_poste
set "PYEXE=python"
set "MODE=installee - Python du poste"
goto :choix_nmap
:py_lanceur
for /f "delims=" %%p in ('py -3 -c "import sys;print(sys.executable)"') do set "PYEXE=%%p"
set "MODE=installee - Python du poste"
:choix_nmap
if exist "%ICI%nmap\nmap.exe" set "PATH=%ICI%nmap;%PATH%"
set "NMAP=absent - moteur de scan Python"
where nmap >nul 2>&1
if not errorlevel 1 set "NMAP=present"

echo ==== %date% %time% cycle, version %MODE%, nmap %NMAP% >> "%ICI%cycle.log"
"%PYEXE%" "%ICI%inventaire_php_app.py" --cycle --sans-navigateur --donnees "%ICI%donnees" >> "%ICI%cycle.log" 2>&1
popd
exit /b %errorlevel%
:sans_python
echo ==== %date% %time% ECHEC : aucun Python utilisable >> "%ICI%cycle.log"
popd
exit /b 1
