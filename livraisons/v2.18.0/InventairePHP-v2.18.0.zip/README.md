# Inventaire PHP — serveurs vulnérables

Outil local qui repère les serveurs de l'établissement exécutant PHP et ceux dont la version est concernée par les
vulnérabilités **CVE-2026-109618 et CVE-2026-109619** (alerte CERT-FR du 21/10/2026), suit leur correction et
consolide les bilans des hôpitaux. Il aide à décider : il ne corrige rien et ne décide rien.

Outil local des Hôpitaux de Corrèze, réservé aux fonctions **DSI, RSSI, RSI** (fiche, `public`), partagé avec les
établissements du club national des RSSI santé (licence MIT, décision D3). **En service** depuis le 25/10/2026.
Propriétaire : Stéphane Monéger, RSSI. Cadre : *Cadre de développement des applications internes*
(HC-SSI-CADRE-DEV, dépôt `smrcorp/appli-commun`), type « outil local » (décision D18).

> **Données et résultats hors dépôt.** L'inventaire réel des serveurs et les résultats (serveurs vulnérables,
> scans, bilans, journaux) ne sont jamais versés dans ce dépôt. Ils restent sur le poste qui exécute l'outil,
> dans les dossiers décrits plus bas, à protéger (accès réservé à l'équipe informatique).

## Ce que fait l'outil

1. **Périmètre** : l'utilisateur coche les VLAN de sa cartographie, les serveurs de son inventaire et les noms
   d'hôtes à examiner, puis applique ce périmètre. Rien en dehors n'est interrogé ; les exclusions l'emportent.
2. **Scan réseau** (sans compte) : recherche des services web (nmap s'il est installé, sinon moteur intégré) et
   requêtes HTTP GET de lecture pour relever les indices de PHP et la version annoncée.
3. **Scan hôtes** (seulement les serveurs de la liste importée, hors exclusions ; compte saisi à chaque scan,
   jamais enregistré ni journalisé) : SSH pour Linux, WinRM pour Windows ; un script d'inventaire en lecture seule
   lit la version de PHP réellement installée.
4. **Résultats** : machines concernées, suivi des corrections, vue territoire (bilans des autres hôpitaux), plan
   d'action, exports CSV, Excel, HTML et impression.

**Ce que l'outil contacte, et rien d'autre** : les adresses du périmètre et les serveurs de la liste (scans en
lecture seule, délais et tentatives bornés), le DNS du poste (noms d'hôtes fournis), le relais SMTP interne s'il est
renseigné (courriel de synthèse) ; le lanceur télécharge Python depuis python.org (option 2) ou installe Python et
nmap par winget (option 3). Détail : `app.yaml` (`services_externes`, `exploitation_des_systemes`). Le balayage des
serveurs exige une autorisation écrite consignée dans `app.yaml` (`autorisation`).

## Prérequis

- Poste Windows 10 ou 11 (client léger accepté), navigateur récent.
- Python 3.12 : installé sur le poste, ou « embarqué » dans le dossier de l'outil par le lanceur (aucune
  installation, aucun droit d'administration).
- Facultatif : nmap et Npcap (scans plus rapides), client OpenSSH et WinRM (scan hôtes).
- Aucune dépendance Python externe (`requirements.txt`).

## Installer ou mettre à jour (RSI, poste autorisé uniquement)

Le RSSI dépose dans le dossier OneDrive commun aux hôpitaux trois fichiers : l'archive `InventairePHP-vX.Y.Z.zip`,
sa signature `InventairePHP-vX.Y.Z.zip.sig` et la notice « A LIRE - installation.txt » ; il envoie à chaque
responsable informatique, par courriel, l'empreinte SHA-256 de l'archive. Toujours copier l'archive et sa signature,
ensemble, du dossier OneDrive vers Téléchargements (l'outil ne cherche pas dans OneDrive). La signature est celle de la clé du RSSI, dont
l'empreinte est `SHA256:ua+kcOxT3hsOeFxdyJADPogVig7D7jd4foQrMm/b0rg`.

**Première installation** (rien n'est encore installé sur le poste) ; mêmes étapes que la notice jointe à l'envoi :

1. **Vérifier l'archive avec le courriel du RSSI, une seule fois.** S'assurer que le courriel vient de l'adresse du
   RSSI, ouvrir la page jointe « Verifier InventairePHP-vX.Y.Z.html » et y déposer l'archive copiée dans
   Téléchargements : elle affiche en vert « Archive authentique » ou en rouge « Attention » (ne rien installer,
   appeler le RSSI). La vérification se fait sur le poste, sans rien envoyer. La page ne fait foi que reçue par ce
   courriel, jamais par un fichier du dossier OneDrive. À défaut, la ligne PowerShell du courriel fait la même
   vérification.
2. **Décompresser** l'archive (clic droit, « Extraire tout… ») dans un dossier dédié, par exemple
   `C:\Outils\inventaire`, dont l'accès est limité au compte de l'utilisateur (droits NTFS). Le dossier `donnees`
   (et, par défaut, les résultats et les journaux) se crée au premier lancement ; voir plus bas pour placer les
   résultats ailleurs.
3. **Lancer** : double-cliquer sur **`Inventaire PHP.bat`** (si Windows affiche « Windows a protégé votre
   ordinateur » : « Informations complémentaires », puis « Exécuter quand même », seulement après l'étape 1). Le
   menu contrôle le poste ; choisir **1** (Lancer l'application, Python présent) ou **2** (installer Python dans le
   dossier, sans droits : téléchargement depuis python.org, puis vérification automatique de la valeur de contrôle
   publiée par python.org, `PYMD5` dans le lanceur ; une archive différente est supprimée et rien n'est installé ;
   si le téléchargement est bloqué, enregistrer l'archive indiquée dans Téléchargements et relancer l'option).
   L'option **3** installe Python et nmap sur le poste avec droits d'administration (winget), l'option **4**
   affiche le journal du lanceur.
4. **Premier lancement** : choisir son hôpital quand l'outil le demande. Des données d'exemple fictives sont
   chargées (à supprimer avant d'importer les siennes) ; aucune plage n'est autorisée tant que vous n'avez pas
   déclaré votre périmètre (import des VLAN, serveurs et noms d'hôtes dans Paramétrage, puis « Appliquer le
   périmètre » dans 1 · Périmètre).

**Mise à jour** (l'outil est déjà installé) :

1. Copier l'archive et sa signature, ensemble, du dossier OneDrive vers Téléchargements (ou le dossier de l'outil),
   sans décompresser l'archive. Pas besoin de vérifier l'empreinte à la main.
2. Ouvrir le dossier où l'outil est installé ; si la fenêtre noire de l'outil est ouverte, la fermer. Double-cliquer
   sur « Inventaire PHP.bat » et choisir **5** (Mise à jour depuis une archive).
3. La version installée vérifie seule la signature du RSSI : si elle est bonne, elle sauvegarde les données et le
   programme précédent dans `sauvegardes` (10 dernières conservées), puis installe. Sinon elle affiche « archive non
   signée ou signature invalide : installation refusée, prévenez le RSSI », ne touche à rien, range l'archive et sa
   signature dans le sous-dossier `quarantaine` et consigne le refus dans `donnees\mises_a_jour.log`. Il n'existe
   aucun moyen de passer outre : prévenir le RSSI.

Au lancement, le navigateur s'ouvre sur `http://127.0.0.1:8765/?jeton=…` : le jeton, tiré au hasard à chaque
lancement, est exigé à chaque requête (il est ensuite gardé dans un cookie de session et retiré de l'adresse). Si le
navigateur ne s'ouvre pas, recopier l'adresse complète affichée dans la fenêtre noire ; garder cette fenêtre ouverte
pendant l'utilisation.

Sans le lanceur (tout système) :

```
python3 inventaire_php_app.py --donnees <dossier de données> --resultats <dossier des résultats>
```

Options utiles : `--port`, `--sans-navigateur`, `--cycle` (cycle planifié, voir `Cycle_planifie.bat`). Pour le
cycle planifié avec inventaire Linux, le compte SSH est celui de la session, ou la variable d'environnement
`INVENTAIRE_PHP_COMPTE_SSH` du poste : l'outil n'enregistre aucun compte. La mise à jour en ligne de commande
(`--mettre-a-jour <dossier>`, ou `--installer-dans <dossier> --paquet <archive>`) exige la même signature.

Fichiers livrés, et seuls ceux-là (`outils/livrer.py`) : `inventaire_php_app.py` (le programme),
`inventaire_php_interface.html` et `inventaire_php_complements.html` (pages construites, à garder à côté du
programme), le lanceur `Inventaire PHP.bat`, `Cycle_planifie.bat`, ce `README.md`, les modèles d'import
`modele_serveurs.csv` et `modele_vlans.csv` (lignes d'exemple fictives), `parametres_etablissement.json` et la
licence `LICENSE` (MIT).

## Partage avec d'autres établissements (club national des RSSI santé)

L'outil est sous licence MIT (décision D3) et conçu pour servir hors des Hôpitaux de Corrèze : le nom de
l'organisation, la mention des exports et la liste des établissements se déclarent à l'écran (au premier lancement,
ou dans Paramétrage › Réglages › Données) et sont conservés dans le dossier de données. Quand l'organisation n'est
pas les Hôpitaux de Corrèze, le bandeau porte son nom à la place du logo ; le crédit d'auteur demeure. Chaque
établissement utilisateur consigne sa propre autorisation écrite de balayage avant tout scan. Le RSSI des Hôpitaux
de Corrèze reste l'unique distributeur : chaque version est signée par sa clé, et les mises à jour sont vérifiées
comme partout ailleurs.

## Livrer une version (RSSI)

1. **Produire** : sur la branche principale à jour, `python3 outils/livrer.py` construit `InventairePHP-vX.Y.Z.zip`
   (X.Y.Z = `VERSION` du programme = première version d'`app.yaml`, refus sinon) avec les seuls fichiers livrés,
   vérifie que l'outil et le programme de signature l'acceptent et affiche son SHA-256. L'archive est reproductible :
   celle que GitHub joint à la publication de l'étiquette `vX.Y.Z` (workflow « livraison », mention « à signer par le
   RSSI avant envoi ») a la même empreinte. Elle n'est pas signée.
2. **Signer** sur le poste du RSSI, et là seulement : déposer l'archive sur « Signer une livraison.bat » (dossier
   `outils`). Le programme contrôle le contenu (aucune donnée, aucun résultat, aucun journal), fait signer l'archive
   par 1Password (ou OpenSSH), vérifie aussitôt la signature et prépare le dossier « Envoi InventairePHP-vX.Y.Z »
   (archive, signature, notice). La clé privée ne quitte jamais le poste du RSSI : ni le dépôt, ni GitHub, ni une
   session d'IA ne la voient.
3. **Mettre à disposition** : copier le contenu du dossier « Envoi … » (archive, signature, notice) dans le dossier
   OneDrive commun aux hôpitaux, puis envoyer à chaque responsable informatique, depuis l'adresse du RSSI, le
   courriel de l'empreinte SHA-256 (texte prêt : « Courriel empreinte InventairePHP-vX.Y.Z.txt ») avec en pièce
   jointe la page de vérification « Verifier InventairePHP-vX.Y.Z.html » (les deux à côté du dossier d'envoi ; ils
   ne vont pas dans OneDrive). Décision D2.
4. **Publier pour le club** (décision D3) : double-cliquer sur « Publier la livraison.bat » (dossier `outils`). Le
   programme revérifie la signature, demande confirmation, puis pousse l'archive, sa signature, la notice et la
   page de vérification dans `livraisons/vX.Y.Z/` du dépôt public `serveurs-php-vulnerables-public` : le club se
   sert tout seul, rien d'autre à envoyer.

Changer de clé : inscrire la nouvelle clé publique dans `CLES_SIGNATURE` (`inventaire_php_app.py`) à côté de
l'ancienne, livrer cette version signée par l'ancienne clé, puis retirer l'ancienne dans une version suivante.
Signature : format SSHSIG d'OpenSSH, Ed25519, hachage sha512, espace de noms « inventaire-php » ; vérification en
Python standard (RFC 8032), sans dépendance.

## Usage

Écrans à la charte commune des Hôpitaux de Corrèze (thèmes blanc, bleu et nuit au choix dans « Paramètres »).
Barre de menus de gauche à droite : **Accueil** (diagnostic du poste), **1 · Périmètre**, **2 · Scan réseau**,
**3 · Scan hôtes**, **4 · Résultats** ; **Paramétrage** pour importer les VLAN, les serveurs et les noms d'hôtes
(Excel, CSV, export RVTools), régler les scans et ouvrir l'aide. Les boutons du bandeau importent, exportent,
zooment, impriment, règlent le thème et ouvrent « À propos ». Au premier lancement, des données d'exemple aux adresses
fictives sont chargées ; les supprimer avant d'importer les siennes.

## Emplacement des données et des résultats (hors dépôt)

| Dossier | Désignation | Défaut | Contenu |
| --- | --- | --- | --- |
| Données | `--donnees` ou variable `INVENTAIRE_PHP_DONNEES` | `donnees\` à côté du programme | configuration, serveurs, VLAN, noms d'hôtes, suivi, plan d'action, corbeille |
| Résultats | `--resultats` ou variable `INVENTAIRE_PHP_RESULTATS` | le dossier de données | scans, inventaires des hôtes, bilans reçus, journaux (`journaux\`) |

Ces dossiers sont exclus du dépôt (`.gitignore`). Leur structure est décrite dans `docs/DONNEES.md`. Les valeurs
propres à l'établissement (organisation, liste des hôpitaux, mention de diffusion) sont dans
`parametres_etablissement.json`, surchargeable par un fichier du même nom dans le dossier de données.

## Construction, essai et vérifications (développement)

```
python3 <appli-commun>/outils/importer_charte.py .   # paquet de la charte dans vendor/hc-charte/ (jamais retouché)
python3 outils/construire.py                          # pages à la charte, à partir de interface/ et de app.yaml (PyYAML)
python3 outils/essai.py                               # essai de bout en bout sur le jeu fictif essai/ (faux serveur PHP local),
                                                      # puis livraisons signées (outils/essai_livraison.py, clé d'essai jetable, ssh-keygen)
python3 outils/livrer.py                              # archive de livraison InventairePHP-vX.Y.Z.zip et son SHA-256 (à signer par le RSSI)
python3 outils/verifier_depot.py --index              # secrets, adresses réelles, termes interdits, versions, pages à jour
python3 <appli-commun>/outils/controler_service.py .  # contrôles du cadre (outil local)
```

GitHub rejoue à chaque envoi la vérification des pages, la vérification avant envoi, l'essai et une recherche de
secrets dans tout l'historique (`.github/workflows/controles.yml`) ; à chaque étiquette `vX.Y.Z`, le workflow
« livraison » (`.github/workflows/livraison.yml`) construit l'archive et la publie, non signée, avec son SHA-256 ; les contrôles du cadre n'y tournent que si le
secret `APPLI_COMMUN_LECTURE` (jeton de lecture d'appli-commun) est défini.

`essai/` ne contient que des données fictives (adresses de documentation 192.0.2.x, 198.51.100.x, 203.0.113.x,
noms en `*.example.org`, versions de PHP inventées).
