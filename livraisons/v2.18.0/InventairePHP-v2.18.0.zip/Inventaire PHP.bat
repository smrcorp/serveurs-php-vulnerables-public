@echo off
rem ==========================================================================
rem  Inventaire PHP - SCRIPT UNIQUE : controles du poste, installation, lancement.
rem  Double-cliquer. Le menu propose l'option adaptee au poste.
rem  Journal : demarrage.log dans ce dossier.
rem ==========================================================================
setlocal EnableExtensions
set "ORIG=%~dp0"
set "APRES="
if /i "%~1"=="apres-maj" set "APRES=mise a jour"
pushd "%~dp0" 2>nul || goto :inaccessible
set "ICI=%CD%\"
set "LOG=%ICI%demarrage.log"
set "PYVER=3.12.7"
set "PYZIP=python-%PYVER%-embed-amd64.zip"
set "PYURL=https://www.python.org/ftp/python/%PYVER%/%PYZIP%"
rem Valeur de controle officielle de l'archive (MD5 publie sur la page python.org de la version 3.12.7,
rem ligne "Windows embeddable package (64-bit)", releve par le RSSI le 24/10/2026) : verification automatique.
set "PYMD5=4c0a5a44d4ca1d0bc76fe08ea8b76adc"
rem Empreinte SHA-256 facultative ; vide, et sans PYMD5 : l'empreinte est affichee et confirmee a l'ecran.
set "PYSHA256="
title Inventaire PHP
echo ==== %date% %time% ouverture depuis "%~dp0" > "%LOG%"
if not exist "%ICI%inventaire_php_app.py" goto :app_absente
rem remplacement du lanceur interrompu lors d'une mise a jour precedente : le terminer
if exist "%ICI%Inventaire PHP.bat.new" goto :finir_remplacement

:controles
cls
call :detecter
echo.
echo   ==============================================================
echo    INVENTAIRE PHP - controles du poste
echo   ==============================================================
echo    Dossier ................ %ICI%
echo    Ecriture dans le dossier  %ECRITURE%
echo    Python embarque ........ %PYEMB%
echo    Python du poste ........ %PYPOSTE%
echo    nmap ................... %ETATNMAP%
echo    Npcap .................. %ETATNPCAP%
echo    Droits administrateur .. %ADMIN%
echo    Archive Python ......... %ARCHIVE%
echo    Version installee ...... %VINST%
echo    Mise a jour ............ %ETATMAJ%
echo   --------------------------------------------------------------
echo    SITUATION : %SITUATION%
echo    CONSEIL   : %CONSEIL%
echo   ==============================================================
echo.
echo    [1] Lancer l'application
echo    [2] Installer Python dans ce dossier - SANS droits d'administration
echo        client leger, bureau virtuel : rien n'est installe sur le poste
echo    [3] Installer Python et nmap sur le poste - AVEC droits d'administration
echo    [4] Afficher le journal
echo    [5] Mettre a jour l'application - archive signee, donnees conservees et sauvegardees
echo    [Q] Quitter
echo.
call :log "Controles : %SITUATION% / Python %PYEXE% / nmap %ETATNMAP%"
if "%DEFAUT%"=="1" goto :menu_auto
choice /c 12345Q /n /m "   Votre choix, option conseillee %DEFAUT% : "
goto :menu_suite
:menu_auto
echo    Lancement automatique dans 15 secondes ; une touche pour choisir.
choice /c 12345Q /n /t 15 /d 1 /m "   Votre choix [1] : "
:menu_suite
if errorlevel 6 goto :fin
if errorlevel 5 goto :maj
if errorlevel 4 goto :journal
if errorlevel 3 goto :inst_admin
if errorlevel 2 goto :inst_sans
goto :lancer

rem ======================= [1] lancement =======================
:lancer
set "APRES="
if not defined PYEXE goto :pas_de_python
cls
echo.
echo   Inventaire PHP - %MODE%
echo   nmap : %ETATNMAP%
echo.
echo   Le navigateur va s'ouvrir sur l'application.
echo   GARDER CETTE FENETRE OUVERTE : la fermer arrete l'application.
echo   Ne pas cliquer dedans : un clic la met en pause (titre "Selection") ; Echap pour reprendre.
echo   Si le navigateur ne s'ouvre pas : copier l'adresse complete affichee ci-dessous,
echo   avec son ?jeton=... (le jeton change a chaque lancement).
echo.
call :log "Lancement : %PYEXE%"
"%PYEXE%" "%ICI%inventaire_php_app.py" --donnees "%ICI%donnees" >> "%LOG%" 2>&1
echo.
echo   L'application s'est arretee. Dernieres lignes du journal :
echo   --------------------------------------------------------------
powershell -NoProfile -Command "Get-Content -Tail 20 '%LOG%'"
echo   --------------------------------------------------------------
pause
goto :controles

:pas_de_python
echo.
echo   [!!] Aucun Python utilisable : choisir d'abord l'option 2 ou 3.
pause
goto :controles

rem ======================= [2] installation sans droits =======================
:inst_sans
cls
echo.
echo   Installation de Python embarque dans : %ICI%python
echo   Rien n'est installe sur le poste ni ecrit dans le registre.
echo.
call :log "Installation sans droits"
if "%ECRITURE%"=="NON" goto :e_ecriture
if not exist "%ICI%python" mkdir "%ICI%python"
if exist "%ICI%%PYZIP%" goto :archive_ok
if exist "%ICI%..\%PYZIP%" copy /y "%ICI%..\%PYZIP%" "%ICI%%PYZIP%" >nul
if exist "%ICI%%PYZIP%" call :log "Archive reprise du dossier parent"
if exist "%ICI%%PYZIP%" goto :archive_ok
if exist "%USERPROFILE%\Downloads\%PYZIP%" copy /y "%USERPROFILE%\Downloads\%PYZIP%" "%ICI%%PYZIP%" >nul
if exist "%ICI%%PYZIP%" call :log "Archive reprise de Telechargements"
if exist "%ICI%%PYZIP%" goto :archive_ok
echo   [..] Telechargement de Python %PYVER%, environ 11 Mo (3 minutes au plus)...
echo        Ne pas cliquer dans cette fenetre : un clic la met en pause (Echap pour reprendre).
call :log "Telechargement %PYURL%"
powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; $p=[Net.WebRequest]::GetSystemWebProxy(); $p.Credentials=[Net.CredentialCache]::DefaultNetworkCredentials; [Net.WebRequest]::DefaultWebProxy=$p; try { Invoke-WebRequest -Uri '%PYURL%' -OutFile '%ICI%%PYZIP%' -UseBasicParsing -TimeoutSec 180 } catch { Write-Output $_.Exception.Message; Remove-Item -Force -ErrorAction SilentlyContinue '%ICI%%PYZIP%' }" >> "%LOG%" 2>&1
if exist "%ICI%%PYZIP%" goto :archive_ok
call :log "PowerShell sans succes, essai avec curl"
where curl >nul 2>&1
if not errorlevel 1 curl -sS -L --connect-timeout 15 --max-time 180 -o "%ICI%%PYZIP%" "%PYURL%" >> "%LOG%" 2>&1
if errorlevel 1 if exist "%ICI%%PYZIP%" del /q "%ICI%%PYZIP%"
if exist "%ICI%%PYZIP%" goto :archive_ok
echo.
echo   [!!] Le telechargement automatique a echoue : proxy ou filtrage.
echo        1. Ouvrir cette adresse dans le navigateur :
echo           %PYURL%
echo        2. Enregistrer le fichier dans ce dossier ou dans Telechargements.
echo        3. Revenir ici et appuyer sur une touche.
pause
if exist "%USERPROFILE%\Downloads\%PYZIP%" copy /y "%USERPROFILE%\Downloads\%PYZIP%" "%ICI%%PYZIP%" >nul
if not exist "%ICI%%PYZIP%" goto :e_archive
:archive_ok
set "TAILLE=0"
for %%A in ("%ICI%%PYZIP%") do set "TAILLE=%%~zA"
call :log "Archive presente, %TAILLE% octets"
if %TAILLE% LSS 5000000 goto :e_taille
set "EMPR="
for /f "delims=" %%h in ('certutil -hashfile "%ICI%%PYZIP%" SHA256 ^| findstr /v /c:":"') do if not defined EMPR set "EMPR=%%h"
set "EMPR=%EMPR: =%"
call :log "Empreinte SHA-256 de l'archive : %EMPR%"
if defined PYMD5 goto :md5_attendu
if defined PYSHA256 goto :empreinte_attendue
echo.
echo   [!!] Empreinte de l'archive non verifiee automatiquement :
echo        %EMPR%
echo        La comparer a l'empreinte publiee sur python.org pour %PYZIP%.
choice /c ON /n /m "   L'empreinte est-elle identique ? [O/N] "
if errorlevel 2 goto :e_empreinte
goto :empreinte_ok
:md5_attendu
set "EMD5="
for /f "delims=" %%h in ('certutil -hashfile "%ICI%%PYZIP%" MD5 ^| findstr /v /c:":"') do if not defined EMD5 set "EMD5=%%h"
set "EMD5=%EMD5: =%"
call :log "Controle MD5 de l'archive : %EMD5% (attendu %PYMD5%)"
if /i not "%EMD5%"=="%PYMD5%" goto :e_empreinte
echo   [OK] Archive Python verifiee (valeur de controle officielle de python.org).
if not defined PYSHA256 goto :empreinte_ok
:empreinte_attendue
if /i not "%EMPR%"=="%PYSHA256%" goto :e_empreinte
:empreinte_ok
echo   [..] Decompression (moins d'une minute)...
where tar >nul 2>&1
if not errorlevel 1 tar -xf "%ICI%%PYZIP%" -C "%ICI%python" >> "%LOG%" 2>&1
if not exist "%ICI%python\python.exe" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; Expand-Archive -Force -Path '%ICI%%PYZIP%' -DestinationPath '%ICI%python'" >> "%LOG%" 2>&1
if not exist "%ICI%python\python.exe" goto :e_decompression
set "PTH="
for %%f in ("%ICI%python\python3*._pth") do set "PTH=%%f"
if "%PTH%"=="" goto :e_decompression
> "%PTH%" echo python312.zip
>> "%PTH%" echo .
>> "%PTH%" echo ..
>> "%PTH%" echo import site
echo   [..] Test...
"%ICI%python\python.exe" -m py_compile "%ICI%inventaire_php_app.py" >> "%LOG%" 2>&1
if errorlevel 1 goto :e_test
del /q "%ICI%%PYZIP%" >nul 2>&1
call :log "Installation sans droits reussie"
echo.
echo   [OK] Python embarque installe. Retour au menu : choisir [1].
set "APRES=installation"
pause
goto :controles

rem ======================= [3] installation avec droits =======================
:inst_admin
cls
echo.
call :log "Installation avec droits"
if "%ADMIN%"=="NON" goto :e_admin
where winget >nul 2>&1
if errorlevel 1 goto :e_winget
if not defined PYPOSTE_EXE echo   [..] Installation de Python 3.12...
if not defined PYPOSTE_EXE winget install --id Python.Python.3.12 -e --scope machine --silent --accept-source-agreements --accept-package-agreements >> "%LOG%" 2>&1
if not defined NMAPEXE echo   [..] Installation de nmap...
if not defined NMAPEXE winget install --id Insecure.Nmap -e --silent --accept-source-agreements --accept-package-agreements >> "%LOG%" 2>&1
powershell -NoProfile -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Inventaire PHP.lnk')); $s.TargetPath='%ICI%Inventaire PHP.bat'; $s.WorkingDirectory='%ICI%'; $s.IconLocation='shell32.dll,13'; $s.Save()" >> "%LOG%" 2>&1
call :detecter
echo.
echo   Python : %PYPOSTE%
echo   nmap   : %ETATNMAP%
echo   Npcap  : %ETATNPCAP%
if "%ETATNPCAP%"=="absent" echo.
if "%ETATNPCAP%"=="absent" echo   Npcap ne s'installe pas en silencieux : l'installer depuis https://npcap.com
if "%ETATNPCAP%"=="absent" echo   Sans Npcap, l'application utilise son moteur de scan Python.
echo.
echo   Raccourci "Inventaire PHP" cree sur le Bureau. Retour au menu.
set "APRES=installation"
call :log "Installation avec droits terminee : Python %PYPOSTE%, nmap %ETATNMAP%, Npcap %ETATNPCAP%"
pause
goto :controles

rem ======================= [5] mise a jour =======================
:maj
cls
echo.
echo   MISE A JOUR DE L'APPLICATION
echo   ------------------------------------------------------------
if not defined PYEXE goto :e_maj_python
findstr /c:"--mettre-a-jour" "%ICI%inventaire_php_app.py" >nul 2>&1
if errorlevel 1 goto :maj_ancienne
call :log "Mise a jour : recherche des archives"
"%PYEXE%" "%ICI%inventaire_php_app.py" --mettre-a-jour "%ICI%."
set "RC=%errorlevel%"
goto :maj_apres
:maj_ancienne
rem programme installe sans --mettre-a-jour, donc sans verification des signatures (fichier incomplet
rem ou modifie) : aucune installation par ce lanceur, aucun contournement
echo   [!!] Le programme installe ne sait pas verifier la signature des archives :
echo        installation refusee. Prevenez le RSSI, qui fournira une installation complete.
call :log "Mise a jour refusee : programme installe sans verification des signatures"
set "RC=6"
goto :maj_retour
:maj_apres
call :log "Mise a jour terminee, code %RC%"
if not "%RC%"=="0" goto :maj_retour
set "APRES=mise a jour"
if not exist "%ICI%Inventaire PHP.bat.new" goto :maj_retour
rem le lanceur ne peut pas se remplacer pendant qu'il s'execute : un petit script temporaire le fait
set "RELANCE=%TEMP%\inventaire_php_relance.cmd"
> "%RELANCE%" echo @echo off
>> "%RELANCE%" echo ping -n 3 127.0.0.1 ^>nul
>> "%RELANCE%" echo move /y "%ORIG%Inventaire PHP.bat.new" "%ORIG%Inventaire PHP.bat" ^>nul
>> "%RELANCE%" echo start "" "%ORIG%Inventaire PHP.bat" apres-maj
echo   Le menu va se rouvrir dans sa nouvelle version.
pause
start "" /min "%RELANCE%"
popd
exit
:maj_retour
pause
goto :controles

:finir_remplacement
set "RELANCE=%TEMP%\inventaire_php_relance.cmd"
> "%RELANCE%" echo @echo off
>> "%RELANCE%" echo ping -n 3 127.0.0.1 ^>nul
>> "%RELANCE%" echo move /y "%ORIG%Inventaire PHP.bat.new" "%ORIG%Inventaire PHP.bat" ^>nul
>> "%RELANCE%" echo start "" "%ORIG%Inventaire PHP.bat" apres-maj
echo   Fin de la mise a jour du lanceur : le menu se rouvre dans quelques secondes.
start "" /min "%RELANCE%"
popd
exit

rem ======================= [4] journal =======================
:journal
cls
powershell -NoProfile -Command "Get-Content -Tail 40 '%LOG%'"
pause
goto :controles

rem ======================= detection =======================
:detecter
set "PYEXE="
set "PYPOSTE_EXE="
set "NMAPEXE="
set "PYEMB=absent"
set "PYPOSTE=absent"
set "ETATNMAP=absent"
set "ETATNPCAP=absent"
set "ADMIN=NON"
set "ECRITURE=NON"
set "ARCHIVE=absente - sera telechargee si besoin"
rem -- ecriture
type nul > "%ICI%.test_ecriture" 2>nul
if exist "%ICI%.test_ecriture" set "ECRITURE=oui"
del /q "%ICI%.test_ecriture" >nul 2>&1
rem -- Python embarque
if not exist "%ICI%python\python.exe" goto :det_poste
"%ICI%python\python.exe" -c "import sys" >nul 2>&1
if errorlevel 1 set "PYEMB=present mais ne demarre pas - refaire l'option 2"
if not errorlevel 1 set "PYEMB=present"
:det_poste
rem -- Python du poste ; le test ecarte le faux python.exe du Microsoft Store
python -c "import sys" >nul 2>&1
if not errorlevel 1 set "PYPOSTE_EXE=python"
if defined PYPOSTE_EXE goto :det_poste_ok
py -3 -c "import sys" >nul 2>&1
if errorlevel 1 goto :det_chemins
for /f "delims=" %%p in ('py -3 -c "import sys;print(sys.executable)"') do set "PYPOSTE_EXE=%%p"
goto :det_poste_ok
:det_chemins
if exist "%ProgramFiles%\Python312\python.exe" set "PYPOSTE_EXE=%ProgramFiles%\Python312\python.exe"
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PYPOSTE_EXE=%LocalAppData%\Programs\Python\Python312\python.exe"
:det_poste_ok
if defined PYPOSTE_EXE set "PYPOSTE=present"
rem -- choix du Python : embarque d'abord
if "%PYEMB%"=="present" set "PYEXE=%ICI%python\python.exe"
if "%PYEMB%"=="present" set "MODE=version portable - Python embarque"
if not defined PYEXE if defined PYPOSTE_EXE set "MODE=version installee - Python du poste"
if not defined PYEXE if defined PYPOSTE_EXE set "PYEXE=%PYPOSTE_EXE%"
rem -- nmap et Npcap
if exist "%ICI%nmap\nmap.exe" set "NMAPEXE=%ICI%nmap\nmap.exe"
if exist "%ICI%nmap\nmap.exe" set "PATH=%ICI%nmap;%PATH%"
if not defined NMAPEXE if exist "%ProgramFiles(x86)%\Nmap\nmap.exe" set "NMAPEXE=%ProgramFiles(x86)%\Nmap\nmap.exe"
if not defined NMAPEXE if exist "%ProgramFiles%\Nmap\nmap.exe" set "NMAPEXE=%ProgramFiles%\Nmap\nmap.exe"
if not defined NMAPEXE for /f "delims=" %%n in ('where nmap 2^>nul') do set "NMAPEXE=%%n"
if defined NMAPEXE set "ETATNMAP=present"
if defined NMAPEXE for %%d in ("%NMAPEXE%") do set "PATH=%%~dpd;%PATH%"
if exist "%SystemRoot%\System32\Npcap\" set "ETATNPCAP=present"
rem -- droits administrateur
net session >nul 2>&1
if not errorlevel 1 set "ADMIN=oui"
rem -- archive Python deja telechargee
if exist "%USERPROFILE%\Downloads\%PYZIP%" set "ARCHIVE=dans Telechargements"
if exist "%ICI%..\%PYZIP%" set "ARCHIVE=dans le dossier parent"
if exist "%ICI%%PYZIP%" set "ARCHIVE=dans ce dossier"
rem -- version installee et archive de mise a jour
set "VINST=inconnue"
for /f "tokens=2 delims== " %%v in ('findstr /b /c:"VERSION = " "%ICI%inventaire_php_app.py" 2^>nul') do set "VINST=%%~v"
set "MAJZIP="
set "VNEW="
set "ETATMAJ=aucune version plus recente trouvee"
if not defined PYEXE goto :det_maj_fin
findstr /c:"--maj-disponible" "%ICI%inventaire_php_app.py" >nul 2>&1
if errorlevel 1 goto :det_maj_fin
for /f "tokens=1,* delims=|" %%a in ('call "%PYEXE%" "%ICI%inventaire_php_app.py" --maj-disponible "%ICI%." 2^>nul') do set "VNEW=%%a" & set "MAJZIP=%%b"
if defined MAJZIP set "ETATMAJ=version %VNEW% disponible - option 5"
:det_maj_fin
rem -- situation et conseil
set "DEFAUT=2"
set "SITUATION=aucun Python, pas de droits d'administration"
set "CONSEIL=option 2, une seule fois, puis option 1"
if "%ADMIN%"=="oui" set "SITUATION=aucun Python, droits d'administration"
if "%ADMIN%"=="oui" set "CONSEIL=option 3 sur un poste d'administration, sinon option 2"
if "%ADMIN%"=="oui" set "DEFAUT=3"
if not defined PYEXE exit /b 0
set "DEFAUT=1"
set "SITUATION=%MODE%, nmap non utilisable"
set "CONSEIL=option 1 : moteur de scan Python, plus lent que nmap"
if "%ETATNMAP%%ETATNPCAP%"=="presentpresent" set "SITUATION=%MODE%, nmap et Npcap presents"
if "%ETATNMAP%%ETATNPCAP%"=="presentpresent" set "CONSEIL=option 1 : tout est en place, scan nmap"
if defined APRES set "SITUATION=%APRES% effectuee - %MODE%"
if defined APRES set "CONSEIL=option 1 : lancer l'application"
if defined APRES exit /b 0
if not defined MAJZIP exit /b 0
set "DEFAUT=5"
set "SITUATION=nouvelle version %VNEW% disponible, installee %VINST%"
set "CONSEIL=option 5 : mettre a jour, les donnees sont conservees"
exit /b 0

rem ======================= utilitaires et erreurs =======================
:log
echo %time:~0,8%  %~1 >> "%LOG%"
exit /b 0

:e_ecriture
echo   [!!] Impossible d'ecrire dans ce dossier : le copier dans un dossier personnel.
goto :e_fin
:e_archive
echo   [!!] Archive Python introuvable. Deposer %PYZIP% dans ce dossier puis refaire l'option 2.
goto :e_fin
:e_empreinte
echo   [!!] Empreinte de l'archive refusee : fichier supprime, rien n'est installe.
call :log "Empreinte refusee : %EMPR%"
del /q "%ICI%%PYZIP%" >nul 2>&1
goto :e_fin
:e_taille
echo   [!!] Archive trop petite, %TAILLE% octets : telechargement tronque. Supprimer %PYZIP% et refaire l'option 2.
del /q "%ICI%%PYZIP%" >nul 2>&1
goto :e_fin
:e_decompression
echo   [!!] Decompression impossible : voir le journal, option 4.
goto :e_fin
:e_test
echo   [!!] Python embarque ne demarre pas : voir le journal, option 4.
goto :e_fin
:e_admin
echo   [!!] Ce script n'a pas les droits d'administration.
echo        Fermer, puis clic droit sur "Inventaire PHP.bat" : Executer en tant qu'administrateur.
echo        Sans droits possibles : choisir l'option 2.
goto :e_fin
:e_winget
echo   [!!] winget absent. Installer a la main :
echo        Python 3 : https://www.python.org/downloads/ - cocher "Add python.exe to PATH"
echo        nmap     : https://nmap.org/download.html - cocher Npcap
echo        Ou choisir l'option 2, sans droits.
goto :e_fin
:e_maj_python
echo   [!!] Aucun Python utilisable : faire d'abord l'option 2 ou 3.
goto :e_fin
:e_fin
call :log "ECHEC, voir message a l'ecran"
echo.
pause
goto :controles

:app_absente
echo [!!] inventaire_php_app.py absent de ce dossier : decompresser l'archive complete.
pause
exit /b 1

:inaccessible
echo [!!] Dossier inaccessible : lecteur deconnecte ou droits insuffisants.
pause
exit /b 1

:fin
popd
exit /b 0
